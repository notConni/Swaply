import React, { useEffect, useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { supabase } from '../lib/supabase';
import { Session, Skill } from '../types';
import { Calendar, Users, Plus, MapPin, Clock } from 'lucide-react';
import { Link } from 'react-router-dom';

export const Sessions: React.FC = () => {
  const { user } = useAuth();
  const [allSessions, setAllSessions] = useState<Session[]>([]);
  const [mySessions, setMySessions] = useState<Session[]>([]);
  const [joinedSessions, setJoinedSessions] = useState<Session[]>([]);
  const [allSkills, setAllSkills] = useState<Skill[]>([]);
  const [loading, setLoading] = useState(true);
  const [showCreate, setShowCreate] = useState(false);
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    skillId: '',
    sessionType: 'online' as 'online' | 'in-person',
    scheduledDate: '',
    scheduledTime: '',
    durationMinutes: 60,
    location: '',
    maxParticipants: 5,
  });

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setLoading(true);
    try {
      const { data: skills } = await supabase.from('skills').select('*');
      setAllSkills(skills || []);

      const { data: sessions } = await supabase
        .from('sessions')
        .select('*, skill:skill_id(*), creator:creator_id(id, username, profile_picture_url)')
        .eq('status', 'scheduled')
        .gte('scheduled_date', new Date().toISOString().split('T')[0])
        .order('scheduled_date', { ascending: true });

      setAllSessions((sessions as any) || []);

      if (user) {
        const { data: mySessions } = await supabase
          .from('sessions')
          .select('*')
          .eq('creator_id', user.id)
          .order('scheduled_date', { ascending: true });

        setMySessions((mySessions as any) || []);

        const { data: participants } = await supabase
          .from('session_participants')
          .select('session_id')
          .eq('user_id', user.id);

        const sessionIds = participants?.map((p) => p.session_id) || [];

        if (sessionIds.length > 0) {
          const { data: joined } = await supabase
            .from('sessions')
            .select('*, skill:skill_id(*), creator:creator_id(id, username, profile_picture_url)')
            .in('id', sessionIds)
            .order('scheduled_date', { ascending: true });

          setJoinedSessions((joined as any) || []);
        }
      }
    } finally {
      setLoading(false);
    }
  };

  const handleCreateSession = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;

    try {
      const { data: newSession } = await supabase
        .from('sessions')
        .insert([
          {
            title: formData.title,
            description: formData.description,
            skill_id: formData.skillId,
            creator_id: user.id,
            session_type: formData.sessionType,
            scheduled_date: formData.scheduledDate,
            scheduled_time: formData.scheduledTime,
            duration_minutes: formData.durationMinutes,
            location: formData.sessionType === 'in-person' ? formData.location : null,
            max_participants: formData.maxParticipants,
          },
        ])
        .select();

      if (newSession) {
        await supabase.from('session_participants').insert([
          {
            session_id: newSession[0].id,
            user_id: user.id,
            role: 'teacher',
          },
        ]);

        setFormData({
          title: '',
          description: '',
          skillId: '',
          sessionType: 'online',
          scheduledDate: '',
          scheduledTime: '',
          durationMinutes: 60,
          location: '',
          maxParticipants: 5,
        });
        setShowCreate(false);
        loadData();
      }
    } catch (err) {
      console.error('Error creating session:', err);
    }
  };

  const handleJoinSession = async (sessionId: string) => {
    if (!user) return;

    try {
      await supabase.from('session_participants').insert([
        {
          session_id: sessionId,
          user_id: user.id,
          role: 'learner',
        },
      ]);

      loadData();
    } catch (err) {
      console.error('Error joining session:', err);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  const sessionCard = (session: Session, variant: 'all' | 'mine' | 'joined') => (
    <div key={session.id} className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition">
      <div className="flex items-start justify-between mb-4">
        <div>
          <h3 className="text-lg font-bold text-gray-900">{session.title}</h3>
          <p className="text-sm text-gray-600">{session.skill?.name}</p>
        </div>
        <span className={`px-3 py-1 rounded-full text-xs font-semibold ${
          session.session_type === 'online'
            ? 'bg-blue-100 text-blue-700'
            : 'bg-green-100 text-green-700'
        }`}>
          {session.session_type === 'online' ? '💻 Online' : '📍 In-person'}
        </span>
      </div>

      {session.description && (
        <p className="text-sm text-gray-600 mb-3">{session.description}</p>
      )}

      <div className="space-y-2 mb-4 text-sm text-gray-600">
        <div className="flex items-center gap-2">
          <Calendar size={16} />
          {new Date(session.scheduled_date).toLocaleDateString()} at {session.scheduled_time}
        </div>
        <div className="flex items-center gap-2">
          <Clock size={16} />
          {session.duration_minutes} minutes
        </div>
        {session.location && (
          <div className="flex items-center gap-2">
            <MapPin size={16} />
            {session.location}
          </div>
        )}
      </div>

      <div className="flex items-center justify-between mb-4 text-sm text-gray-600">
        <div className="flex items-center gap-2">
          <Users size={16} />
          <span>Participants limit: {session.max_participants}</span>
        </div>
      </div>

      {session.creator && variant === 'all' && (
        <div className="p-3 bg-gray-50 rounded-lg mb-4">
          <p className="text-sm text-gray-600">
            Hosted by <span className="font-semibold text-gray-900">{session.creator.username}</span>
          </p>
        </div>
      )}

      {variant === 'all' && (
        <button
          onClick={() => handleJoinSession(session.id)}
          className="w-full bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700 transition font-semibold"
        >
          Join Session
        </button>
      )}
    </div>
  );

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex items-center justify-between mb-8">
          <h1 className="text-3xl font-bold text-gray-900">Learning Sessions</h1>
          <button
            onClick={() => setShowCreate(!showCreate)}
            className="flex items-center gap-2 bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition font-semibold"
          >
            <Plus size={20} />
            Create Session
          </button>
        </div>

        {/* Create Session Form */}
        {showCreate && (
          <div className="bg-white rounded-lg shadow-md p-6 mb-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">Schedule a New Learning Session</h2>
            <form onSubmit={handleCreateSession} className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Session Title</label>
                <input
                  type="text"
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  required
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none transition"
                  placeholder="e.g., Spanish Conversation Practice"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Skill</label>
                <select
                  value={formData.skillId}
                  onChange={(e) => setFormData({ ...formData, skillId: e.target.value })}
                  required
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none transition"
                >
                  <option value="">Select a skill</option>
                  {allSkills.map((skill) => (
                    <option key={skill.id} value={skill.id}>
                      {skill.name}
                    </option>
                  ))}
                </select>
              </div>

              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-gray-700 mb-2">Description</label>
                <textarea
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  rows={3}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none transition resize-none"
                  placeholder="Describe the session..."
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Session Type</label>
                <select
                  value={formData.sessionType}
                  onChange={(e) => setFormData({ ...formData, sessionType: e.target.value as any })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none transition"
                >
                  <option value="online">Online</option>
                  <option value="in-person">In-person</option>
                </select>
              </div>

              {formData.sessionType === 'in-person' && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Location</label>
                  <input
                    type="text"
                    value={formData.location}
                    onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none transition"
                    placeholder="Meeting location"
                  />
                </div>
              )}

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Date</label>
                <input
                  type="date"
                  value={formData.scheduledDate}
                  onChange={(e) => setFormData({ ...formData, scheduledDate: e.target.value })}
                  required
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none transition"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Time</label>
                <input
                  type="time"
                  value={formData.scheduledTime}
                  onChange={(e) => setFormData({ ...formData, scheduledTime: e.target.value })}
                  required
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none transition"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Duration (minutes)</label>
                <input
                  type="number"
                  min="15"
                  value={formData.durationMinutes}
                  onChange={(e) => setFormData({ ...formData, durationMinutes: parseInt(e.target.value) })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none transition"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Max Participants</label>
                <input
                  type="number"
                  min="2"
                  value={formData.maxParticipants}
                  onChange={(e) => setFormData({ ...formData, maxParticipants: parseInt(e.target.value) })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none transition"
                />
              </div>

              <div className="md:col-span-2 flex gap-3">
                <button
                  type="submit"
                  className="flex-1 bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700 transition font-semibold"
                >
                  Create Session
                </button>
                <button
                  type="button"
                  onClick={() => setShowCreate(false)}
                  className="flex-1 bg-gray-300 text-gray-700 py-2 rounded-lg hover:bg-gray-400 transition font-semibold"
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        )}

        {/* Sessions Grid */}
        <div className="space-y-8">
          {/* My Sessions */}
          {mySessions.length > 0 && (
            <div>
              <h2 className="text-2xl font-bold text-gray-900 mb-4">My Sessions</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {mySessions.map((session) => sessionCard(session, 'mine'))}
              </div>
            </div>
          )}

          {/* Joined Sessions */}
          {joinedSessions.length > 0 && (
            <div>
              <h2 className="text-2xl font-bold text-gray-900 mb-4">Sessions I'm Attending</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {joinedSessions.map((session) => sessionCard(session, 'joined'))}
              </div>
            </div>
          )}

          {/* Available Sessions */}
          {allSessions.length > 0 && (
            <div>
              <h2 className="text-2xl font-bold text-gray-900 mb-4">Available Sessions</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {allSessions.map((session) => sessionCard(session, 'all'))}
              </div>
            </div>
          )}

          {allSessions.length === 0 && mySessions.length === 0 && joinedSessions.length === 0 && (
            <div className="text-center py-12">
              <Calendar size={48} className="mx-auto mb-4 text-gray-300" />
              <p className="text-gray-600 text-lg">No sessions available. Create one to get started!</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
