import React, { useEffect, useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { supabase } from '../lib/supabase';
import { SwapRequest, User, Skill } from '../types';
import { CheckCircle, XCircle, Clock, User as UserIcon } from 'lucide-react';
import { Link } from 'react-router-dom';

export const SwapRequests: React.FC = () => {
  const { user } = useAuth();
  const [incomingRequests, setIncomingRequests] = useState<SwapRequest[]>([]);
  const [outgoingRequests, setOutgoingRequests] = useState<SwapRequest[]>([]);
  const [completedSwaps, setCompletedSwaps] = useState<SwapRequest[]>([]);
  const [loading, setLoading] = useState(true);
  const [showNewRequest, setShowNewRequest] = useState(false);
  const [selectedUser, setSelectedUser] = useState<string>('');
  const [formData, setFormData] = useState({
    skillOffered: '',
    skillWanted: '',
    message: '',
    sessionType: 'online' as 'online' | 'in-person',
    proposedDate: '',
  });

  useEffect(() => {
    if (user) {
      loadRequests();
    }
  }, [user]);

  const loadRequests = async () => {
    if (!user) return;

    setLoading(true);
    try {
      const { data: incoming } = await supabase
        .from('swap_requests')
        .select('*, requester:requester_id(id, username, profile_picture_url), skill_offered:skill_offered_id(*), skill_wanted:skill_wanted_id(*)')
        .eq('recipient_id', user.id)
        .eq('status', 'pending')
        .order('created_at', { ascending: false });

      const { data: outgoing } = await supabase
        .from('swap_requests')
        .select('*, recipient:recipient_id(id, username, profile_picture_url), skill_offered:skill_offered_id(*), skill_wanted:skill_wanted_id(*)')
        .eq('requester_id', user.id)
        .eq('status', 'pending')
        .order('created_at', { ascending: false });

      const { data: completed } = await supabase
        .from('swap_requests')
        .select('*, requester:requester_id(*), recipient:recipient_id(*), skill_offered:skill_offered_id(*), skill_wanted:skill_wanted_id(*)')
        .or(`requester_id.eq.${user.id},recipient_id.eq.${user.id}`)
        .in('status', ['accepted', 'completed'])
        .order('updated_at', { ascending: false })
        .limit(10);

      setIncomingRequests((incoming as any) || []);
      setOutgoingRequests((outgoing as any) || []);
      setCompletedSwaps((completed as any) || []);
    } finally {
      setLoading(false);
    }
  };

  const handleAccept = async (requestId: string) => {
    try {
      await supabase
        .from('swap_requests')
        .update({ status: 'accepted' })
        .eq('id', requestId);

      loadRequests();
    } catch (err) {
      console.error('Error accepting request:', err);
    }
  };

  const handleDecline = async (requestId: string) => {
    try {
      await supabase
        .from('swap_requests')
        .update({ status: 'declined' })
        .eq('id', requestId);

      loadRequests();
    } catch (err) {
      console.error('Error declining request:', err);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-6xl mx-auto px-4">
        <div className="flex items-center justify-between mb-8">
          <h1 className="text-3xl font-bold text-gray-900">Skill Swap Requests</h1>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Incoming Requests */}
          <div className="lg:col-span-2 bg-white rounded-lg shadow-md p-6">
            <div className="flex items-center gap-2 mb-6">
              <Clock className="text-blue-600" size={24} />
              <h2 className="text-2xl font-bold text-gray-900">Incoming Requests</h2>
              {incomingRequests.length > 0 && (
                <span className="ml-auto bg-blue-100 text-blue-700 px-3 py-1 rounded-full text-sm font-semibold">
                  {incomingRequests.length}
                </span>
              )}
            </div>

            {incomingRequests.length > 0 ? (
              <div className="space-y-4">
                {incomingRequests.map((request) => (
                  <div key={request.id} className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition">
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex items-center gap-3">
                        <div className="w-12 h-12 bg-gradient-to-br from-blue-400 to-blue-600 rounded-full flex items-center justify-center text-white font-bold">
                          {request.requester?.username?.[0]?.toUpperCase() || 'U'}
                        </div>
                        <div>
                          <Link
                            to={`/profile/${request.requester_id}`}
                            className="font-semibold text-gray-900 hover:text-blue-600 transition"
                          >
                            {request.requester?.username}
                          </Link>
                          <p className="text-sm text-gray-600">wants to swap</p>
                        </div>
                      </div>
                    </div>

                    <div className="bg-gray-50 rounded-lg p-3 mb-3 space-y-2">
                      <p className="text-sm">
                        <span className="font-semibold text-gray-900">Offers to teach:</span>{' '}
                        <span className="text-gray-600">{request.skill_offered?.name}</span>
                      </p>
                      <p className="text-sm">
                        <span className="font-semibold text-gray-900">Wants to learn:</span>{' '}
                        <span className="text-gray-600">{request.skill_wanted?.name}</span>
                      </p>
                      {request.message && (
                        <p className="text-sm text-gray-600 italic">"{request.message}"</p>
                      )}
                      <p className="text-xs text-gray-500">
                        {request.session_type === 'online' ? '💻 Online' : '📍 In-person'} •{' '}
                        {request.proposed_date ? new Date(request.proposed_date).toLocaleDateString() : 'Flexible'}
                      </p>
                    </div>

                    <div className="flex gap-2">
                      <button
                        onClick={() => handleAccept(request.id)}
                        className="flex-1 flex items-center justify-center gap-2 bg-green-600 text-white py-2 rounded-lg hover:bg-green-700 transition font-semibold"
                      >
                        <CheckCircle size={18} />
                        Accept
                      </button>
                      <button
                        onClick={() => handleDecline(request.id)}
                        className="flex-1 flex items-center justify-center gap-2 bg-red-600 text-white py-2 rounded-lg hover:bg-red-700 transition font-semibold"
                      >
                        <XCircle size={18} />
                        Decline
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-12 text-gray-500">
                <Clock size={32} className="mx-auto mb-2 opacity-50" />
                <p>No incoming requests</p>
              </div>
            )}
          </div>

          {/* Stats Sidebar */}
          <div className="space-y-6">
            {/* Summary Stats */}
            <div className="bg-white rounded-lg shadow-md p-6">
              <h3 className="font-semibold text-gray-900 mb-4">Summary</h3>
              <div className="space-y-4">
                <div>
                  <p className="text-sm text-gray-600">Pending Requests</p>
                  <p className="text-2xl font-bold text-blue-600">{incomingRequests.length}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-600">Awaiting Response</p>
                  <p className="text-2xl font-bold text-orange-600">{outgoingRequests.length}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-600">Completed</p>
                  <p className="text-2xl font-bold text-green-600">{completedSwaps.length}</p>
                </div>
              </div>
            </div>

            {/* Outgoing Requests */}
            {outgoingRequests.length > 0 && (
              <div className="bg-white rounded-lg shadow-md p-6">
                <h3 className="font-semibold text-gray-900 mb-4">Awaiting Response</h3>
                <div className="space-y-3">
                  {outgoingRequests.map((request) => (
                    <div key={request.id} className="p-3 bg-orange-50 rounded-lg border border-orange-200">
                      <p className="font-semibold text-gray-900 text-sm">{request.recipient?.username}</p>
                      <p className="text-xs text-gray-600 mt-1">
                        {request.skill_offered?.name} → {request.skill_wanted?.name}
                      </p>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Completed Swaps */}
        {completedSwaps.length > 0 && (
          <div className="mt-8 bg-white rounded-lg shadow-md p-6">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">Recent Activity</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {completedSwaps.map((swap) => (
                <div key={swap.id} className="border border-gray-200 rounded-lg p-4">
                  <div className="flex items-center gap-2 mb-2">
                    <CheckCircle size={18} className="text-green-600" />
                    <span className="font-semibold text-gray-900 text-sm">Swap {swap.status === 'completed' ? 'Completed' : 'Accepted'}</span>
                  </div>
                  <p className="text-sm text-gray-600 mb-2">
                    {swap.requester_id === user?.id ? swap.recipient?.username : swap.requester?.username}
                  </p>
                  <p className="text-xs text-gray-500">
                    {swap.skill_offered?.name} ↔ {swap.skill_wanted?.name}
                  </p>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
