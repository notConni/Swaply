import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { supabase } from '../lib/supabase';
import { SkillSwap, Notification, Message } from '../types';
import { Bell, MessageSquare, Users, CheckCircle, Clock } from 'lucide-react';

export const Dashboard: React.FC = () => {
  const { user, profile } = useAuth();
  const [pendingSwaps, setPendingSwaps] = useState<SkillSwap[]>([]);
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [unreadMessages, setUnreadMessages] = useState<Message[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user) {
      loadDashboardData();
      const interval = setInterval(loadDashboardData, 5000);
      return () => clearInterval(interval);
    }
  }, [user]);

  const loadDashboardData = async () => {
    if (!user) return;

    try {
      const { data: swaps } = await supabase
        .from('skill_swaps')
        .select('*')
        .or(`initiator_id.eq.${user.id},recipient_id.eq.${user.id}`)
        .eq('status', 'pending')
        .order('created_at', { ascending: false })
        .limit(5);

      setPendingSwaps(swaps || []);

      const { data: notifs } = await supabase
        .from('notifications')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false })
        .limit(10);

      setNotifications(notifs || []);

      const { data: msgs } = await supabase
        .from('messages')
        .select('*')
        .eq('recipient_id', user.id)
        .eq('is_read', false)
        .order('created_at', { ascending: false })
        .limit(5);

      setUnreadMessages(msgs || []);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4">
        {/* Welcome Section */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">
            Welcome back, {profile?.username}!
          </h1>
          <p className="text-gray-600 mt-2">Manage your skill swaps and connect with learning partners</p>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="flex items-center gap-4">
              <div className="bg-blue-100 p-3 rounded-lg">
                <Users className="text-blue-600" size={24} />
              </div>
              <div>
                <p className="text-gray-600 text-sm">Learning Partners</p>
                <p className="text-2xl font-bold text-gray-900">
                  {profile?.average_rating.toFixed(1) || 0}
                </p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="flex items-center gap-4">
              <div className="bg-green-100 p-3 rounded-lg">
                <CheckCircle className="text-green-600" size={24} />
              </div>
              <div>
                <p className="text-gray-600 text-sm">Completed Swaps</p>
                <p className="text-2xl font-bold text-gray-900">{profile?.total_reviews || 0}</p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="flex items-center gap-4">
              <div className="bg-purple-100 p-3 rounded-lg">
                <Clock className="text-purple-600" size={24} />
              </div>
              <div>
                <p className="text-gray-600 text-sm">Pending Requests</p>
                <p className="text-2xl font-bold text-gray-900">{pendingSwaps.length}</p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="flex items-center gap-4">
              <div className="bg-orange-100 p-3 rounded-lg">
                <MessageSquare className="text-orange-600" size={24} />
              </div>
              <div>
                <p className="text-gray-600 text-sm">Unread Messages</p>
                <p className="text-2xl font-bold text-gray-900">{unreadMessages.length}</p>
              </div>
            </div>
          </div>
        </div>

        {/* Main Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Left Column */}
          <div className="lg:col-span-2 space-y-8">
            {/* Pending Skill Swap Requests */}
            <div className="bg-white rounded-lg shadow-md p-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-bold text-gray-900">Pending Requests</h2>
                {pendingSwaps.length > 0 && (
                  <span className="bg-orange-100 text-orange-700 px-3 py-1 rounded-full text-sm font-semibold">
                    {pendingSwaps.length} New
                  </span>
                )}
              </div>

              {pendingSwaps.length > 0 ? (
                <div className="space-y-4">
                  {pendingSwaps.map((swap) => (
                    <div
                      key={swap.id}
                      className="flex items-start justify-between p-4 bg-gray-50 rounded-lg border border-gray-200 hover:bg-gray-100 transition"
                    >
                      <div>
                        <p className="font-semibold text-gray-900">
                          Skill Swap Request
                        </p>
                        <p className="text-sm text-gray-600 mt-1">
                          {swap.notes || 'No description provided'}
                        </p>
                        {swap.proposed_date && (
                          <p className="text-sm text-gray-600 mt-1">
                            Proposed: {new Date(swap.proposed_date).toLocaleDateString()}
                          </p>
                        )}
                      </div>
                      <Link
                        to={`/profile/${swap.initiator_id === user?.id ? swap.recipient_id : swap.initiator_id}`}
                        className="text-blue-600 hover:text-blue-700 font-semibold text-sm"
                      >
                        View
                      </Link>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8 text-gray-500">
                  <Clock size={32} className="mx-auto mb-2 opacity-50" />
                  <p>No pending requests</p>
                </div>
              )}
            </div>

            {/* Recent Activity */}
            <div className="bg-white rounded-lg shadow-md p-6">
              <h2 className="text-2xl font-bold text-gray-900 mb-6">Quick Actions</h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <Link
                  to="/search"
                  className="block p-4 bg-gradient-to-br from-blue-50 to-blue-100 rounded-lg border border-blue-200 hover:border-blue-400 transition"
                >
                  <div className="font-semibold text-gray-900">Find Learning Partners</div>
                  <p className="text-sm text-gray-600 mt-1">Search for users with complementary skills</p>
                </Link>

                <Link
                  to="/skills"
                  className="block p-4 bg-gradient-to-br from-green-50 to-green-100 rounded-lg border border-green-200 hover:border-green-400 transition"
                >
                  <div className="font-semibold text-gray-900">Manage Skills</div>
                  <p className="text-sm text-gray-600 mt-1">Update what you can teach and want to learn</p>
                </Link>

                <Link
                  to="/messages"
                  className="block p-4 bg-gradient-to-br from-purple-50 to-purple-100 rounded-lg border border-purple-200 hover:border-purple-400 transition"
                >
                  <div className="font-semibold text-gray-900">Messages</div>
                  <p className="text-sm text-gray-600 mt-1">Check your conversations</p>
                </Link>

                <Link
                  to={`/profile/${user?.id}`}
                  className="block p-4 bg-gradient-to-br from-orange-50 to-orange-100 rounded-lg border border-orange-200 hover:border-orange-400 transition"
                >
                  <div className="font-semibold text-gray-900">My Profile</div>
                  <p className="text-sm text-gray-600 mt-1">View your profile and reviews</p>
                </Link>
              </div>
            </div>
          </div>

          {/* Right Column */}
          <div className="space-y-8">
            {/* Notifications */}
            <div className="bg-white rounded-lg shadow-md p-6">
              <div className="flex items-center gap-2 mb-6">
                <Bell size={24} className="text-blue-600" />
                <h2 className="text-2xl font-bold text-gray-900">Notifications</h2>
              </div>

              {notifications.length > 0 ? (
                <div className="space-y-3 max-h-96 overflow-y-auto">
                  {notifications.map((notif) => (
                    <div
                      key={notif.id}
                      className={`p-3 rounded-lg border ${
                        notif.is_read
                          ? 'bg-gray-50 border-gray-200'
                          : 'bg-blue-50 border-blue-200'
                      }`}
                    >
                      <p className="font-semibold text-gray-900 text-sm">{notif.title}</p>
                      <p className="text-xs text-gray-600 mt-1">{notif.message}</p>
                      <p className="text-xs text-gray-500 mt-2">
                        {new Date(notif.created_at).toLocaleDateString()}
                      </p>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8 text-gray-500">
                  <Bell size={32} className="mx-auto mb-2 opacity-50" />
                  <p>No notifications yet</p>
                </div>
              )}
            </div>

            {/* Profile Summary */}
            <div className="bg-white rounded-lg shadow-md p-6">
              <h2 className="text-xl font-bold text-gray-900 mb-4">Profile Summary</h2>
              <div className="space-y-3">
                <div>
                  <p className="text-sm text-gray-600">Username</p>
                  <p className="font-semibold text-gray-900">{profile?.username}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-600">Location</p>
                  <p className="font-semibold text-gray-900">
                    {profile?.city || 'Not specified'}
                  </p>
                </div>
                <div>
                  <p className="text-sm text-gray-600">Member Since</p>
                  <p className="font-semibold text-gray-900">
                    {profile?.created_at
                      ? new Date(profile.created_at).toLocaleDateString()
                      : 'N/A'}
                  </p>
                </div>
                <Link
                  to={`/profile/${user?.id}`}
                  className="inline-block mt-4 text-blue-600 hover:text-blue-700 font-semibold"
                >
                  Edit Profile →
                </Link>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
