import React, { useEffect, useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { supabase } from '../lib/supabase';
import { User, Message } from '../types';
import { Send, MessageCircle } from 'lucide-react';
import { useSearchParams } from 'react-router-dom';

export const Messages: React.FC = () => {
  const { user } = useAuth();
  const [searchParams] = useSearchParams();
  const initialUserId = searchParams.get('user');

  const [conversations, setConversations] = useState<User[]>([]);
  const [selectedUser, setSelectedUser] = useState<User | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [loading, setLoading] = useState(true);
  const [allUsers, setAllUsers] = useState<Map<string, User>>(new Map());

  useEffect(() => {
    if (user) {
      loadConversations();
      if (initialUserId) {
        loadUser(initialUserId);
      }
    }
  }, [user, initialUserId]);

  const loadConversations = async () => {
    if (!user) return;

    setLoading(true);
    try {
      const { data: messageData } = await supabase
        .from('messages')
        .select('sender_id, recipient_id')
        .or(`sender_id.eq.${user.id},recipient_id.eq.${user.id}`)
        .order('created_at', { ascending: false });

      if (messageData) {
        const userIds = new Set<string>();
        messageData.forEach((msg) => {
          if (msg.sender_id === user.id) {
            userIds.add(msg.recipient_id);
          } else {
            userIds.add(msg.sender_id);
          }
        });

        const { data: users } = await supabase
          .from('users')
          .select('*')
          .in('id', Array.from(userIds));

        if (users) {
          setConversations(users);
          const usersMap = new Map(users.map((u) => [u.id, u]));
          setAllUsers(usersMap);
        }
      }
    } finally {
      setLoading(false);
    }
  };

  const loadUser = async (userId: string) => {
    try {
      const { data } = await supabase.from('users').select('*').eq('id', userId).single();
      if (data) {
        setSelectedUser(data);
        loadMessages(userId);
      }
    } catch (err) {
      console.error('Error loading user:', err);
    }
  };

  const loadMessages = async (recipientId: string) => {
    if (!user) return;

    try {
      const { data } = await supabase
        .from('messages')
        .select('*')
        .or(
          `and(sender_id.eq.${user.id},recipient_id.eq.${recipientId}),and(sender_id.eq.${recipientId},recipient_id.eq.${user.id})`
        )
        .order('created_at', { ascending: true });

      setMessages(data || []);

      await supabase
        .from('messages')
        .update({ is_read: true })
        .eq('recipient_id', user.id)
        .eq('sender_id', recipientId);
    } catch (err) {
      console.error('Error loading messages:', err);
    }
  };

  const handleSelectUser = (u: User) => {
    setSelectedUser(u);
    loadMessages(u.id);
  };

  const handleSendMessage = async () => {
    if (!user || !selectedUser || !newMessage.trim()) return;

    try {
      await supabase.from('messages').insert([
        {
          sender_id: user.id,
          recipient_id: selectedUser.id,
          content: newMessage,
        },
      ]);

      setNewMessage('');
      loadMessages(selectedUser.id);

      if (!conversations.some((c) => c.id === selectedUser.id)) {
        setConversations((prev) => [selectedUser, ...prev]);
      }
    } catch (err) {
      console.error('Error sending message:', err);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-6xl mx-auto px-4">
        <h1 className="text-3xl font-bold text-gray-900 mb-8">Messages</h1>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 h-[600px]">
          {/* Conversations List */}
          <div className="bg-white rounded-lg shadow-md overflow-hidden flex flex-col">
            <div className="p-4 border-b border-gray-200">
              <h2 className="font-semibold text-gray-900">Conversations</h2>
            </div>

            <div className="flex-1 overflow-y-auto">
              {conversations.length > 0 ? (
                conversations.map((c) => (
                  <button
                    key={c.id}
                    onClick={() => handleSelectUser(c)}
                    className={`w-full p-4 border-b border-gray-100 text-left hover:bg-gray-50 transition ${
                      selectedUser?.id === c.id ? 'bg-blue-50' : ''
                    }`}
                  >
                    <p className="font-medium text-gray-900">{c.username}</p>
                    <p className="text-sm text-gray-600 truncate">{c.bio || 'No bio'}</p>
                  </button>
                ))
              ) : (
                <div className="p-4 text-center text-gray-500">
                  <MessageCircle size={32} className="mx-auto mb-2 opacity-50" />
                  <p>No conversations yet</p>
                </div>
              )}
            </div>
          </div>

          {/* Chat Area */}
          <div className="md:col-span-2 bg-white rounded-lg shadow-md overflow-hidden flex flex-col">
            {selectedUser ? (
              <>
                {/* Chat Header */}
                <div className="p-4 border-b border-gray-200">
                  <p className="font-semibold text-gray-900">{selectedUser.username}</p>
                  <p className="text-sm text-gray-600">{selectedUser.city || 'No location'}</p>
                </div>

                {/* Messages */}
                <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-gray-50">
                  {messages.length > 0 ? (
                    messages.map((msg) => (
                      <div
                        key={msg.id}
                        className={`flex ${msg.sender_id === user?.id ? 'justify-end' : 'justify-start'}`}
                      >
                        <div
                          className={`max-w-xs px-4 py-2 rounded-lg ${
                            msg.sender_id === user?.id
                              ? 'bg-blue-600 text-white'
                              : 'bg-gray-300 text-gray-900'
                          }`}
                        >
                          <p className="break-words">{msg.content}</p>
                          <p
                            className={`text-xs mt-1 ${
                              msg.sender_id === user?.id
                                ? 'text-blue-100'
                                : 'text-gray-600'
                            }`}
                          >
                            {new Date(msg.created_at).toLocaleTimeString([], {
                              hour: '2-digit',
                              minute: '2-digit',
                            })}
                          </p>
                        </div>
                      </div>
                    ))
                  ) : (
                    <div className="text-center text-gray-500 py-12">
                      <MessageCircle size={32} className="mx-auto mb-2 opacity-50" />
                      <p>No messages yet. Start a conversation!</p>
                    </div>
                  )}
                </div>

                {/* Message Input */}
                <div className="p-4 border-t border-gray-200">
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={newMessage}
                      onChange={(e) => setNewMessage(e.target.value)}
                      onKeyPress={(e) => {
                        if (e.key === 'Enter') {
                          handleSendMessage();
                        }
                      }}
                      placeholder="Type a message..."
                      className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none transition"
                    />
                    <button
                      onClick={handleSendMessage}
                      disabled={!newMessage.trim()}
                      className="bg-blue-600 text-white p-2 rounded-lg hover:bg-blue-700 transition disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      <Send size={20} />
                    </button>
                  </div>
                </div>
              </>
            ) : (
              <div className="flex items-center justify-center h-full text-gray-500">
                <div className="text-center">
                  <MessageCircle size={48} className="mx-auto mb-4 opacity-50" />
                  <p>Select a conversation to start messaging</p>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
