export interface User {
  id: string;
  username: string;
  email: string;
  bio: string;
  profile_picture_url: string | null;
  city: string;
  country: string;
  average_rating: number;
  total_reviews: number;
  reputation_points: number;
  latitude: number | null;
  longitude: number | null;
  session_preference: 'online' | 'in-person' | 'both';
  is_public: boolean;
  created_at: string;
  updated_at: string;
}

export interface Skill {
  id: string;
  name: string;
  description: string;
  category: string;
  created_at: string;
}

export interface UserSkillOffered {
  id: string;
  user_id: string;
  skill_id: string;
  proficiency_level: 'beginner' | 'intermediate' | 'advanced' | 'expert';
  years_of_experience: number;
  description: string;
  created_at: string;
  skill?: Skill;
}

export interface UserSkillWanted {
  id: string;
  user_id: string;
  skill_id: string;
  priority: number;
  created_at: string;
  skill?: Skill;
}

export interface SkillSwap {
  id: string;
  initiator_id: string;
  recipient_id: string;
  skill_offered_id: string;
  skill_wanted_id: string;
  status: 'pending' | 'accepted' | 'completed' | 'cancelled';
  proposed_date: string | null;
  notes: string;
  created_at: string;
  updated_at: string;
  initiator?: User;
  recipient?: User;
  skill_offered?: Skill;
  skill_wanted?: Skill;
}

export interface Message {
  id: string;
  sender_id: string;
  recipient_id: string;
  swap_id: string | null;
  content: string;
  is_read: boolean;
  created_at: string;
  sender?: User;
  recipient?: User;
}

export interface Review {
  id: string;
  reviewer_id: string;
  reviewed_user_id: string;
  swap_id: string;
  rating: number;
  comment: string;
  created_at: string;
  reviewer?: User;
}

export interface Notification {
  id: string;
  user_id: string;
  type: string;
  title: string;
  message: string;
  related_user_id: string | null;
  related_swap_id: string | null;
  is_read: boolean;
  created_at: string;
  related_user?: User;
}

export interface Match {
  user: User;
  userOfferedSkill: UserSkillOffered;
  userWantedSkill: UserSkillWanted;
  matchScore: number;
}

export interface Follower {
  id: string;
  follower_id: string;
  following_id: string;
  created_at: string;
  follower?: User;
  following?: User;
}

export interface Connection {
  id: string;
  user_id_1: string;
  user_id_2: string;
  created_at: string;
  user1?: User;
  user2?: User;
}

export interface ConnectionRequest {
  id: string;
  requester_id: string;
  recipient_id: string;
  message: string;
  status: 'pending' | 'accepted' | 'declined';
  created_at: string;
  updated_at: string;
  requester?: User;
  recipient?: User;
}

export interface SwapRequest {
  id: string;
  requester_id: string;
  recipient_id: string;
  skill_offered_id: string;
  skill_wanted_id: string;
  message: string;
  session_type: 'online' | 'in-person';
  proposed_date: string | null;
  proposed_time: string | null;
  status: 'pending' | 'accepted' | 'declined' | 'completed';
  created_at: string;
  updated_at: string;
  requester?: User;
  recipient?: User;
  skill_offered?: Skill;
  skill_wanted?: Skill;
}

export interface Session {
  id: string;
  title: string;
  description: string;
  skill_id: string;
  creator_id: string;
  session_type: 'online' | 'in-person';
  scheduled_date: string;
  scheduled_time: string;
  duration_minutes: number;
  location: string | null;
  max_participants: number;
  status: 'scheduled' | 'in-progress' | 'completed' | 'cancelled';
  created_at: string;
  updated_at: string;
  skill?: Skill;
  creator?: User;
  participants?: SessionParticipant[];
}

export interface SessionParticipant {
  id: string;
  session_id: string;
  user_id: string;
  role: 'teacher' | 'learner';
  joined_at: string;
  user?: User;
}

export interface GroupSwap {
  id: string;
  title: string;
  description: string;
  creator_id: string;
  skill_focus_id: string | null;
  session_type: 'online' | 'in-person';
  max_members: number;
  location: string | null;
  scheduled_date: string | null;
  scheduled_time: string | null;
  status: 'open' | 'in-progress' | 'completed' | 'cancelled';
  created_at: string;
  updated_at: string;
  creator?: User;
  skill?: Skill;
  members?: User[];
}

export interface Badge {
  id: string;
  name: string;
  description: string;
  icon_name: string;
  requirement: string;
  created_at: string;
}

export interface UserBadge {
  id: string;
  user_id: string;
  badge_id: string;
  earned_at: string;
  badge?: Badge;
}

export interface ReputationHistory {
  id: string;
  user_id: string;
  points: number;
  reason: string;
  related_swap_id: string | null;
  created_at: string;
}

export interface LearningProgress {
  id: string;
  user_id: string;
  skill_id: string;
  proficiency_level: 'beginner' | 'intermediate' | 'advanced' | 'expert';
  swaps_completed: number;
  total_hours_learned: number;
  last_practiced_at: string | null;
  created_at: string;
  updated_at: string;
  skill?: Skill;
}

export interface ActivityFeed {
  id: string;
  user_id: string;
  activity_type: string;
  actor_id: string | null;
  content: string;
  related_skill_id: string | null;
  related_swap_id: string | null;
  is_public: boolean;
  created_at: string;
  user?: User;
  actor?: User;
  skill?: Skill;
}

export interface MatchRecommendation {
  userId: string;
  username: string;
  profilePictureUrl: string | null;
  matchScore: number;
  matchReason: string;
  userOfferedSkills: string[];
  userWantedSkills: string[];
}
