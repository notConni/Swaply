export interface User {
  id: string;
  username: string;
  email: string;
  bio: string;
  profile_picture_url: string | null;
  city: string;
  country: string;
  average_rating: number;
  total_reviews: number;
  created_at: string;
  updated_at: string;
}

export interface Skill {
  id: string;
  name: string;
  description: string;
  category: string;
  created_at: string;
}

export interface UserSkillOffered {
  id: string;
  user_id: string;
  skill_id: string;
  proficiency_level: 'beginner' | 'intermediate' | 'advanced' | 'expert';
  years_of_experience: number;
  description: string;
  created_at: string;
  skill?: Skill;
}

export interface UserSkillWanted {
  id: string;
  user_id: string;
  skill_id: string;
  priority: number;
  created_at: string;
  skill?: Skill;
}

export interface SkillSwap {
  id: string;
  initiator_id: string;
  recipient_id: string;
  skill_offered_id: string;
  skill_wanted_id: string;
  status: 'pending' | 'accepted' | 'completed' | 'cancelled';
  proposed_date: string | null;
  notes: string;
  created_at: string;
  updated_at: string;
  initiator?: User;
  recipient?: User;
  skill_offered?: Skill;
  skill_wanted?: Skill;
}

export interface Message {
  id: string;
  sender_id: string;
  recipient_id: string;
  swap_id: string | null;
  content: string;
  is_read: boolean;
  created_at: string;
  sender?: User;
  recipient?: User;
}

export interface Review {
  id: string;
  reviewer_id: string;
  reviewed_user_id: string;
  swap_id: string;
  rating: number;
  comment: string;
  created_at: string;
  reviewer?: User;
}

export interface Notification {
  id: string;
  user_id: string;
  type: string;
  title: string;
  message: string;
  related_user_id: string | null;
  related_swap_id: string | null;
  is_read: boolean;
  created_at: string;
  related_user?: User;
}

export interface Match {
  user: User;
  userOfferedSkill: UserSkillOffered;
  userWantedSkill: UserSkillWanted;
  matchScore: number;
}
