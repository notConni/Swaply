import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { Menu, X, LogOut, User, MessageSquare } from 'lucide-react';

export const Header: React.FC = () => {
  const { user, profile, signOut } = useAuth();
  const [menuOpen, setMenuOpen] = useState(false);

  const handleSignOut = async () => {
    await signOut();
    setMenuOpen(false);
  };

  return (
    <header className="bg-white shadow-md sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
        <Link to="/" className="flex items-center space-x-2">
          <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-blue-800 rounded-lg flex items-center justify-center">
            <span className="text-white font-bold text-lg">SS</span>
          </div>
          <span className="font-bold text-xl hidden sm:inline text-gray-900">Skill Swap</span>
        </Link>

        <nav className="hidden md:flex items-center space-x-8">
          {user ? (
            <>
              <Link to="/search" className="text-gray-600 hover:text-blue-600 transition">
                Search Skills
              </Link>
              <Link to="/dashboard" className="text-gray-600 hover:text-blue-600 transition">
                Dashboard
              </Link>
              <Link to="/messages" className="text-gray-600 hover:text-blue-600 transition flex items-center space-x-1">
                <MessageSquare size={20} />
                <span>Messages</span>
              </Link>
              <Link to={`/profile/${user.id}`} className="text-gray-600 hover:text-blue-600 transition flex items-center space-x-1">
                <User size={20} />
                <span>{profile?.username}</span>
              </Link>
              <button
                onClick={handleSignOut}
                className="text-red-600 hover:text-red-700 transition flex items-center space-x-1"
              >
                <LogOut size={20} />
                <span>Sign Out</span>
              </button>
            </>
          ) : (
            <>
              <Link
                to="/login"
                className="text-gray-600 hover:text-blue-600 transition font-medium"
              >
                Login
              </Link>
              <Link
                to="/register"
                className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition font-medium"
              >
                Get Started
              </Link>
            </>
          )}
        </nav>

        <button
          className="md:hidden"
          onClick={() => setMenuOpen(!menuOpen)}
        >
          {menuOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {menuOpen && (
        <div className="md:hidden bg-white border-t border-gray-200">
          <div className="px-4 py-4 space-y-4">
            {user ? (
              <>
                <Link
                  to="/search"
                  className="block text-gray-600 hover:text-blue-600 transition"
                  onClick={() => setMenuOpen(false)}
                >
                  Search Skills
                </Link>
                <Link
                  to="/dashboard"
                  className="block text-gray-600 hover:text-blue-600 transition"
                  onClick={() => setMenuOpen(false)}
                >
                  Dashboard
                </Link>
                <Link
                  to="/messages"
                  className="block text-gray-600 hover:text-blue-600 transition"
                  onClick={() => setMenuOpen(false)}
                >
                  Messages
                </Link>
                <Link
                  to={`/profile/${user.id}`}
                  className="block text-gray-600 hover:text-blue-600 transition"
                  onClick={() => setMenuOpen(false)}
                >
                  My Profile
                </Link>
                <button
                  onClick={handleSignOut}
                  className="block w-full text-left text-red-600 hover:text-red-700 transition"
                >
                  Sign Out
                </button>
              </>
            ) : (
              <>
                <Link
                  to="/login"
                  className="block text-gray-600 hover:text-blue-600 transition"
                  onClick={() => setMenuOpen(false)}
                >
                  Login
                </Link>
                <Link
                  to="/register"
                  className="block bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition text-center"
                  onClick={() => setMenuOpen(false)}
                >
                  Get Started
                </Link>
              </>
            )}
          </div>
        </div>
      )}
    </header>
  );
};
