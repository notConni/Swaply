# SkillSwap - Skill Exchange Platform

## Overview
A React + Vite + TypeScript single-page application for skill swapping and social learning. Users can register, list skills they offer/want to learn, request skill swaps, and engage socially through the platform.

## Tech Stack
- **Frontend**: React 18, TypeScript, Vite 5
- **Styling**: Tailwind CSS
- **Routing**: React Router DOM v6
- **Backend/Database**: Supabase (PostgreSQL + Auth + Edge Functions)
- **Icons**: Lucide React

## Project Structure
```
src/
  components/
    Header.tsx           - Navigation with live notification badges for pending swap requests & unread messages
    SwapRequestModal.tsx - Modal for sending swap requests (skill selection + optional message)
    SocialActions.tsx    - Follow/connect social actions
    BadgeDisplay.tsx     - User achievement badges
    ProtectedRoute.tsx   - Auth guard
  context/
    AuthContext.tsx      - Auth state + profile management
  lib/
    supabase.ts         - Supabase client
  pages/
    Dashboard.tsx       - Main dashboard with inline accept/decline for incoming swap requests
    SwapRequests.tsx    - Full swap request management (4 tabs: Incoming, Sent, Accepted, History)
    Profile.tsx         - User profile with "Request Swap" button for other users
    Search.tsx          - Find partners with "Request Swap" button on each user card
    Skills.tsx          - Manage offered/wanted skills
    Messages.tsx        - Real-time messaging
    Sessions.tsx        - Session scheduling
    ReputationProgress.tsx - Reputation/badges
    SearchAdvanced.tsx  - Advanced search
    Home.tsx / Login.tsx / Register.tsx
supabase/
  migrations/   - SQL migrations for database schema
  functions/    - Edge Functions (handle_skill_swap, get_learning_suggestions, get_skill_recommendations)
```

## Swap Request System
- **Send requests**: From Search page (card button) or Profile page ("Request Swap" button)
- **Request form**: Select your offered skill + their skill you want to learn + optional message + session type
- **Status flow**: pending → accepted/declined → (accepted) completed
- **Notifications**: Auto-created when a request is accepted or declined
- **Dashboard**: Shows incoming requests with inline Accept/Decline + active accepted swaps with Chat button
- **SwapRequests page**: Tabbed view (Incoming | Sent | Accepted | History) with full detail cards
- **Header**: Live badge counts for pending requests and unread messages (polls every 15s)

## Environment Variables
- `VITE_SUPABASE_URL` - Supabase project URL
- `VITE_SUPABASE_ANON_KEY` - Supabase anonymous key

## Development
- Workflow: `npm run dev` on port 5000
- The Vite dev server is configured to run on `0.0.0.0:5000` with `allowedHosts: true` for Replit proxy compatibility

## Deployment
- Static site deployment via `npm run build` → `dist/` directory
