import React, { useState } from 'react';
import { Star, X, Send } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../context/AuthContext';
import { SwapRequest } from '../types';

interface Props {
  swap: SwapRequest;
  reviewedUserId: string;
  reviewedUsername: string;
  onClose: () => void;
  onSubmitted: () => void;
}

const RATING_LABELS = ['', 'Poor', 'Fair', 'Good', 'Great', 'Excellent'];

export const ReviewModal: React.FC<Props> = ({
  swap,
  reviewedUserId,
  reviewedUsername,
  onClose,
  onSubmitted,
}) => {
  const { user } = useAuth();
  const [rating, setRating]     = useState(0);
  const [hovered, setHovered]   = useState(0);
  const [comment, setComment]   = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [error, setError]       = useState('');

  const handleSubmit = async () => {
    if (!user || rating === 0) {
      setError('Please select a star rating.');
      return;
    }

    setSubmitting(true);
    setError('');

    try {
      const { error: insertErr } = await supabase
        .from('swap_request_reviews')
        .insert([{
          swap_request_id: swap.id,
          reviewer_id: user.id,
          reviewed_user_id: reviewedUserId,
          rating,
          comment: comment.trim(),
        }]);

      if (insertErr) {
        if (insertErr.code === '23505') {
          setError('You have already reviewed this swap.');
          return;
        }
        throw insertErr;
      }

      const { data: reviewedUser } = await supabase
        .from('users')
        .select('average_rating, total_reviews, reputation_points')
        .eq('id', reviewedUserId)
        .single();

      if (reviewedUser) {
        const currentTotal  = reviewedUser.total_reviews ?? 0;
        const currentAvg    = reviewedUser.average_rating ?? 0;
        const newTotal      = currentTotal + 1;
        const newAvg        = ((currentAvg * currentTotal) + rating) / newTotal;
        const reputationGain = rating * 4;

        await supabase
          .from('users')
          .update({
            average_rating:    Math.round(newAvg * 100) / 100,
            total_reviews:     newTotal,
            reputation_points: (reviewedUser.reputation_points ?? 0) + reputationGain,
            updated_at:        new Date().toISOString(),
          })
          .eq('id', reviewedUserId);

        await supabase.from('reputation_history').insert([{
          user_id: reviewedUserId,
          points:  reputationGain,
          reason:  `Received a ${rating}-star review for a completed swap`,
        }]);

        await supabase.from('notifications').insert([{
          user_id:         reviewedUserId,
          type:            'review_received',
          title:           'You received a new review!',
          message:         `Someone gave you ${rating} star${rating !== 1 ? 's' : ''} after your skill swap.`,
          related_user_id: user.id,
          related_swap_id: null,
        }]);
      }

      onSubmitted();
    } catch (err: any) {
      console.error('Error submitting review:', err);
      setError('Failed to submit review. Please try again.');
    } finally {
      setSubmitting(false);
    }
  };

  const displayRating = hovered || rating;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md overflow-hidden">
        <div className="flex items-center justify-between px-6 py-4 border-b border-gray-100">
          <div>
            <h2 className="text-lg font-bold text-gray-900">Leave a Review</h2>
            <p className="text-sm text-gray-500 mt-0.5">Rate your experience with {reviewedUsername}</p>
          </div>
          <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-gray-100 text-gray-400 hover:text-gray-600 transition">
            <X size={18} />
          </button>
        </div>

        <div className="px-6 py-6 space-y-5">
          <div>
            <p className="text-sm font-semibold text-gray-700 mb-3">How was the swap?</p>
            <div className="flex items-center gap-1.5 mb-1.5">
              {[1, 2, 3, 4, 5].map((star) => (
                <button
                  key={star}
                  onMouseEnter={() => setHovered(star)}
                  onMouseLeave={() => setHovered(0)}
                  onClick={() => setRating(star)}
                  className="focus:outline-none transition-transform active:scale-90"
                >
                  <Star
                    size={38}
                    className={`transition-colors ${
                      star <= displayRating
                        ? 'fill-amber-400 text-amber-400'
                        : 'text-gray-200 fill-gray-200'
                    }`}
                  />
                </button>
              ))}
            </div>
            {displayRating > 0 && (
              <p className="text-sm font-semibold text-amber-600">{RATING_LABELS[displayRating]}</p>
            )}
          </div>

          <div>
            <label className="text-sm font-semibold text-gray-700 mb-2 block">
              Comment <span className="text-gray-400 font-normal">(optional)</span>
            </label>
            <textarea
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              placeholder={`Share what you learned or how ${reviewedUsername} helped you...`}
              rows={4}
              maxLength={500}
              className="w-full px-4 py-3 border border-gray-200 rounded-xl text-sm resize-none focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition"
            />
            <p className="text-xs text-gray-400 text-right mt-1">{comment.length}/500</p>
          </div>

          {error && (
            <div className="bg-red-50 border border-red-200 rounded-lg px-4 py-3">
              <p className="text-sm text-red-600">{error}</p>
            </div>
          )}

          {rating > 0 && (
            <div className="bg-amber-50 border border-amber-100 rounded-xl px-4 py-3 flex items-center gap-2.5">
              <Star size={16} className="fill-amber-400 text-amber-400 flex-shrink-0" />
              <p className="text-xs text-amber-800">
                Your review will award <strong>{rating * 4} reputation points</strong> to {reviewedUsername}.
              </p>
            </div>
          )}
        </div>

        <div className="px-6 py-4 border-t border-gray-100 flex gap-3">
          <button
            onClick={onClose}
            className="flex-1 px-4 py-2.5 border border-gray-200 text-gray-600 rounded-xl text-sm font-semibold hover:bg-gray-50 transition"
          >
            Cancel
          </button>
          <button
            onClick={handleSubmit}
            disabled={rating === 0 || submitting}
            className="flex-1 flex items-center justify-center gap-2 px-4 py-2.5 bg-blue-600 text-white rounded-xl text-sm font-semibold hover:bg-blue-700 transition disabled:opacity-40 disabled:cursor-not-allowed"
          >
            {submitting
              ? <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white" />
              : <><Send size={15} /> Submit Review</>
            }
          </button>
        </div>
      </div>
    </div>
  );
};
