import React, { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
import { UserBadge } from '../types';
import {
  Star,
  Award,
  Trophy,
  Heart,
  Users,
  TrendingUp,
  Calendar,
  UserPlus,
  Zap,
  Link2,
} from 'lucide-react';

interface BadgeDisplayProps {
  userId: string;
}

const iconMap: Record<string, React.ReactNode> = {
  star: <Star size={24} />,
  award: <Award size={24} />,
  trophy: <Trophy size={24} />,
  heart: <Heart size={24} />,
  users: <Users size={24} />,
  'trending-up': <TrendingUp size={24} />,
  calendar: <Calendar size={24} />,
  'user-plus': <UserPlus size={24} />,
  zap: <Zap size={24} />,
  link: <Link2 size={24} />,
};

export const BadgeDisplay: React.FC<BadgeDisplayProps> = ({ userId }) => {
  const [badges, setBadges] = useState<UserBadge[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadBadges();
  }, [userId]);

  const loadBadges = async () => {
    try {
      const { data } = await supabase
        .from('user_badges')
        .select('*, badge:badges(*)')
        .eq('user_id', userId)
        .order('earned_at', { ascending: false });

      setBadges(data || []);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return <div className="text-gray-500 text-sm">Loading badges...</div>;
  }

  if (badges.length === 0) {
    return <p className="text-gray-500 text-sm">No badges earned yet</p>;
  }

  return (
    <div className="space-y-3">
      {badges.map((userBadge) => (
        <div key={userBadge.id} className="flex items-start gap-3 p-3 bg-gradient-to-r from-amber-50 to-orange-50 rounded-lg border border-amber-200">
          <div className="text-amber-600 flex-shrink-0">
            {iconMap[userBadge.badge?.icon_name || 'star'] || <Star size={24} />}
          </div>
          <div className="flex-1">
            <h4 className="font-semibold text-gray-900">{userBadge.badge?.name}</h4>
            <p className="text-sm text-gray-600">{userBadge.badge?.description}</p>
            <p className="text-xs text-gray-500 mt-1">
              Earned: {new Date(userBadge.earned_at).toLocaleDateString()}
            </p>
          </div>
        </div>
      ))}
    </div>
  );
};
