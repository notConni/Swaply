import React, { useEffect, useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { supabase } from '../lib/supabase';
import { Heart, UserPlus, Mail, Share2 } from 'lucide-react';

interface SocialActionsProps {
  userId: string;
  isOwnProfile: boolean;
}

export const SocialActions: React.FC<SocialActionsProps> = ({ userId, isOwnProfile }) => {
  const { user } = useAuth();
  const [isFollowing, setIsFollowing] = useState(false);
  const [isConnected, setIsConnected] = useState(false);
  const [connectionRequestPending, setConnectionRequestPending] = useState(false);
  const [followerCount, setFollowerCount] = useState(0);
  const [followingCount, setFollowingCount] = useState(0);
  const [connectionCount, setConnectionCount] = useState(0);

  useEffect(() => {
    if (user && !isOwnProfile) {
      loadSocialStatus();
    }
    loadCounts();
  }, [user, userId, isOwnProfile]);

  const loadSocialStatus = async () => {
    if (!user) return;

    const { data: following } = await supabase
      .from('followers')
      .select('id')
      .eq('follower_id', user.id)
      .eq('following_id', userId)
      .maybeSingle();

    setIsFollowing(!!following);

    const { data: connection } = await supabase
      .from('connections')
      .select('id')
      .or(`and(user_id_1.eq.${user.id},user_id_2.eq.${userId}),and(user_id_1.eq.${userId},user_id_2.eq.${user.id})`)
      .maybeSingle();

    setIsConnected(!!connection);

    const { data: request } = await supabase
      .from('connection_requests')
      .select('id')
      .eq('requester_id', user.id)
      .eq('recipient_id', userId)
      .eq('status', 'pending')
      .maybeSingle();

    setConnectionRequestPending(!!request);
  };

  const loadCounts = async () => {
    const { count: followers } = await supabase
      .from('followers')
      .select('id', { count: 'exact' })
      .eq('following_id', userId);

    const { count: following } = await supabase
      .from('followers')
      .select('id', { count: 'exact' })
      .eq('follower_id', userId);

    const { count: connections } = await supabase
      .from('connections')
      .select('id', { count: 'exact' })
      .or(`user_id_1.eq.${userId},user_id_2.eq.${userId}`);

    setFollowerCount(followers || 0);
    setFollowingCount(following || 0);
    setConnectionCount(connections || 0);
  };

  const handleFollow = async () => {
    if (!user) return;

    try {
      if (isFollowing) {
        await supabase
          .from('followers')
          .delete()
          .eq('follower_id', user.id)
          .eq('following_id', userId);
        setIsFollowing(false);
        setFollowerCount(Math.max(0, followerCount - 1));
      } else {
        await supabase.from('followers').insert([
          {
            follower_id: user.id,
            following_id: userId,
          },
        ]);
        setIsFollowing(true);
        setFollowerCount(followerCount + 1);
      }
    } catch (err) {
      console.error('Error toggling follow:', err);
    }
  };

  const handleConnect = async () => {
    if (!user) return;

    try {
      await supabase.from('connection_requests').insert([
        {
          requester_id: user.id,
          recipient_id: userId,
          message: `Hi! I'd like to connect with you on Skill Swap.`,
        },
      ]);
      setConnectionRequestPending(true);
    } catch (err) {
      console.error('Error sending connection request:', err);
    }
  };

  if (isOwnProfile) {
    return (
      <div className="flex gap-4 flex-wrap">
        <div className="text-center">
          <p className="text-2xl font-bold text-gray-900">{followerCount}</p>
          <p className="text-sm text-gray-600">Followers</p>
        </div>
        <div className="text-center">
          <p className="text-2xl font-bold text-gray-900">{followingCount}</p>
          <p className="text-sm text-gray-600">Following</p>
        </div>
        <div className="text-center">
          <p className="text-2xl font-bold text-gray-900">{connectionCount}</p>
          <p className="text-sm text-gray-600">Connections</p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-wrap gap-3">
      <button
        onClick={handleFollow}
        className={`flex items-center gap-2 px-4 py-2 rounded-lg transition font-semibold ${
          isFollowing
            ? 'bg-red-100 text-red-600 hover:bg-red-200'
            : 'bg-blue-100 text-blue-600 hover:bg-blue-200'
        }`}
      >
        <Heart size={20} fill={isFollowing ? 'currentColor' : 'none'} />
        {isFollowing ? 'Following' : 'Follow'}
      </button>

      <button
        onClick={handleConnect}
        disabled={isConnected || connectionRequestPending}
        className={`flex items-center gap-2 px-4 py-2 rounded-lg transition font-semibold ${
          isConnected
            ? 'bg-green-100 text-green-600'
            : connectionRequestPending
              ? 'bg-orange-100 text-orange-600'
              : 'bg-purple-100 text-purple-600 hover:bg-purple-200'
        }`}
      >
        <UserPlus size={20} />
        {isConnected ? 'Connected' : connectionRequestPending ? 'Request Sent' : 'Connect'}
      </button>

      <button className="flex items-center gap-2 px-4 py-2 rounded-lg bg-gray-100 text-gray-600 hover:bg-gray-200 transition font-semibold">
        <Mail size={20} />
        Message
      </button>

      <div className="flex gap-4 ml-auto">
        <div className="text-center">
          <p className="text-sm text-gray-600">{followerCount}</p>
          <p className="text-xs text-gray-500">Followers</p>
        </div>
        <div className="text-center">
          <p className="text-sm text-gray-600">{followingCount}</p>
          <p className="text-xs text-gray-500">Following</p>
        </div>
      </div>
    </div>
  );
};
