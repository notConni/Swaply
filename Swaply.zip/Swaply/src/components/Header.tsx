import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { supabase } from '../lib/supabase';
import { Menu, X, LogOut, User, MessageSquare, ArrowLeftRight } from 'lucide-react';

export const Header: React.FC = () => {
  const { user, profile, signOut } = useAuth();
  const location = useLocation();
  const [menuOpen, setMenuOpen] = useState(false);
  const [pendingCount, setPendingCount] = useState(0);
  const [unreadCount, setUnreadCount] = useState(0);

  useEffect(() => {
    if (user) {
      loadCounts();
      const interval = setInterval(loadCounts, 15000);
      return () => clearInterval(interval);
    } else {
      setPendingCount(0);
      setUnreadCount(0);
    }
  }, [user]);

  const loadCounts = async () => {
    if (!user) return;
    const [swapRes, msgRes] = await Promise.all([
      supabase
        .from('swap_requests')
        .select('id', { count: 'exact', head: true })
        .eq('recipient_id', user.id)
        .eq('status', 'pending'),
      supabase
        .from('messages')
        .select('id', { count: 'exact', head: true })
        .eq('recipient_id', user.id)
        .eq('is_read', false),
    ]);
    setPendingCount(swapRes.count || 0);
    setUnreadCount(msgRes.count || 0);
  };

  const handleSignOut = async () => {
    await signOut();
    setMenuOpen(false);
  };

  const isActive = (path: string) =>
    location.pathname === path ? 'text-blue-600' : 'text-gray-600 hover:text-blue-600';

  return (
    <header className="bg-white shadow-md sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
        <Link to="/" className="flex items-center space-x-2">
          <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-blue-800 rounded-lg flex items-center justify-center">
            <span className="text-white font-bold text-lg">SS</span>
          </div>
          <span className="font-bold text-xl hidden sm:inline text-gray-900">Skill Swap</span>
        </Link>

        <nav className="hidden md:flex items-center space-x-6 text-sm">
          {user ? (
            <>
              <Link to="/search" className={`transition font-medium ${isActive('/search')}`}>
                Find Partners
              </Link>
              <Link to="/sessions" className={`transition font-medium ${isActive('/sessions')}`}>
                Sessions
              </Link>
              <Link
                to="/swap-requests"
                className={`relative transition font-medium flex items-center gap-1.5 ${isActive('/swap-requests')}`}
              >
                <ArrowLeftRight size={16} />
                Requests
                {pendingCount > 0 && (
                  <span className="absolute -top-2.5 -right-3.5 bg-red-500 text-white text-[10px] font-bold min-w-[18px] h-[18px] px-1 rounded-full flex items-center justify-center">
                    {pendingCount > 9 ? '9+' : pendingCount}
                  </span>
                )}
              </Link>
              <Link to="/dashboard" className={`transition font-medium ${isActive('/dashboard')}`}>
                Dashboard
              </Link>
              <Link to="/messages" className={`relative transition ${isActive('/messages')}`}>
                <MessageSquare size={20} />
                {unreadCount > 0 && (
                  <span className="absolute -top-1.5 -right-1.5 bg-red-500 text-white text-[10px] font-bold min-w-[16px] h-[16px] px-0.5 rounded-full flex items-center justify-center">
                    {unreadCount > 9 ? '9+' : unreadCount}
                  </span>
                )}
              </Link>
              <Link to={`/profile/${user.id}`} className={`transition ${isActive(`/profile/${user.id}`)}`}>
                <User size={20} />
              </Link>
              <button onClick={handleSignOut} className="text-red-600 hover:text-red-700 transition">
                <LogOut size={20} />
              </button>
            </>
          ) : (
            <>
              <Link to="/login" className="text-gray-600 hover:text-blue-600 transition font-medium">
                Login
              </Link>
              <Link
                to="/register"
                className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition font-medium"
              >
                Get Started
              </Link>
            </>
          )}
        </nav>

        <button className="md:hidden" onClick={() => setMenuOpen(!menuOpen)}>
          {menuOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {menuOpen && (
        <div className="md:hidden bg-white border-t border-gray-200">
          <div className="px-4 py-4 space-y-4">
            {user ? (
              <>
                <Link
                  to="/search"
                  className="block text-gray-600 hover:text-blue-600 transition font-medium"
                  onClick={() => setMenuOpen(false)}
                >
                  Find Partners
                </Link>
                <Link
                  to="/sessions"
                  className="block text-gray-600 hover:text-blue-600 transition font-medium"
                  onClick={() => setMenuOpen(false)}
                >
                  Sessions
                </Link>
                <Link
                  to="/swap-requests"
                  className="flex items-center justify-between text-gray-600 hover:text-blue-600 transition font-medium"
                  onClick={() => setMenuOpen(false)}
                >
                  <span>Swap Requests</span>
                  {pendingCount > 0 && (
                    <span className="bg-red-500 text-white text-xs font-bold px-2 py-0.5 rounded-full">
                      {pendingCount}
                    </span>
                  )}
                </Link>
                <Link
                  to="/dashboard"
                  className="block text-gray-600 hover:text-blue-600 transition font-medium"
                  onClick={() => setMenuOpen(false)}
                >
                  Dashboard
                </Link>
                <Link
                  to="/messages"
                  className="flex items-center justify-between text-gray-600 hover:text-blue-600 transition font-medium"
                  onClick={() => setMenuOpen(false)}
                >
                  <span>Messages</span>
                  {unreadCount > 0 && (
                    <span className="bg-red-500 text-white text-xs font-bold px-2 py-0.5 rounded-full">
                      {unreadCount}
                    </span>
                  )}
                </Link>
                <Link
                  to={`/profile/${user.id}`}
                  className="block text-gray-600 hover:text-blue-600 transition font-medium"
                  onClick={() => setMenuOpen(false)}
                >
                  My Profile
                </Link>
                <button
                  onClick={handleSignOut}
                  className="block w-full text-left text-red-600 hover:text-red-700 transition font-medium"
                >
                  Sign Out
                </button>
              </>
            ) : (
              <>
                <Link
                  to="/login"
                  className="block text-gray-600 hover:text-blue-600 transition font-medium"
                  onClick={() => setMenuOpen(false)}
                >
                  Login
                </Link>
                <Link
                  to="/register"
                  className="block bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition text-center font-medium"
                  onClick={() => setMenuOpen(false)}
                >
                  Get Started
                </Link>
              </>
            )}
          </div>
        </div>
      )}
    </header>
  );
};
