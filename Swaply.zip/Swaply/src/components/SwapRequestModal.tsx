import React, { useEffect, useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { supabase } from '../lib/supabase';
import { UserSkillOffered, User } from '../types';
import { X, ArrowLeftRight, Send } from 'lucide-react';

interface SwapRequestModalProps {
  targetUser: User;
  onClose: () => void;
  onSuccess?: () => void;
}

export const SwapRequestModal: React.FC<SwapRequestModalProps> = ({ targetUser, onClose, onSuccess }) => {
  const { user } = useAuth();
  const [mySkills, setMySkills] = useState<UserSkillOffered[]>([]);
  const [theirSkills, setTheirSkills] = useState<UserSkillOffered[]>([]);
  const [skillOfferedId, setSkillOfferedId] = useState('');
  const [skillWantedId, setSkillWantedId] = useState('');
  const [message, setMessage] = useState('');
  const [sessionType, setSessionType] = useState<'online' | 'in-person'>('online');
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);

  useEffect(() => {
    loadSkills();
  }, []);

  const loadSkills = async () => {
    if (!user) return;
    setLoading(true);
    try {
      const { data: mine } = await supabase
        .from('user_skills_offered')
        .select('*, skill:skills(*)')
        .eq('user_id', user.id);

      const { data: theirs } = await supabase
        .from('user_skills_offered')
        .select('*, skill:skills(*)')
        .eq('user_id', targetUser.id);

      setMySkills(mine || []);
      setTheirSkills(theirs || []);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async () => {
    if (!user || !skillOfferedId || !skillWantedId) return;
    setError('');
    setSubmitting(true);

    try {
      const { data: existing } = await supabase
        .from('swap_requests')
        .select('id')
        .eq('requester_id', user.id)
        .eq('recipient_id', targetUser.id)
        .eq('status', 'pending')
        .maybeSingle();

      if (existing) {
        setError('You already have a pending swap request with this user.');
        return;
      }

      const { error: insertErr } = await supabase.from('swap_requests').insert([{
        requester_id: user.id,
        recipient_id: targetUser.id,
        skill_offered_id: skillOfferedId,
        skill_wanted_id: skillWantedId,
        message: message.trim(),
        session_type: sessionType,
        status: 'pending',
      }]);

      if (insertErr) throw insertErr;

      await supabase.from('notifications').insert([{
        user_id: targetUser.id,
        type: 'swap_request',
        title: 'New Skill Swap Request',
        message: `You have a new swap request waiting for your response.`,
        related_user_id: user.id,
      }]);

      setSuccess(true);
      setTimeout(() => {
        onSuccess?.();
        onClose();
      }, 1500);
    } catch (err: any) {
      setError('Failed to send request. Please try again.');
      console.error(err);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 px-4">
      <div className="bg-white rounded-xl shadow-2xl w-full max-w-lg">
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <div className="flex items-center gap-3">
            <div className="bg-blue-100 p-2 rounded-lg">
              <ArrowLeftRight className="text-blue-600" size={20} />
            </div>
            <div>
              <h2 className="text-lg font-bold text-gray-900">Request Skill Swap</h2>
              <p className="text-sm text-gray-500">with {targetUser.username}</p>
            </div>
          </div>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600 transition">
            <X size={24} />
          </button>
        </div>

        {loading ? (
          <div className="p-8 text-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto"></div>
          </div>
        ) : success ? (
          <div className="p-8 text-center">
            <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Send className="text-green-600" size={28} />
            </div>
            <h3 className="text-lg font-bold text-gray-900 mb-2">Request Sent!</h3>
            <p className="text-gray-500">Your swap request has been sent to {targetUser.username}.</p>
          </div>
        ) : (
          <div className="p-6 space-y-5">
            {error && (
              <div className="bg-red-50 border border-red-200 text-red-700 rounded-lg px-4 py-3 text-sm">
                {error}
              </div>
            )}

            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                Skill you're offering
              </label>
              {mySkills.length === 0 ? (
                <p className="text-sm text-gray-500 italic">
                  You haven't added any offered skills yet. Go to{' '}
                  <a href="/skills" className="text-blue-600 underline">My Skills</a> to add some.
                </p>
              ) : (
                <select
                  value={skillOfferedId}
                  onChange={(e) => setSkillOfferedId(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition text-sm"
                >
                  <option value="">Select a skill you can teach...</option>
                  {mySkills.map((s) => (
                    <option key={s.id} value={s.skill_id}>
                      {s.skill?.name} ({s.proficiency_level})
                    </option>
                  ))}
                </select>
              )}
            </div>

            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                Skill you want to learn from {targetUser.username}
              </label>
              {theirSkills.length === 0 ? (
                <p className="text-sm text-gray-500 italic">
                  {targetUser.username} hasn't listed any offered skills yet.
                </p>
              ) : (
                <select
                  value={skillWantedId}
                  onChange={(e) => setSkillWantedId(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition text-sm"
                >
                  <option value="">Select a skill to learn...</option>
                  {theirSkills.map((s) => (
                    <option key={s.id} value={s.skill_id}>
                      {s.skill?.name} ({s.proficiency_level})
                    </option>
                  ))}
                </select>
              )}
            </div>

            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                Session type
              </label>
              <div className="flex gap-3">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="radio"
                    name="sessionType"
                    value="online"
                    checked={sessionType === 'online'}
                    onChange={() => setSessionType('online')}
                    className="text-blue-600"
                  />
                  <span className="text-sm text-gray-700">Online</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="radio"
                    name="sessionType"
                    value="in-person"
                    checked={sessionType === 'in-person'}
                    onChange={() => setSessionType('in-person')}
                    className="text-blue-600"
                  />
                  <span className="text-sm text-gray-700">In-person</span>
                </label>
              </div>
            </div>

            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                Message <span className="font-normal text-gray-400">(optional)</span>
              </label>
              <textarea
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                placeholder="Introduce yourself and describe what you'd like to learn..."
                rows={3}
                maxLength={500}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition text-sm resize-none"
              />
              <p className="text-xs text-gray-400 mt-1 text-right">{message.length}/500</p>
            </div>

            <div className="flex gap-3 pt-2">
              <button
                onClick={onClose}
                className="flex-1 px-4 py-2.5 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition font-semibold text-sm"
              >
                Cancel
              </button>
              <button
                onClick={handleSubmit}
                disabled={submitting || !skillOfferedId || !skillWantedId}
                className="flex-1 px-4 py-2.5 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition font-semibold text-sm disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
              >
                {submitting ? (
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                ) : (
                  <>
                    <Send size={16} />
                    Send Request
                  </>
                )}
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
