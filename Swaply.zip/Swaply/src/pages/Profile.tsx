import React, { useEffect, useState } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { supabase } from '../lib/supabase';
import { User, UserSkillOffered, UserSkillWanted, Review } from '../types';
import { Mail, MapPin, Star, CreditCard as Edit, MessageSquare, TrendingUp, ArrowLeftRight } from 'lucide-react';
import { SocialActions } from '../components/SocialActions';
import { BadgeDisplay } from '../components/BadgeDisplay';
import { SwapRequestModal } from '../components/SwapRequestModal';

export const Profile: React.FC = () => {
  const { userId } = useParams<{ userId: string }>();
  const { user, profile: currentUserProfile } = useAuth();
  const navigate = useNavigate();
  const [profile, setProfile] = useState<User | null>(null);
  const [offeredSkills, setOfferedSkills] = useState<UserSkillOffered[]>([]);
  const [wantedSkills, setWantedSkills] = useState<UserSkillWanted[]>([]);
  const [reviews, setReviews] = useState<Review[]>([]);
  const [loading, setLoading] = useState(true);
  const [isEditing, setIsEditing] = useState(false);
  const [editData, setEditData] = useState<Partial<User>>({});
  const [showSwapModal, setShowSwapModal] = useState(false);

  useEffect(() => {
    if (userId) {
      loadProfile();
    }
  }, [userId]);

  const loadProfile = async () => {
    if (!userId) return;

    setLoading(true);
    try {
      const { data: profileData } = await supabase
        .from('users')
        .select('*')
        .eq('id', userId)
        .single();

      if (profileData) {
        setProfile(profileData);
        setEditData(profileData);
      }

      const { data: offered } = await supabase
        .from('user_skills_offered')
        .select('*, skill:skills(*)')
        .eq('user_id', userId);

      setOfferedSkills(offered || []);

      const { data: wanted } = await supabase
        .from('user_skills_wanted')
        .select('*, skill:skills(*)')
        .eq('user_id', userId);

      setWantedSkills(wanted || []);

      const { data: userReviews } = await supabase
        .from('reviews')
        .select('*')
        .eq('reviewed_user_id', userId)
        .order('created_at', { ascending: false });

      setReviews(userReviews || []);
    } finally {
      setLoading(false);
    }
  };

  const handleSaveProfile = async () => {
    if (!user || !profile) return;

    try {
      await supabase
        .from('users')
        .update(editData)
        .eq('id', user.id);

      setProfile((prev) => (prev ? { ...prev, ...editData } : null));
      setIsEditing(false);
    } catch (err) {
      console.error('Error updating profile:', err);
    }
  };

  const handleSendMessage = () => {
    if (userId && userId !== user?.id) {
      navigate(`/messages?user=${userId}`);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (!profile) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <p className="text-gray-600 mb-4">User not found</p>
          <Link to="/" className="text-blue-600 hover:text-blue-700">
            Go back home
          </Link>
        </div>
      </div>
    );
  }

  const isOwnProfile = user?.id === userId;

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-4xl mx-auto px-4">
        {/* Profile Header */}
        <div className="bg-white rounded-lg shadow-md p-8 mb-8">
          <div className="flex flex-col md:flex-row gap-8 items-start md:items-center">
            <div className="w-32 h-32 bg-gradient-to-br from-blue-400 to-blue-600 rounded-lg flex items-center justify-center flex-shrink-0">
              {profile.profile_picture_url ? (
                <img
                  src={profile.profile_picture_url}
                  alt={profile.username}
                  className="w-full h-full object-cover rounded-lg"
                />
              ) : (
                <span className="text-white text-5xl font-bold">
                  {profile.username.charAt(0).toUpperCase()}
                </span>
              )}
            </div>

            <div className="flex-1">
              <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-4">
                <div>
                  {isEditing ? (
                    <input
                      type="text"
                      value={editData.username || ''}
                      onChange={(e) => setEditData({ ...editData, username: e.target.value })}
                      className="text-3xl font-bold text-gray-900 border-b-2 border-blue-600 focus:outline-none"
                    />
                  ) : (
                    <h1 className="text-3xl font-bold text-gray-900">{profile.username}</h1>
                  )}
                  <div className="flex items-center gap-4 mt-2 flex-wrap">
                    <div className="flex items-center gap-1 text-yellow-500">
                      <Star size={20} fill="currentColor" />
                      <span className="font-semibold text-gray-900">
                        {profile.average_rating.toFixed(1)}
                      </span>
                      <span className="text-gray-600">({profile.total_reviews} reviews)</span>
                    </div>
                  </div>
                </div>
                <div className="flex gap-2">
                  {isOwnProfile ? (
                    <>
                      <button
                        onClick={() => {
                          if (isEditing) handleSaveProfile();
                          setIsEditing(!isEditing);
                        }}
                        className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition flex items-center gap-2 text-sm"
                      >
                        <Edit size={18} />
                        {isEditing ? 'Save' : 'Edit Profile'}
                      </button>
                      <Link
                        to={`/reputation/${user?.id}`}
                        className="bg-purple-600 text-white px-4 py-2 rounded-lg hover:bg-purple-700 transition flex items-center gap-2 text-sm"
                      >
                        <TrendingUp size={18} />
                        Reputation
                      </Link>
                    </>
                  ) : (
                    <div className="flex gap-2 flex-wrap">
                      <button
                        onClick={() => setShowSwapModal(true)}
                        className="flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition text-sm font-semibold"
                      >
                        <ArrowLeftRight size={16} />
                        Request Swap
                      </button>
                      <button
                        onClick={handleSendMessage}
                        className="flex items-center gap-2 bg-gray-100 text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-200 transition text-sm font-semibold"
                      >
                        <MessageSquare size={16} />
                        Message
                      </button>
                      <SocialActions userId={userId!} isOwnProfile={false} />
                    </div>
                  )}
                </div>
              </div>

              <div className="space-y-3 text-gray-600">
                {isEditing ? (
                  <>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Bio</label>
                      <textarea
                        value={editData.bio || ''}
                        onChange={(e) => setEditData({ ...editData, bio: e.target.value })}
                        rows={3}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none transition resize-none"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">City</label>
                      <input
                        type="text"
                        value={editData.city || ''}
                        onChange={(e) => setEditData({ ...editData, city: e.target.value })}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none transition"
                      />
                    </div>
                  </>
                ) : (
                  <>
                    {profile.bio && (
                      <p className="text-lg">{profile.bio}</p>
                    )}
                    <div className="flex items-center gap-2">
                      <MapPin size={20} />
                      <span>{profile.city || 'Location not specified'}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Mail size={20} />
                      <span>{profile.email}</span>
                    </div>
                  </>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Skills Sections */}
        <div className="grid md:grid-cols-2 gap-8 mb-8">
          {/* Offered Skills */}
          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-bold text-gray-900">Skills I Can Teach</h2>
              {isOwnProfile && (
                <Link to="/skills" className="text-blue-600 hover:text-blue-700 text-sm font-semibold">
                  + Add Skill
                </Link>
              )}
            </div>
            <div className="space-y-4">
              {offeredSkills.length > 0 ? (
                offeredSkills.map((skill) => (
                  <div key={skill.id} className="border border-gray-200 rounded-lg p-4">
                    <h3 className="font-semibold text-gray-900">{skill.skill?.name}</h3>
                    <p className="text-sm text-gray-600 mt-1">
                      Level: <span className="capitalize">{skill.proficiency_level}</span>
                    </p>
                    {skill.years_of_experience > 0 && (
                      <p className="text-sm text-gray-600">
                        {skill.years_of_experience} year{skill.years_of_experience > 1 ? 's' : ''} experience
                      </p>
                    )}
                    {skill.description && (
                      <p className="text-sm text-gray-600 mt-2">{skill.description}</p>
                    )}
                  </div>
                ))
              ) : (
                <p className="text-gray-500">No skills added yet</p>
              )}
            </div>
          </div>

          {/* Wanted Skills */}
          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-bold text-gray-900">Skills I Want to Learn</h2>
              {isOwnProfile && (
                <Link to="/skills" className="text-blue-600 hover:text-blue-700 text-sm font-semibold">
                  + Add Skill
                </Link>
              )}
            </div>
            <div className="space-y-4">
              {wantedSkills.length > 0 ? (
                wantedSkills.map((skill) => (
                  <div key={skill.id} className="border border-gray-200 rounded-lg p-4">
                    <h3 className="font-semibold text-gray-900">{skill.skill?.name}</h3>
                    <p className="text-sm text-gray-600 mt-1">Priority: Level {skill.priority}</p>
                  </div>
                ))
              ) : (
                <p className="text-gray-500">No skills added yet</p>
              )}
            </div>
          </div>
        </div>

        {/* Badges */}
        <div className="bg-white rounded-lg shadow-md p-6 mb-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">Badges & Achievements</h2>
          <BadgeDisplay userId={profile.id} />
        </div>

        {/* Reviews */}
        {reviews.length > 0 && (
          <div className="bg-white rounded-lg shadow-md p-6">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">Reviews</h2>
            <div className="space-y-6">
              {reviews.map((review) => (
                <div key={review.id} className="border-b border-gray-200 pb-6 last:border-b-0 last:pb-0">
                  <div className="flex items-center gap-2 mb-2">
                    <div className="flex gap-1">
                      {[...Array(review.rating)].map((_, i) => (
                        <Star key={i} size={18} className="fill-yellow-400 text-yellow-400" />
                      ))}
                    </div>
                    <span className="text-sm text-gray-600">
                      {new Date(review.created_at).toLocaleDateString()}
                    </span>
                  </div>
                  <p className="text-gray-700">{review.comment}</p>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {showSwapModal && profile && !isOwnProfile && (
        <SwapRequestModal
          targetUser={profile}
          onClose={() => setShowSwapModal(false)}
          onSuccess={() => setShowSwapModal(false)}
        />
      )}
    </div>
  );
};
