import React, { useEffect, useRef, useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { supabase } from '../lib/supabase';
import { User, Message } from '../types';
import { Send, MessageCircle, Search } from 'lucide-react';
import { useSearchParams } from 'react-router-dom';

interface ConversationMeta {
  user: User;
  lastMessage: string;
  lastMessageTime: string;
  unreadCount: number;
  lastSenderId: string;
}

export const Messages: React.FC = () => {
  const { user } = useAuth();
  const [searchParams] = useSearchParams();
  const initialUserId = searchParams.get('user');

  const [conversations, setConversations] = useState<ConversationMeta[]>([]);
  const [selectedUser, setSelectedUser] = useState<User | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (user) {
      loadConversations();
    }
  }, [user]);

  useEffect(() => {
    if (user && initialUserId) {
      loadUser(initialUserId);
    }
  }, [user, initialUserId]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const loadConversations = async () => {
    if (!user) return;
    setLoading(true);

    try {
      const { data: messageData } = await supabase
        .from('messages')
        .select('sender_id, recipient_id, content, created_at, is_read')
        .or(`sender_id.eq.${user.id},recipient_id.eq.${user.id}`)
        .order('created_at', { ascending: false });

      if (!messageData || messageData.length === 0) {
        setLoading(false);
        return;
      }

      const partnerMap = new Map<string, {
        lastMessage: string;
        lastMessageTime: string;
        unreadCount: number;
        lastSenderId: string;
      }>();

      messageData.forEach((msg) => {
        const partnerId = msg.sender_id === user.id ? msg.recipient_id : msg.sender_id;

        if (!partnerMap.has(partnerId)) {
          partnerMap.set(partnerId, {
            lastMessage: msg.content,
            lastMessageTime: msg.created_at,
            unreadCount: 0,
            lastSenderId: msg.sender_id,
          });
        }

        if (!msg.is_read && msg.recipient_id === user.id) {
          const existing = partnerMap.get(partnerId)!;
          existing.unreadCount += 1;
          partnerMap.set(partnerId, existing);
        }
      });

      const partnerIds = Array.from(partnerMap.keys());
      if (partnerIds.length === 0) return;

      const { data: users } = await supabase
        .from('users')
        .select('*')
        .in('id', partnerIds);

      if (users) {
        const convos: ConversationMeta[] = users.map((u) => ({
          user: u,
          ...partnerMap.get(u.id)!,
        }));

        convos.sort(
          (a, b) => new Date(b.lastMessageTime).getTime() - new Date(a.lastMessageTime).getTime()
        );

        setConversations(convos);
      }
    } finally {
      setLoading(false);
    }
  };

  const loadUser = async (userId: string) => {
    try {
      const { data } = await supabase.from('users').select('*').eq('id', userId).single();
      if (data) {
        setSelectedUser(data);
        await loadMessages(userId);
      }
    } catch (err) {
      console.error('Error loading user:', err);
    }
  };

  const loadMessages = async (partnerId: string) => {
    if (!user) return;

    try {
      const { data } = await supabase
        .from('messages')
        .select('*')
        .or(
          `and(sender_id.eq.${user.id},recipient_id.eq.${partnerId}),and(sender_id.eq.${partnerId},recipient_id.eq.${user.id})`
        )
        .order('created_at', { ascending: true });

      setMessages(data || []);

      await supabase
        .from('messages')
        .update({ is_read: true })
        .eq('recipient_id', user.id)
        .eq('sender_id', partnerId);

      setConversations((prev) =>
        prev.map((c) =>
          c.user.id === partnerId ? { ...c, unreadCount: 0 } : c
        )
      );
    } catch (err) {
      console.error('Error loading messages:', err);
    }
  };

  const handleSelectUser = (meta: ConversationMeta) => {
    setSelectedUser(meta.user);
    loadMessages(meta.user.id);
  };

  const handleSendMessage = async () => {
    if (!user || !selectedUser || !newMessage.trim()) return;

    const content = newMessage.trim();
    setNewMessage('');

    try {
      await supabase.from('messages').insert([{
        sender_id: user.id,
        recipient_id: selectedUser.id,
        content,
      }]);

      await loadMessages(selectedUser.id);

      setConversations((prev) => {
        const existing = prev.find((c) => c.user.id === selectedUser.id);
        const updated: ConversationMeta = {
          user: selectedUser,
          lastMessage: content,
          lastMessageTime: new Date().toISOString(),
          unreadCount: 0,
          lastSenderId: user.id,
        };
        if (existing) {
          return [updated, ...prev.filter((c) => c.user.id !== selectedUser.id)];
        }
        return [updated, ...prev];
      });
    } catch (err) {
      console.error('Error sending message:', err);
    }
  };

  const formatTime = (iso: string) => {
    const date = new Date(iso);
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffDays = Math.floor(diffMs / 86400000);

    if (diffDays === 0) {
      return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    } else if (diffDays === 1) {
      return 'Yesterday';
    } else if (diffDays < 7) {
      return date.toLocaleDateString([], { weekday: 'short' });
    } else {
      return date.toLocaleDateString([], { month: 'short', day: 'numeric' });
    }
  };

  const filteredConversations = searchQuery
    ? conversations.filter((c) =>
        c.user.username.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : conversations;

  const totalUnread = conversations.reduce((sum, c) => sum + c.unreadCount, 0);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-6">
      <div className="max-w-6xl mx-auto px-4">
        <div className="flex items-center gap-3 mb-6">
          <h1 className="text-2xl font-bold text-gray-900">Messages</h1>
          {totalUnread > 0 && (
            <span className="bg-blue-600 text-white text-xs font-bold px-2.5 py-1 rounded-full">
              {totalUnread} unread
            </span>
          )}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-0 h-[680px] bg-white rounded-2xl shadow-lg overflow-hidden border border-gray-200">
          {/* Sidebar — Conversations List */}
          <div className="flex flex-col border-r border-gray-200">
            {/* Search */}
            <div className="p-4 border-b border-gray-100">
              <div className="relative">
                <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search conversations..."
                  className="w-full pl-9 pr-3 py-2 bg-gray-100 rounded-xl text-sm outline-none focus:bg-gray-50 focus:ring-2 focus:ring-blue-500 transition"
                />
              </div>
            </div>

            {/* List */}
            <div className="flex-1 overflow-y-auto">
              {filteredConversations.length > 0 ? (
                filteredConversations.map((meta) => {
                  const isSelected = selectedUser?.id === meta.user.id;
                  const hasUnread = meta.unreadCount > 0;
                  const isMe = meta.lastSenderId === user?.id;

                  return (
                    <button
                      key={meta.user.id}
                      onClick={() => handleSelectUser(meta)}
                      className={`w-full px-4 py-3.5 flex items-center gap-3 text-left transition border-b border-gray-50 ${
                        isSelected
                          ? 'bg-blue-50 border-l-2 border-l-blue-600'
                          : 'hover:bg-gray-50'
                      }`}
                    >
                      {/* Avatar */}
                      <div className="relative flex-shrink-0">
                        <div className={`w-11 h-11 rounded-full flex items-center justify-center font-bold text-white text-sm ${
                          isSelected
                            ? 'bg-gradient-to-br from-blue-500 to-blue-700'
                            : 'bg-gradient-to-br from-gray-400 to-gray-600'
                        }`}>
                          {meta.user.username.charAt(0).toUpperCase()}
                        </div>
                        {hasUnread && (
                          <span className="absolute -top-0.5 -right-0.5 bg-blue-600 text-white text-[10px] font-bold min-w-[18px] h-[18px] px-1 rounded-full flex items-center justify-center">
                            {meta.unreadCount > 99 ? '99+' : meta.unreadCount}
                          </span>
                        )}
                      </div>

                      {/* Text */}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between gap-2 mb-0.5">
                          <span className={`text-sm truncate ${hasUnread ? 'font-bold text-gray-900' : 'font-semibold text-gray-800'}`}>
                            {meta.user.username}
                          </span>
                          <span className="text-[11px] text-gray-400 flex-shrink-0">
                            {formatTime(meta.lastMessageTime)}
                          </span>
                        </div>
                        <p className={`text-xs truncate ${hasUnread ? 'text-gray-800 font-medium' : 'text-gray-500'}`}>
                          {isMe && <span className="text-gray-400">You: </span>}
                          {meta.lastMessage}
                        </p>
                      </div>
                    </button>
                  );
                })
              ) : searchQuery ? (
                <div className="p-6 text-center text-gray-400">
                  <p className="text-sm">No conversations match "{searchQuery}"</p>
                </div>
              ) : (
                <div className="p-8 text-center text-gray-400">
                  <MessageCircle size={36} className="mx-auto mb-3 opacity-40" />
                  <p className="text-sm font-medium">No conversations yet</p>
                  <p className="text-xs mt-1 text-gray-400">Find a partner and start swapping!</p>
                </div>
              )}
            </div>
          </div>

          {/* Chat Area */}
          <div className="md:col-span-2 flex flex-col">
            {selectedUser ? (
              <>
                {/* Chat Header */}
                <div className="px-5 py-4 border-b border-gray-200 flex items-center gap-3 bg-white">
                  <div className="w-9 h-9 bg-gradient-to-br from-blue-500 to-blue-700 rounded-full flex items-center justify-center text-white font-bold text-sm flex-shrink-0">
                    {selectedUser.username.charAt(0).toUpperCase()}
                  </div>
                  <div>
                    <p className="font-semibold text-gray-900 text-sm leading-tight">{selectedUser.username}</p>
                    <p className="text-xs text-gray-400">{selectedUser.city || 'No location'}</p>
                  </div>
                </div>

                {/* Messages */}
                <div className="flex-1 overflow-y-auto px-5 py-4 space-y-3 bg-gray-50">
                  {messages.length > 0 ? (
                    <>
                      {messages.map((msg, idx) => {
                        const isOwn = msg.sender_id === user?.id;
                        const prevMsg = messages[idx - 1];
                        const showDateSep =
                          !prevMsg ||
                          new Date(msg.created_at).toDateString() !==
                            new Date(prevMsg.created_at).toDateString();

                        return (
                          <React.Fragment key={msg.id}>
                            {showDateSep && (
                              <div className="flex items-center gap-3 py-1">
                                <div className="flex-1 h-px bg-gray-200" />
                                <span className="text-xs text-gray-400 px-2">
                                  {new Date(msg.created_at).toLocaleDateString([], {
                                    weekday: 'short',
                                    month: 'short',
                                    day: 'numeric',
                                  })}
                                </span>
                                <div className="flex-1 h-px bg-gray-200" />
                              </div>
                            )}
                            <div className={`flex ${isOwn ? 'justify-end' : 'justify-start'}`}>
                              <div
                                className={`max-w-[70%] px-4 py-2.5 rounded-2xl text-sm leading-relaxed ${
                                  isOwn
                                    ? 'bg-blue-600 text-white rounded-br-sm'
                                    : 'bg-white text-gray-900 shadow-sm border border-gray-100 rounded-bl-sm'
                                }`}
                              >
                                <p className="break-words">{msg.content}</p>
                                <p className={`text-[10px] mt-1 ${isOwn ? 'text-blue-200 text-right' : 'text-gray-400'}`}>
                                  {new Date(msg.created_at).toLocaleTimeString([], {
                                    hour: '2-digit',
                                    minute: '2-digit',
                                  })}
                                </p>
                              </div>
                            </div>
                          </React.Fragment>
                        );
                      })}
                      <div ref={messagesEndRef} />
                    </>
                  ) : (
                    <div className="flex items-center justify-center h-full text-gray-400">
                      <div className="text-center">
                        <MessageCircle size={36} className="mx-auto mb-3 opacity-40" />
                        <p className="text-sm font-medium">No messages yet</p>
                        <p className="text-xs mt-1">Say hello to {selectedUser.username}!</p>
                      </div>
                    </div>
                  )}
                </div>

                {/* Input */}
                <div className="px-4 py-3 border-t border-gray-200 bg-white">
                  <div className="flex gap-2 items-end">
                    <input
                      type="text"
                      value={newMessage}
                      onChange={(e) => setNewMessage(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter' && !e.shiftKey) {
                          e.preventDefault();
                          handleSendMessage();
                        }
                      }}
                      placeholder={`Message ${selectedUser.username}...`}
                      className="flex-1 px-4 py-2.5 bg-gray-100 rounded-xl text-sm outline-none focus:bg-gray-50 focus:ring-2 focus:ring-blue-500 transition"
                    />
                    <button
                      onClick={handleSendMessage}
                      disabled={!newMessage.trim()}
                      className="bg-blue-600 text-white p-2.5 rounded-xl hover:bg-blue-700 active:scale-95 transition disabled:opacity-40 disabled:cursor-not-allowed flex-shrink-0"
                    >
                      <Send size={18} />
                    </button>
                  </div>
                </div>
              </>
            ) : (
              <div className="flex items-center justify-center h-full text-gray-400">
                <div className="text-center">
                  <MessageCircle size={48} className="mx-auto mb-4 opacity-30" />
                  <p className="font-medium text-gray-500">Select a conversation</p>
                  <p className="text-sm mt-1">Choose someone to start chatting</p>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
