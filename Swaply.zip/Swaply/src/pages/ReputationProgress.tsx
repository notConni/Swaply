import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { supabase } from '../lib/supabase';
import { User, LearningProgress, ReputationHistory, UserBadge } from '../types';
import { TrendingUp, Zap, Award, BookOpen } from 'lucide-react';
import { BadgeDisplay } from '../components/BadgeDisplay';

export const ReputationProgress: React.FC = () => {
  const { userId } = useParams<{ userId: string }>();
  const { user } = useAuth();
  const [profile, setProfile] = useState<User | null>(null);
  const [learningProgress, setLearningProgress] = useState<LearningProgress[]>([]);
  const [reputationHistory, setReputationHistory] = useState<ReputationHistory[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (userId) {
      loadData();
    }
  }, [userId]);

  const loadData = async () => {
    if (!userId) return;

    setLoading(true);
    try {
      const { data: profileData } = await supabase
        .from('users')
        .select('*')
        .eq('id', userId)
        .single();

      if (profileData) {
        setProfile(profileData);
      }

      const { data: progress } = await supabase
        .from('learning_progress')
        .select('*, skill:skill_id(*)')
        .eq('user_id', userId)
        .order('proficiency_level', { ascending: false });

      setLearningProgress((progress as any) || []);

      const { data: history } = await supabase
        .from('reputation_history')
        .select('*')
        .eq('user_id', userId)
        .order('created_at', { ascending: false })
        .limit(20);

      setReputationHistory(history || []);
    } finally {
      setLoading(false);
    }
  };

  const getReputationLevel = (points: number) => {
    if (points >= 1000) return { level: 'Master', color: 'text-yellow-600', bgColor: 'bg-yellow-100' };
    if (points >= 500) return { level: 'Expert', color: 'text-orange-600', bgColor: 'bg-orange-100' };
    if (points >= 250) return { level: 'Advanced', color: 'text-blue-600', bgColor: 'bg-blue-100' };
    if (points >= 100) return { level: 'Intermediate', color: 'text-green-600', bgColor: 'bg-green-100' };
    return { level: 'Beginner', color: 'text-gray-600', bgColor: 'bg-gray-100' };
  };

  const getProficiencyColor = (level: string) => {
    switch (level) {
      case 'expert':
        return 'bg-yellow-100 text-yellow-700';
      case 'advanced':
        return 'bg-orange-100 text-orange-700';
      case 'intermediate':
        return 'bg-blue-100 text-blue-700';
      default:
        return 'bg-gray-100 text-gray-700';
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (!profile) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p className="text-gray-600">User not found</p>
      </div>
    );
  }

  const reputationLevel = getReputationLevel(profile.reputation_points);
  const progressPercentage = (profile.reputation_points % 500) / 5;

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-6xl mx-auto px-4">
        <h1 className="text-3xl font-bold text-gray-900 mb-8">{profile.username}'s Reputation & Progress</h1>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-8">
            {/* Reputation Overview */}
            <div className="bg-white rounded-lg shadow-md p-8">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-bold text-gray-900">Reputation Level</h2>
                <TrendingUp className="text-blue-600" size={32} />
              </div>

              <div className="flex items-center gap-8 mb-8">
                <div>
                  <p className={`text-4xl font-bold ${reputationLevel.color}`}>
                    {reputationLevel.level}
                  </p>
                  <p className="text-gray-600 mt-2">{profile.reputation_points.toLocaleString()} points</p>
                </div>

                <div className="flex-1">
                  <div className="bg-gray-200 rounded-full h-4 overflow-hidden">
                    <div
                      className="bg-gradient-to-r from-blue-600 to-blue-400 h-full transition-all duration-300"
                      style={{ width: `${Math.min(progressPercentage, 100)}%` }}
                    />
                  </div>
                  <p className="text-sm text-gray-600 mt-2">
                    {profile.reputation_points % 500} / 500 to next level
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
                  <p className="text-sm text-gray-600">Total Swaps</p>
                  <p className="text-2xl font-bold text-blue-600">{profile.total_reviews}</p>
                </div>
                <div className="p-4 bg-yellow-50 rounded-lg border border-yellow-200">
                  <p className="text-sm text-gray-600">Average Rating</p>
                  <p className="text-2xl font-bold text-yellow-600">{profile.average_rating.toFixed(1)}</p>
                </div>
                <div className="p-4 bg-green-50 rounded-lg border border-green-200">
                  <p className="text-sm text-gray-600">Community Member</p>
                  <p className="text-2xl font-bold text-green-600">
                    {Math.floor((new Date().getTime() - new Date(profile.created_at).getTime()) / (1000 * 60 * 60 * 24))}d
                  </p>
                </div>
              </div>
            </div>

            {/* Learning Progress */}
            <div className="bg-white rounded-lg shadow-md p-8">
              <div className="flex items-center gap-2 mb-6">
                <BookOpen className="text-green-600" size={28} />
                <h2 className="text-2xl font-bold text-gray-900">Learning Progress</h2>
              </div>

              {learningProgress.length > 0 ? (
                <div className="space-y-4">
                  {learningProgress.map((progress) => (
                    <div key={progress.id} className="p-4 bg-gray-50 rounded-lg border border-gray-200">
                      <div className="flex items-start justify-between mb-3">
                        <div>
                          <h3 className="font-semibold text-gray-900">{progress.skill?.name}</h3>
                          <span className={`inline-block px-3 py-1 rounded-full text-xs font-semibold mt-1 ${getProficiencyColor(progress.proficiency_level)}`}>
                            {progress.proficiency_level.charAt(0).toUpperCase() + progress.proficiency_level.slice(1)}
                          </span>
                        </div>
                        <div className="text-right">
                          <p className="text-lg font-bold text-gray-900">{progress.swaps_completed}</p>
                          <p className="text-xs text-gray-600">completed swaps</p>
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-4 text-sm text-gray-600">
                        <p>Total hours learned: {progress.total_hours_learned.toFixed(1)}h</p>
                        {progress.last_practiced_at && (
                          <p>Last practiced: {new Date(progress.last_practiced_at).toLocaleDateString()}</p>
                        )}
                      </div>

                      <div className="mt-3 bg-white rounded h-2">
                        <div
                          className="bg-green-500 h-full rounded"
                          style={{
                            width: `${Math.min((progress.swaps_completed / 10) * 100, 100)}%`,
                          }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-gray-500 text-center py-8">No learning progress yet</p>
              )}
            </div>

            {/* Reputation History */}
            <div className="bg-white rounded-lg shadow-md p-8">
              <div className="flex items-center gap-2 mb-6">
                <Zap className="text-orange-600" size={28} />
                <h2 className="text-2xl font-bold text-gray-900">Reputation History</h2>
              </div>

              {reputationHistory.length > 0 ? (
                <div className="space-y-3">
                  {reputationHistory.map((item) => (
                    <div key={item.id} className="flex items-start justify-between p-4 bg-gradient-to-r from-orange-50 to-yellow-50 rounded-lg border border-orange-200">
                      <div className="flex-1">
                        <p className="font-semibold text-gray-900">{item.reason}</p>
                        <p className="text-sm text-gray-600 mt-1">
                          {new Date(item.created_at).toLocaleDateString()}
                        </p>
                      </div>
                      <div className={`text-lg font-bold ${item.points > 0 ? 'text-green-600' : 'text-red-600'}`}>
                        {item.points > 0 ? '+' : ''}{item.points}
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-gray-500 text-center py-8">No reputation history yet</p>
              )}
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-8">
            {/* Badges */}
            <div className="bg-white rounded-lg shadow-md p-6">
              <div className="flex items-center gap-2 mb-6">
                <Award className="text-amber-600" size={24} />
                <h2 className="text-xl font-bold text-gray-900">Badges & Achievements</h2>
              </div>

              <BadgeDisplay userId={profile.id} />
            </div>

            {/* Milestones */}
            <div className="bg-white rounded-lg shadow-md p-6">
              <h3 className="font-semibold text-gray-900 mb-4">Upcoming Milestones</h3>
              <div className="space-y-3">
                <div className="p-3 bg-gray-50 rounded-lg border border-gray-200">
                  <p className="text-sm font-semibold text-gray-900">5 Successful Swaps</p>
                  <div className="mt-2 bg-gray-200 rounded h-2">
                    <div
                      className="bg-blue-600 h-full rounded"
                      style={{ width: `${Math.min((profile.total_reviews / 5) * 100, 100)}%` }}
                    />
                  </div>
                  <p className="text-xs text-gray-600 mt-1">
                    {profile.total_reviews} / 5
                  </p>
                </div>

                <div className="p-3 bg-gray-50 rounded-lg border border-gray-200">
                  <p className="text-sm font-semibold text-gray-900">Expert Rating (4.5+)</p>
                  <div className="mt-2 bg-gray-200 rounded h-2">
                    <div
                      className="bg-yellow-600 h-full rounded"
                      style={{ width: `${Math.min((profile.average_rating / 4.5) * 100, 100)}%` }}
                    />
                  </div>
                  <p className="text-xs text-gray-600 mt-1">
                    {profile.average_rating.toFixed(1)} / 4.5
                  </p>
                </div>

                <div className="p-3 bg-gray-50 rounded-lg border border-gray-200">
                  <p className="text-sm font-semibold text-gray-900">Reputation Master (1000pts)</p>
                  <div className="mt-2 bg-gray-200 rounded h-2">
                    <div
                      className="bg-orange-600 h-full rounded"
                      style={{ width: `${Math.min((profile.reputation_points / 1000) * 100, 100)}%` }}
                    />
                  </div>
                  <p className="text-xs text-gray-600 mt-1">
                    {profile.reputation_points} / 1000
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
