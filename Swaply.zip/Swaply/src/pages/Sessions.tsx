import React, { useEffect, useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { supabase } from '../lib/supabase';
import { Session, Skill } from '../types';
import {
  Calendar,
  Users,
  Plus,
  MapPin,
  Clock,
  Link as LinkIcon,
  X,
  Video,
  Monitor,
  ChevronRight,
  UserCheck,
  Trash2,
  LogOut,
  ExternalLink,
  BookOpen,
} from 'lucide-react';

type Tab = 'browse' | 'mine' | 'attending';

const DURATION_OPTIONS = [
  { value: 30,  label: '30 minutes'  },
  { value: 45,  label: '45 minutes'  },
  { value: 60,  label: '1 hour'      },
  { value: 90,  label: '1.5 hours'   },
  { value: 120, label: '2 hours'     },
  { value: 180, label: '3 hours'     },
];

const formatDate = (date: string) =>
  new Date(date + 'T00:00:00').toLocaleDateString(undefined, {
    weekday: 'short', month: 'short', day: 'numeric', year: 'numeric',
  });

const formatTime = (t: string) => {
  if (!t) return '';
  const [h, m] = t.split(':');
  const hour = parseInt(h);
  const ampm = hour >= 12 ? 'PM' : 'AM';
  const h12 = hour % 12 || 12;
  return `${h12}:${m} ${ampm}`;
};

const formatDuration = (mins: number) => {
  if (mins < 60) return `${mins}m`;
  const h = Math.floor(mins / 60);
  const m = mins % 60;
  return m === 0 ? `${h}h` : `${h}h ${m}m`;
};

export const Sessions: React.FC = () => {
  const { user } = useAuth();

  const [activeTab, setActiveTab]         = useState<Tab>('browse');
  const [browseSessions, setBrowseSessions] = useState<Session[]>([]);
  const [mySessions, setMySessions]       = useState<Session[]>([]);
  const [attendingSessions, setAttending] = useState<Session[]>([]);
  const [joinedIds, setJoinedIds]         = useState<Set<string>>(new Set());
  const [participantCounts, setParticipantCounts] = useState<Map<string, number>>(new Map());
  const [allSkills, setAllSkills]         = useState<Skill[]>([]);
  const [loading, setLoading]             = useState(true);
  const [showCreate, setShowCreate]       = useState(false);
  const [actionLoading, setActionLoading] = useState<string | null>(null);
  const [createLoading, setCreateLoading] = useState(false);
  const [formError, setFormError]         = useState('');

  const defaultForm = {
    title:           '',
    description:     '',
    skillId:         '',
    sessionType:     'online' as 'online' | 'in-person',
    scheduledDate:   '',
    scheduledTime:   '',
    durationMinutes: 60,
    location:        '',
    meetingLink:     '',
    maxParticipants: 5,
  };
  const [form, setForm] = useState(defaultForm);

  useEffect(() => { loadData(); }, [user]);

  const loadData = async () => {
    setLoading(true);
    try {
      const { data: skills } = await supabase.from('skills').select('*').order('name');
      setAllSkills(skills || []);

      const today = new Date().toISOString().split('T')[0];
      const sessionFields = `id, title, description, skill_id, creator_id, session_type,
        scheduled_date, scheduled_time, duration_minutes, location, meeting_link,
        max_participants, status, created_at, updated_at,
        skill:skill_id(id, name, category),
        creator:creator_id(id, username, profile_picture_url)`;

      const { data: browse } = await supabase
        .from('sessions')
        .select(sessionFields)
        .eq('status', 'scheduled')
        .gte('scheduled_date', today)
        .order('scheduled_date', { ascending: true });

      setBrowseSessions((browse as any) || []);

      let myIds: string[] = [];
      let joinedIdList: string[] = [];

      if (user) {
        const { data: mine } = await supabase
          .from('sessions')
          .select(sessionFields)
          .eq('creator_id', user.id)
          .order('scheduled_date', { ascending: true });

        setMySessions((mine as any) || []);
        myIds = (mine || []).map((s: any) => s.id);

        const { data: participations } = await supabase
          .from('session_participants')
          .select('session_id')
          .eq('user_id', user.id);

        joinedIdList = (participations || []).map((p) => p.session_id);
        setJoinedIds(new Set(joinedIdList));

        if (joinedIdList.length > 0) {
          const { data: attending } = await supabase
            .from('sessions')
            .select(sessionFields)
            .in('id', joinedIdList)
            .order('scheduled_date', { ascending: true });
          setAttending((attending as any) || []);
        } else {
          setAttending([]);
        }
      }

      const allIds = [
        ...new Set([
          ...((browse || []).map((s: any) => s.id)),
          ...myIds,
          ...joinedIdList,
        ]),
      ];

      if (allIds.length > 0) {
        const { data: counts } = await supabase
          .from('session_participants')
          .select('session_id')
          .in('session_id', allIds);

        const countMap = new Map<string, number>();
        (counts || []).forEach((p) => {
          countMap.set(p.session_id, (countMap.get(p.session_id) ?? 0) + 1);
        });
        setParticipantCounts(countMap);
      }
    } finally {
      setLoading(false);
    }
  };

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    setFormError('');

    if (!form.skillId) { setFormError('Please select a skill.'); return; }
    if (!form.scheduledDate) { setFormError('Please pick a date.'); return; }
    if (!form.scheduledTime) { setFormError('Please pick a time.'); return; }

    setCreateLoading(true);
    try {
      const { data: newSession, error } = await supabase
        .from('sessions')
        .insert([{
          title:           form.title,
          description:     form.description,
          skill_id:        form.skillId,
          creator_id:      user.id,
          session_type:    form.sessionType,
          scheduled_date:  form.scheduledDate,
          scheduled_time:  form.scheduledTime,
          duration_minutes: form.durationMinutes,
          location:        form.sessionType === 'in-person' ? form.location.trim() : null,
          meeting_link:    form.sessionType === 'online'    ? form.meetingLink.trim() : null,
          max_participants: form.maxParticipants,
        }])
        .select();

      if (error) throw error;

      if (newSession?.[0]) {
        await supabase.from('session_participants').insert([{
          session_id: newSession[0].id,
          user_id:    user.id,
          role:       'teacher',
        }]);
      }

      setForm(defaultForm);
      setShowCreate(false);
      await loadData();
      setActiveTab('mine');
    } catch (err: any) {
      console.error(err);
      setFormError('Failed to create session. Please try again.');
    } finally {
      setCreateLoading(false);
    }
  };

  const handleJoin = async (sessionId: string) => {
    if (!user) return;
    setActionLoading(sessionId);
    try {
      await supabase.from('session_participants').insert([{
        session_id: sessionId,
        user_id:    user.id,
        role:       'learner',
      }]);
      await loadData();
    } catch (err) {
      console.error('Error joining session:', err);
    } finally {
      setActionLoading(null);
    }
  };

  const handleLeave = async (sessionId: string) => {
    if (!user) return;
    setActionLoading(sessionId);
    try {
      await supabase
        .from('session_participants')
        .delete()
        .eq('session_id', sessionId)
        .eq('user_id', user.id);
      await loadData();
    } catch (err) {
      console.error('Error leaving session:', err);
    } finally {
      setActionLoading(null);
    }
  };

  const handleCancel = async (sessionId: string) => {
    if (!user) return;
    setActionLoading(sessionId);
    try {
      await supabase
        .from('sessions')
        .update({ status: 'cancelled', updated_at: new Date().toISOString() })
        .eq('id', sessionId)
        .eq('creator_id', user.id);
      await loadData();
    } catch (err) {
      console.error('Error cancelling session:', err);
    } finally {
      setActionLoading(null);
    }
  };

  const isJoined = (sessionId: string) => joinedIds.has(sessionId);
  const isCreator = (session: Session) => session.creator_id === user?.id;
  const isMember  = (session: Session) => isJoined(session.id);
  const canSeePrivateInfo = (session: Session) => isCreator(session) || isMember(session);

  const tabs: { key: Tab; label: string; count?: number }[] = [
    { key: 'browse',    label: 'Browse Sessions',  count: browseSessions.length    },
    { key: 'mine',      label: 'My Sessions',      count: mySessions.length        },
    { key: 'attending', label: "I'm Attending",    count: attendingSessions.length },
  ];

  const renderCard = (session: Session, variant: Tab) => {
    const count    = participantCounts.get(session.id) ?? 0;
    const isFull   = count >= session.max_participants;
    const isLoading = actionLoading === session.id;
    const myJoined  = isJoined(session.id);
    const myCreated = isCreator(session);
    const seePrivate = canSeePrivateInfo(session);
    const isOnline = session.session_type === 'online';
    const creator = (session as any).creator;
    const skill   = (session as any).skill;

    return (
      <div key={session.id} className="bg-white rounded-2xl border border-gray-200 shadow-sm hover:shadow-md transition overflow-hidden flex flex-col">
        {/* Card top bar */}
        <div className={`h-1.5 ${isOnline ? 'bg-blue-500' : 'bg-emerald-500'}`} />

        <div className="p-5 flex-1 flex flex-col gap-4">
          {/* Header */}
          <div className="flex items-start justify-between gap-3">
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 mb-1">
                <span className={`inline-flex items-center gap-1 text-[11px] font-bold px-2 py-0.5 rounded-full ${
                  isOnline
                    ? 'bg-blue-100 text-blue-700'
                    : 'bg-emerald-100 text-emerald-700'
                }`}>
                  {isOnline ? <Monitor size={10} /> : <MapPin size={10} />}
                  {isOnline ? 'Online' : 'In-person'}
                </span>
                {skill && (
                  <span className="inline-flex items-center gap-1 text-[11px] font-semibold px-2 py-0.5 rounded-full bg-purple-100 text-purple-700">
                    <BookOpen size={10} />
                    {skill.name}
                  </span>
                )}
              </div>
              <h3 className="text-base font-bold text-gray-900 leading-snug">{session.title}</h3>
            </div>

            {/* Participant counter */}
            <div className={`flex-shrink-0 flex flex-col items-center px-3 py-1.5 rounded-xl text-xs font-bold ${
              isFull ? 'bg-red-50 text-red-600' : 'bg-gray-100 text-gray-600'
            }`}>
              <Users size={13} className="mb-0.5" />
              {count}/{session.max_participants}
            </div>
          </div>

          {/* Description */}
          {session.description && (
            <p className="text-sm text-gray-600 leading-relaxed line-clamp-2">{session.description}</p>
          )}

          {/* Details grid */}
          <div className="grid grid-cols-2 gap-2">
            <div className="flex items-center gap-2 bg-gray-50 rounded-lg px-3 py-2">
              <Calendar size={14} className="text-gray-400 flex-shrink-0" />
              <span className="text-xs text-gray-700 font-medium truncate">
                {formatDate(session.scheduled_date)}
              </span>
            </div>
            <div className="flex items-center gap-2 bg-gray-50 rounded-lg px-3 py-2">
              <Clock size={14} className="text-gray-400 flex-shrink-0" />
              <span className="text-xs text-gray-700 font-medium">
                {formatTime(session.scheduled_time)} · {formatDuration(session.duration_minutes)}
              </span>
            </div>
          </div>

          {/* Location / Meeting link — only for creator or joined participants */}
          {isOnline && session.meeting_link && seePrivate && (
            <a
              href={session.meeting_link}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2 bg-blue-50 border border-blue-100 rounded-lg px-3 py-2.5 hover:bg-blue-100 transition group"
            >
              <Video size={14} className="text-blue-500 flex-shrink-0" />
              <span className="text-xs text-blue-700 font-semibold flex-1 truncate">{session.meeting_link}</span>
              <ExternalLink size={12} className="text-blue-400 flex-shrink-0 group-hover:text-blue-600" />
            </a>
          )}
          {isOnline && session.meeting_link && !seePrivate && (
            <div className="flex items-center gap-2 bg-gray-50 border border-gray-200 rounded-lg px-3 py-2.5">
              <Video size={14} className="text-gray-400 flex-shrink-0" />
              <span className="text-xs text-gray-400 italic">Meeting link visible after joining</span>
            </div>
          )}
          {isOnline && !session.meeting_link && (
            <div className="flex items-center gap-2 bg-gray-50 rounded-lg px-3 py-2.5">
              <Video size={14} className="text-gray-400 flex-shrink-0" />
              <span className="text-xs text-gray-400">No meeting link provided</span>
            </div>
          )}
          {!isOnline && session.location && (
            <div className="flex items-start gap-2 bg-emerald-50 border border-emerald-100 rounded-lg px-3 py-2.5">
              <MapPin size={14} className="text-emerald-500 flex-shrink-0 mt-0.5" />
              <span className="text-xs text-emerald-800 font-medium">{session.location}</span>
            </div>
          )}
          {!isOnline && !session.location && (
            <div className="flex items-center gap-2 bg-gray-50 rounded-lg px-3 py-2.5">
              <MapPin size={14} className="text-gray-400 flex-shrink-0" />
              <span className="text-xs text-gray-400">Location to be announced</span>
            </div>
          )}

          {/* Host */}
          {creator && !myCreated && (
            <div className="flex items-center gap-2 pt-1 border-t border-gray-100">
              <div className="w-6 h-6 bg-gradient-to-br from-blue-500 to-blue-700 rounded-full flex items-center justify-center flex-shrink-0">
                <span className="text-white text-[10px] font-bold">
                  {creator.username?.charAt(0).toUpperCase()}
                </span>
              </div>
              <span className="text-xs text-gray-500">
                Hosted by <span className="font-semibold text-gray-700">{creator.username}</span>
              </span>
            </div>
          )}
          {myCreated && (
            <div className="flex items-center gap-1.5 pt-1 border-t border-gray-100">
              <UserCheck size={14} className="text-blue-500" />
              <span className="text-xs font-semibold text-blue-600">You are hosting this session</span>
            </div>
          )}
        </div>

        {/* Action footer */}
        <div className="px-5 pb-4 flex gap-2">
          {variant === 'browse' && !myCreated && (
            myJoined ? (
              <button
                disabled
                className="flex-1 py-2 text-sm font-semibold bg-green-100 text-green-700 rounded-xl cursor-default"
              >
                ✓ Joined
              </button>
            ) : isFull ? (
              <button disabled className="flex-1 py-2 text-sm font-semibold bg-gray-100 text-gray-400 rounded-xl cursor-not-allowed">
                Session Full
              </button>
            ) : (
              <button
                onClick={() => handleJoin(session.id)}
                disabled={isLoading}
                className="flex-1 flex items-center justify-center gap-2 py-2 text-sm font-semibold bg-blue-600 text-white rounded-xl hover:bg-blue-700 transition disabled:opacity-50"
              >
                {isLoading
                  ? <div className="animate-spin rounded-full h-3.5 w-3.5 border-b-2 border-white" />
                  : <><ChevronRight size={15} /> Join Session</>
                }
              </button>
            )
          )}

          {variant === 'mine' && (
            <button
              onClick={() => handleCancel(session.id)}
              disabled={isLoading || session.status === 'cancelled'}
              className="flex items-center gap-1.5 px-4 py-2 text-sm font-semibold text-red-600 border border-red-200 bg-red-50 rounded-xl hover:bg-red-100 transition disabled:opacity-40"
            >
              {isLoading
                ? <div className="animate-spin rounded-full h-3.5 w-3.5 border-b-2 border-red-400" />
                : <Trash2 size={14} />
              }
              {session.status === 'cancelled' ? 'Cancelled' : 'Cancel Session'}
            </button>
          )}

          {variant === 'attending' && !myCreated && (
            <button
              onClick={() => handleLeave(session.id)}
              disabled={isLoading}
              className="flex items-center gap-1.5 px-4 py-2 text-sm font-semibold text-gray-600 border border-gray-200 rounded-xl hover:bg-gray-50 transition disabled:opacity-50"
            >
              {isLoading
                ? <div className="animate-spin rounded-full h-3.5 w-3.5 border-b-2 border-gray-400" />
                : <LogOut size={14} />
              }
              Leave Session
            </button>
          )}
        </div>
      </div>
    );
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  const currentSessions =
    activeTab === 'browse'    ? browseSessions :
    activeTab === 'mine'      ? mySessions :
                                attendingSessions;

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-6xl mx-auto px-4">

        {/* Page header */}
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Learning Sessions</h1>
            <p className="text-gray-500 mt-1">Schedule and join skill-learning sessions</p>
          </div>
          <button
            onClick={() => { setShowCreate(true); setFormError(''); }}
            className="flex items-center gap-2 bg-blue-600 text-white px-5 py-2.5 rounded-xl hover:bg-blue-700 transition font-semibold shadow-sm"
          >
            <Plus size={18} />
            Create Session
          </button>
        </div>

        {/* Tabs */}
        <div className="flex border-b border-gray-200 mb-6 bg-white rounded-t-xl overflow-hidden shadow-sm">
          {tabs.map((tab) => (
            <button
              key={tab.key}
              onClick={() => setActiveTab(tab.key)}
              className={`flex-1 py-3.5 text-sm font-semibold transition border-b-2 ${
                activeTab === tab.key
                  ? 'border-blue-600 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700'
              }`}
            >
              {tab.label}
              {tab.count != null && tab.count > 0 && (
                <span className={`ml-1.5 text-xs font-bold px-1.5 py-0.5 rounded-full ${
                  activeTab === tab.key ? 'bg-blue-100 text-blue-700' : 'bg-gray-100 text-gray-500'
                }`}>
                  {tab.count}
                </span>
              )}
            </button>
          ))}
        </div>

        {/* Session grid */}
        {currentSessions.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {currentSessions.map((s) => renderCard(s, activeTab))}
          </div>
        ) : (
          <div className="text-center py-20 text-gray-400">
            <Calendar size={44} className="mx-auto mb-4 opacity-30" />
            <p className="text-base font-medium text-gray-500">
              {activeTab === 'browse'
                ? 'No sessions scheduled yet.'
                : activeTab === 'mine'
                ? "You haven't created any sessions yet."
                : "You haven't joined any sessions yet."}
            </p>
            {activeTab === 'browse' && (
              <p className="text-sm text-gray-400 mt-1">Create one to get started!</p>
            )}
          </div>
        )}
      </div>

      {/* Create Session Modal */}
      {showCreate && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm overflow-y-auto">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl my-4">
            {/* Modal header */}
            <div className="flex items-center justify-between px-6 py-5 border-b border-gray-100">
              <div>
                <h2 className="text-xl font-bold text-gray-900">Schedule a New Session</h2>
                <p className="text-sm text-gray-500 mt-0.5">Fill in the details for your learning session</p>
              </div>
              <button
                onClick={() => setShowCreate(false)}
                className="p-1.5 rounded-lg hover:bg-gray-100 text-gray-400 hover:text-gray-600 transition"
              >
                <X size={20} />
              </button>
            </div>

            <form onSubmit={handleCreate} className="px-6 py-6 space-y-5">
              {/* Title */}
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-1.5">Session Title <span className="text-red-500">*</span></label>
                <input
                  type="text"
                  value={form.title}
                  onChange={(e) => setForm({ ...form, title: e.target.value })}
                  required
                  placeholder="e.g., Spanish Conversation Practice"
                  className="w-full px-4 py-2.5 border border-gray-200 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition"
                />
              </div>

              {/* Skill */}
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-1.5">Skill <span className="text-red-500">*</span></label>
                <select
                  value={form.skillId}
                  onChange={(e) => setForm({ ...form, skillId: e.target.value })}
                  required
                  className="w-full px-4 py-2.5 border border-gray-200 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition bg-white"
                >
                  <option value="">Select a skill</option>
                  {allSkills.map((skill) => (
                    <option key={skill.id} value={skill.id}>{skill.name}</option>
                  ))}
                </select>
              </div>

              {/* Description */}
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-1.5">Description</label>
                <textarea
                  value={form.description}
                  onChange={(e) => setForm({ ...form, description: e.target.value })}
                  rows={3}
                  placeholder="What will participants learn? What should they prepare?"
                  className="w-full px-4 py-2.5 border border-gray-200 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition resize-none"
                />
              </div>

              {/* Session type toggle */}
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-1.5">Session Type</label>
                <div className="grid grid-cols-2 gap-3">
                  <button
                    type="button"
                    onClick={() => setForm({ ...form, sessionType: 'online' })}
                    className={`flex items-center justify-center gap-2 py-3 rounded-xl border-2 text-sm font-semibold transition ${
                      form.sessionType === 'online'
                        ? 'border-blue-500 bg-blue-50 text-blue-700'
                        : 'border-gray-200 text-gray-500 hover:border-gray-300'
                    }`}
                  >
                    <Monitor size={16} />
                    Online
                  </button>
                  <button
                    type="button"
                    onClick={() => setForm({ ...form, sessionType: 'in-person' })}
                    className={`flex items-center justify-center gap-2 py-3 rounded-xl border-2 text-sm font-semibold transition ${
                      form.sessionType === 'in-person'
                        ? 'border-emerald-500 bg-emerald-50 text-emerald-700'
                        : 'border-gray-200 text-gray-500 hover:border-gray-300'
                    }`}
                  >
                    <MapPin size={16} />
                    In-person
                  </button>
                </div>
              </div>

              {/* Conditional field: meeting link or location */}
              {form.sessionType === 'online' ? (
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-1.5">
                    <span className="flex items-center gap-1.5">
                      <LinkIcon size={13} />
                      Meeting Link
                      <span className="text-gray-400 font-normal">(optional)</span>
                    </span>
                  </label>
                  <input
                    type="url"
                    value={form.meetingLink}
                    onChange={(e) => setForm({ ...form, meetingLink: e.target.value })}
                    placeholder="https://meet.google.com/xxx-yyyy-zzz"
                    className="w-full px-4 py-2.5 border border-gray-200 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition"
                  />
                  <p className="text-xs text-gray-400 mt-1">Google Meet, Zoom, Teams, etc. Only visible to joined participants.</p>
                </div>
              ) : (
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-1.5">
                    <span className="flex items-center gap-1.5">
                      <MapPin size={13} />
                      Location
                    </span>
                  </label>
                  <input
                    type="text"
                    value={form.location}
                    onChange={(e) => setForm({ ...form, location: e.target.value })}
                    placeholder="e.g., Central Library, Room 3B, New York"
                    className="w-full px-4 py-2.5 border border-gray-200 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition"
                  />
                </div>
              )}

              {/* Date and Time */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-1.5">Date <span className="text-red-500">*</span></label>
                  <input
                    type="date"
                    value={form.scheduledDate}
                    min={new Date().toISOString().split('T')[0]}
                    onChange={(e) => setForm({ ...form, scheduledDate: e.target.value })}
                    required
                    className="w-full px-4 py-2.5 border border-gray-200 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition"
                  />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-1.5">Time <span className="text-red-500">*</span></label>
                  <input
                    type="time"
                    value={form.scheduledTime}
                    onChange={(e) => setForm({ ...form, scheduledTime: e.target.value })}
                    required
                    className="w-full px-4 py-2.5 border border-gray-200 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition"
                  />
                </div>
              </div>

              {/* Duration and Max Participants */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-1.5">Duration</label>
                  <select
                    value={form.durationMinutes}
                    onChange={(e) => setForm({ ...form, durationMinutes: parseInt(e.target.value) })}
                    className="w-full px-4 py-2.5 border border-gray-200 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition bg-white"
                  >
                    {DURATION_OPTIONS.map((opt) => (
                      <option key={opt.value} value={opt.value}>{opt.label}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-1.5">Max Participants</label>
                  <input
                    type="number"
                    min={2}
                    max={50}
                    value={form.maxParticipants}
                    onChange={(e) => setForm({ ...form, maxParticipants: parseInt(e.target.value) })}
                    className="w-full px-4 py-2.5 border border-gray-200 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition"
                  />
                </div>
              </div>

              {formError && (
                <div className="bg-red-50 border border-red-200 rounded-xl px-4 py-3">
                  <p className="text-sm text-red-600">{formError}</p>
                </div>
              )}

              {/* Buttons */}
              <div className="flex gap-3 pt-1">
                <button
                  type="button"
                  onClick={() => setShowCreate(false)}
                  className="flex-1 py-2.5 border border-gray-200 text-gray-600 rounded-xl text-sm font-semibold hover:bg-gray-50 transition"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={createLoading}
                  className="flex-1 flex items-center justify-center gap-2 py-2.5 bg-blue-600 text-white rounded-xl text-sm font-semibold hover:bg-blue-700 transition disabled:opacity-50"
                >
                  {createLoading
                    ? <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white" />
                    : <><Calendar size={15} /> Schedule Session</>
                  }
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
