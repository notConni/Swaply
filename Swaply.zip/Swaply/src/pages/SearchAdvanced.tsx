import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { supabase } from '../lib/supabase';
import { User, UserSkillOffered, UserSkillWanted, Skill } from '../types';
import { Search as SearchIcon, MessageSquare, Star, MapPin, Zap } from 'lucide-react';

interface UserWithSkills {
  user: User;
  offeredSkills: UserSkillOffered[];
  wantedSkills: UserSkillWanted[];
}

export const SearchAdvanced: React.FC = () => {
  const { user } = useAuth();
  const [allUsers, setAllUsers] = useState<UserWithSkills[]>([]);
  const [filteredUsers, setFilteredUsers] = useState<UserWithSkills[]>([]);
  const [allSkills, setAllSkills] = useState<Skill[]>([]);
  const [loading, setLoading] = useState(true);

  // Filters
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedSkill, setSelectedSkill] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('');
  const [proficiencyLevel, setProficiencyLevel] = useState('');
  const [sessionType, setSessionType] = useState('');
  const [location, setLocation] = useState('');
  const [matchMode, setMatchMode] = useState<'all' | 'matches'>('all');

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setLoading(true);
    try {
      const { data: skills } = await supabase.from('skills').select('*');
      setAllSkills(skills || []);

      const { data: users } = await supabase
        .from('users')
        .select('*')
        .neq('id', user?.id)
        .eq('is_public', true);

      if (users) {
        const usersWithSkills: UserWithSkills[] = [];

        for (const u of users) {
          const { data: offered } = await supabase
            .from('user_skills_offered')
            .select('*, skill:skills(*)')
            .eq('user_id', u.id);

          const { data: wanted } = await supabase
            .from('user_skills_wanted')
            .select('*, skill:skills(*)')
            .eq('user_id', u.id);

          usersWithSkills.push({
            user: u,
            offeredSkills: offered || [],
            wantedSkills: wanted || [],
          });
        }

        setAllUsers(usersWithSkills);
        setFilteredUsers(usersWithSkills);
      }
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    let results = allUsers;

    // Match mode filter
    if (matchMode === 'matches') {
      results = results.filter((u) => calculateMatchScore(u) > 0);
    }

    // Search query
    if (searchQuery) {
      results = results.filter(
        (u) =>
          u.user.username.toLowerCase().includes(searchQuery.toLowerCase()) ||
          u.user.bio.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }

    // Skill filter
    if (selectedSkill) {
      results = results.filter((u) =>
        u.offeredSkills.some((s) => s.skill_id === selectedSkill)
      );
    }

    // Category filter
    if (selectedCategory) {
      results = results.filter((u) =>
        u.offeredSkills.some((s) => s.skill?.category === selectedCategory)
      );
    }

    // Proficiency level filter
    if (proficiencyLevel) {
      results = results.filter((u) =>
        u.offeredSkills.some((s) => s.proficiency_level === proficiencyLevel)
      );
    }

    // Session type filter
    if (sessionType) {
      results = results.filter((u) => u.user.session_preference === sessionType || u.user.session_preference === 'both');
    }

    // Location filter
    if (location) {
      results = results.filter((u) =>
        u.user.city.toLowerCase().includes(location.toLowerCase())
      );
    }

    setFilteredUsers(results);
  }, [searchQuery, selectedSkill, selectedCategory, proficiencyLevel, sessionType, location, matchMode, allUsers]);

  const calculateMatchScore = (userWithSkills: UserWithSkills): number => {
    if (!user?.id) return 0;

    let score = 0;
    const currentUserOffered = allUsers.find((u) => u.user.id === user.id)?.offeredSkills || [];
    const currentUserWanted = allUsers.find((u) => u.user.id === user.id)?.wantedSkills || [];

    currentUserOffered.forEach((offered) => {
      if (userWithSkills.wantedSkills.some((w) => w.skill_id === offered.skill_id)) {
        score += 2;
      }
    });

    currentUserWanted.forEach((wanted) => {
      if (userWithSkills.offeredSkills.some((o) => o.skill_id === wanted.skill_id)) {
        score += 2;
      }
    });

    return score;
  };

  const getCategories = () => {
    return Array.from(new Set(allSkills.map((s) => s.category)));
  };

  const matchedUsers = filteredUsers.filter((u) => calculateMatchScore(u) > 0);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4">
        <h1 className="text-3xl font-bold text-gray-900 mb-8">Find Learning Partners</h1>

        {/* Advanced Filters */}
        <div className="bg-white rounded-lg shadow-md p-6 mb-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-4">
            {/* Search */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Search by Name</label>
              <div className="relative">
                <SearchIcon className="absolute left-3 top-3 text-gray-400" size={20} />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search users..."
                  className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none transition"
                />
              </div>
            </div>

            {/* Location */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Location</label>
              <input
                type="text"
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                placeholder="City or region..."
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none transition"
              />
            </div>

            {/* Category */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Skill Category</label>
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none transition"
              >
                <option value="">All categories</option>
                {getCategories().map((cat) => (
                  <option key={cat} value={cat}>
                    {cat}
                  </option>
                ))}
              </select>
            </div>

            {/* Skill */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Specific Skill</label>
              <select
                value={selectedSkill}
                onChange={(e) => setSelectedSkill(e.target.value)}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none transition"
              >
                <option value="">All skills</option>
                {allSkills.map((skill) => (
                  <option key={skill.id} value={skill.id}>
                    {skill.name}
                  </option>
                ))}
              </select>
            </div>

            {/* Proficiency */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Proficiency Level</label>
              <select
                value={proficiencyLevel}
                onChange={(e) => setProficiencyLevel(e.target.value)}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none transition"
              >
                <option value="">Any level</option>
                <option value="beginner">Beginner</option>
                <option value="intermediate">Intermediate</option>
                <option value="advanced">Advanced</option>
                <option value="expert">Expert</option>
              </select>
            </div>

            {/* Session Type */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Session Type</label>
              <select
                value={sessionType}
                onChange={(e) => setSessionType(e.target.value)}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none transition"
              >
                <option value="">Any type</option>
                <option value="online">Online Only</option>
                <option value="in-person">In-person Only</option>
              </select>
            </div>

            {/* Match Mode */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">View Mode</label>
              <select
                value={matchMode}
                onChange={(e) => setMatchMode(e.target.value as 'all' | 'matches')}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none transition"
              >
                <option value="all">All Users ({filteredUsers.length})</option>
                <option value="matches">Perfect Matches ({matchedUsers.length})</option>
              </select>
            </div>
          </div>

          {(searchQuery || selectedSkill || selectedCategory || proficiencyLevel || sessionType || location) && (
            <button
              onClick={() => {
                setSearchQuery('');
                setSelectedSkill('');
                setSelectedCategory('');
                setProficiencyLevel('');
                setSessionType('');
                setLocation('');
              }}
              className="text-blue-600 hover:text-blue-700 text-sm font-semibold"
            >
              Clear Filters
            </button>
          )}
        </div>

        {/* Results Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredUsers.length > 0 ? (
            filteredUsers.map((userWithSkills) => {
              const matchScore = calculateMatchScore(userWithSkills);
              const isPerfectMatch = matchScore > 0;

              return (
                <div
                  key={userWithSkills.user.id}
                  className={`bg-white rounded-lg shadow-md overflow-hidden transition hover:shadow-lg ${
                    isPerfectMatch ? 'border-2 border-green-500 relative' : ''
                  }`}
                >
                  {isPerfectMatch && (
                    <div className="absolute top-3 right-3 bg-green-100 text-green-700 px-3 py-1 rounded-full text-xs font-semibold flex items-center gap-1">
                      <Zap size={14} />
                      Perfect Match
                    </div>
                  )}

                  <div className="p-6">
                    <div className="flex items-start gap-4 mb-4">
                      <div className="w-16 h-16 bg-gradient-to-br from-blue-400 to-blue-600 rounded-lg flex items-center justify-center flex-shrink-0 text-white text-2xl font-bold">
                        {userWithSkills.user.username.charAt(0).toUpperCase()}
                      </div>

                      <div className="flex-1">
                        <Link
                          to={`/profile/${userWithSkills.user.id}`}
                          className="text-lg font-bold text-gray-900 hover:text-blue-600 transition"
                        >
                          {userWithSkills.user.username}
                        </Link>
                        <div className="flex items-center gap-1 mt-1">
                          <Star size={16} className="fill-yellow-400 text-yellow-400" />
                          <span className="text-sm text-gray-600">{userWithSkills.user.average_rating.toFixed(1)}</span>
                        </div>
                        {userWithSkills.user.city && (
                          <div className="flex items-center gap-1 text-sm text-gray-600 mt-1">
                            <MapPin size={14} />
                            {userWithSkills.user.city}
                          </div>
                        )}
                      </div>
                    </div>

                    {userWithSkills.user.bio && (
                      <p className="text-sm text-gray-600 mb-4 line-clamp-2">{userWithSkills.user.bio}</p>
                    )}

                    {userWithSkills.offeredSkills.length > 0 && (
                      <div className="mb-3">
                        <h4 className="font-semibold text-gray-900 mb-2 text-sm">Can Teach</h4>
                        <div className="flex flex-wrap gap-2">
                          {userWithSkills.offeredSkills.slice(0, 2).map((skill) => (
                            <span
                              key={skill.id}
                              className="inline-block bg-blue-100 text-blue-700 px-2 py-1 rounded-full text-xs font-medium"
                            >
                              {skill.skill?.name}
                            </span>
                          ))}
                          {userWithSkills.offeredSkills.length > 2 && (
                            <span className="text-xs text-gray-500">+{userWithSkills.offeredSkills.length - 2}</span>
                          )}
                        </div>
                      </div>
                    )}

                    {userWithSkills.wantedSkills.length > 0 && (
                      <div className="mb-4">
                        <h4 className="font-semibold text-gray-900 mb-2 text-sm">Wants to Learn</h4>
                        <div className="flex flex-wrap gap-2">
                          {userWithSkills.wantedSkills.slice(0, 2).map((skill) => (
                            <span
                              key={skill.id}
                              className="inline-block bg-purple-100 text-purple-700 px-2 py-1 rounded-full text-xs font-medium"
                            >
                              {skill.skill?.name}
                            </span>
                          ))}
                          {userWithSkills.wantedSkills.length > 2 && (
                            <span className="text-xs text-gray-500">+{userWithSkills.wantedSkills.length - 2}</span>
                          )}
                        </div>
                      </div>
                    )}

                    <div className="flex gap-2 pt-4 border-t border-gray-200">
                      <Link
                        to={`/profile/${userWithSkills.user.id}`}
                        className="flex-1 text-center bg-gray-100 text-gray-700 py-2 rounded-lg hover:bg-gray-200 transition font-medium text-sm"
                      >
                        View Profile
                      </Link>
                      <Link
                        to={`/messages?user=${userWithSkills.user.id}`}
                        className="flex-1 text-center bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700 transition font-medium text-sm flex items-center justify-center gap-2"
                      >
                        <MessageSquare size={16} />
                        Message
                      </Link>
                    </div>
                  </div>
                </div>
              );
            })
          ) : (
            <div className="col-span-full text-center py-12">
              <p className="text-gray-600 text-lg">No users found matching your criteria.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
