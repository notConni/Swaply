import React, { useEffect, useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { supabase } from '../lib/supabase';
import { Skill, UserSkillOffered, UserSkillWanted } from '../types';
import { X, Trash2 } from 'lucide-react';

export const Skills: React.FC = () => {
  const { user } = useAuth();
  const [allSkills, setAllSkills] = useState<Skill[]>([]);
  const [userOfferedSkills, setUserOfferedSkills] = useState<UserSkillOffered[]>([]);
  const [userWantedSkills, setUserWantedSkills] = useState<UserSkillWanted[]>([]);
  const [showAddOffered, setShowAddOffered] = useState(false);
  const [showAddWanted, setShowAddWanted] = useState(false);
  const [selectedOfferedSkill, setSelectedOfferedSkill] = useState<string>('');
  const [selectedWantedSkill, setSelectedWantedSkill] = useState<string>('');
  const [proficiencyLevel, setProficiencyLevel] = useState<'beginner' | 'intermediate' | 'advanced' | 'expert'>('beginner');
  const [yearsOfExperience, setYearsOfExperience] = useState(0);
  const [skillDescription, setSkillDescription] = useState('');
  const [priority, setPriority] = useState(0);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user) {
      loadData();
    }
  }, [user]);

  const loadData = async () => {
    if (!user) return;

    setLoading(true);
    try {
      const { data: skills } = await supabase.from('skills').select('*');
      setAllSkills(skills || []);

      const { data: offered } = await supabase
        .from('user_skills_offered')
        .select('*, skill:skills(*)')
        .eq('user_id', user.id);

      setUserOfferedSkills(offered || []);

      const { data: wanted } = await supabase
        .from('user_skills_wanted')
        .select('*, skill:skills(*)')
        .eq('user_id', user.id);

      setUserWantedSkills(wanted || []);
    } finally {
      setLoading(false);
    }
  };

  const addOfferedSkill = async () => {
    if (!user || !selectedOfferedSkill) return;

    try {
      await supabase.from('user_skills_offered').insert([
        {
          user_id: user.id,
          skill_id: selectedOfferedSkill,
          proficiency_level: proficiencyLevel,
          years_of_experience: yearsOfExperience,
          description: skillDescription,
        },
      ]);

      setShowAddOffered(false);
      setSelectedOfferedSkill('');
      setProficiencyLevel('beginner');
      setYearsOfExperience(0);
      setSkillDescription('');
      loadData();
    } catch (err) {
      console.error('Error adding skill:', err);
    }
  };

  const addWantedSkill = async () => {
    if (!user || !selectedWantedSkill) return;

    try {
      await supabase.from('user_skills_wanted').insert([
        {
          user_id: user.id,
          skill_id: selectedWantedSkill,
          priority,
        },
      ]);

      setShowAddWanted(false);
      setSelectedWantedSkill('');
      setPriority(0);
      loadData();
    } catch (err) {
      console.error('Error adding skill:', err);
    }
  };

  const deleteOfferedSkill = async (skillId: string) => {
    try {
      await supabase.from('user_skills_offered').delete().eq('id', skillId);
      loadData();
    } catch (err) {
      console.error('Error deleting skill:', err);
    }
  };

  const deleteWantedSkill = async (skillId: string) => {
    try {
      await supabase.from('user_skills_wanted').delete().eq('id', skillId);
      loadData();
    } catch (err) {
      console.error('Error deleting skill:', err);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  const availableOfferedSkills = allSkills.filter(
    (skill) => !userOfferedSkills.some((us) => us.skill_id === skill.id)
  );

  const availableWantedSkills = allSkills.filter(
    (skill) => !userWantedSkills.some((us) => us.skill_id === skill.id)
  );

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-4xl mx-auto px-4">
        <h1 className="text-3xl font-bold text-gray-900 mb-8">Manage Your Skills</h1>

        <div className="grid md:grid-cols-2 gap-8">
          {/* Offered Skills */}
          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-bold text-gray-900">Skills I Can Teach</h2>
              {!showAddOffered && (
                <button
                  onClick={() => setShowAddOffered(true)}
                  className="text-blue-600 hover:text-blue-700 text-sm font-semibold"
                >
                  + Add
                </button>
              )}
            </div>

            {showAddOffered && (
              <div className="mb-6 p-4 bg-blue-50 rounded-lg border border-blue-200">
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Skill</label>
                    <select
                      value={selectedOfferedSkill}
                      onChange={(e) => setSelectedOfferedSkill(e.target.value)}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none transition"
                    >
                      <option value="">Select a skill</option>
                      {availableOfferedSkills.map((skill) => (
                        <option key={skill.id} value={skill.id}>
                          {skill.name}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Proficiency Level</label>
                    <select
                      value={proficiencyLevel}
                      onChange={(e) => setProficiencyLevel(e.target.value as any)}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none transition"
                    >
                      <option value="beginner">Beginner</option>
                      <option value="intermediate">Intermediate</option>
                      <option value="advanced">Advanced</option>
                      <option value="expert">Expert</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Years of Experience</label>
                    <input
                      type="number"
                      min="0"
                      value={yearsOfExperience}
                      onChange={(e) => setYearsOfExperience(parseInt(e.target.value) || 0)}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none transition"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Description (Optional)</label>
                    <textarea
                      value={skillDescription}
                      onChange={(e) => setSkillDescription(e.target.value)}
                      rows={2}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none transition resize-none"
                      placeholder="Add details about your expertise..."
                    />
                  </div>

                  <div className="flex gap-2">
                    <button
                      onClick={addOfferedSkill}
                      disabled={!selectedOfferedSkill}
                      className="flex-1 bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700 transition font-semibold disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      Add Skill
                    </button>
                    <button
                      onClick={() => setShowAddOffered(false)}
                      className="flex-1 bg-gray-300 text-gray-700 py-2 rounded-lg hover:bg-gray-400 transition font-semibold"
                    >
                      Cancel
                    </button>
                  </div>
                </div>
              </div>
            )}

            <div className="space-y-3">
              {userOfferedSkills.length > 0 ? (
                userOfferedSkills.map((skill) => (
                  <div key={skill.id} className="flex items-start justify-between p-3 bg-gray-50 rounded-lg border border-gray-200">
                    <div className="flex-1">
                      <h3 className="font-semibold text-gray-900">{skill.skill?.name}</h3>
                      <p className="text-sm text-gray-600 capitalize">{skill.proficiency_level}</p>
                      {skill.years_of_experience > 0 && (
                        <p className="text-sm text-gray-600">
                          {skill.years_of_experience} year{skill.years_of_experience > 1 ? 's' : ''}
                        </p>
                      )}
                    </div>
                    <button
                      onClick={() => deleteOfferedSkill(skill.id)}
                      className="text-red-600 hover:text-red-700 transition"
                    >
                      <Trash2 size={18} />
                    </button>
                  </div>
                ))
              ) : (
                <p className="text-gray-500">No skills added yet</p>
              )}
            </div>
          </div>

          {/* Wanted Skills */}
          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-bold text-gray-900">Skills I Want to Learn</h2>
              {!showAddWanted && (
                <button
                  onClick={() => setShowAddWanted(true)}
                  className="text-blue-600 hover:text-blue-700 text-sm font-semibold"
                >
                  + Add
                </button>
              )}
            </div>

            {showAddWanted && (
              <div className="mb-6 p-4 bg-blue-50 rounded-lg border border-blue-200">
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Skill</label>
                    <select
                      value={selectedWantedSkill}
                      onChange={(e) => setSelectedWantedSkill(e.target.value)}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none transition"
                    >
                      <option value="">Select a skill</option>
                      {availableWantedSkills.map((skill) => (
                        <option key={skill.id} value={skill.id}>
                          {skill.name}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Priority (1-10)</label>
                    <input
                      type="number"
                      min="0"
                      max="10"
                      value={priority}
                      onChange={(e) => setPriority(parseInt(e.target.value) || 0)}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none transition"
                    />
                  </div>

                  <div className="flex gap-2">
                    <button
                      onClick={addWantedSkill}
                      disabled={!selectedWantedSkill}
                      className="flex-1 bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700 transition font-semibold disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      Add Skill
                    </button>
                    <button
                      onClick={() => setShowAddWanted(false)}
                      className="flex-1 bg-gray-300 text-gray-700 py-2 rounded-lg hover:bg-gray-400 transition font-semibold"
                    >
                      Cancel
                    </button>
                  </div>
                </div>
              </div>
            )}

            <div className="space-y-3">
              {userWantedSkills.length > 0 ? (
                userWantedSkills.map((skill) => (
                  <div key={skill.id} className="flex items-start justify-between p-3 bg-gray-50 rounded-lg border border-gray-200">
                    <div className="flex-1">
                      <h3 className="font-semibold text-gray-900">{skill.skill?.name}</h3>
                      <p className="text-sm text-gray-600">Priority: {skill.priority}</p>
                    </div>
                    <button
                      onClick={() => deleteWantedSkill(skill.id)}
                      className="text-red-600 hover:text-red-700 transition"
                    >
                      <Trash2 size={18} />
                    </button>
                  </div>
                ))
              ) : (
                <p className="text-gray-500">No skills added yet</p>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
