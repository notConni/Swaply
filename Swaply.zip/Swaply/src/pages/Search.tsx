import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { supabase } from '../lib/supabase';
import { User, UserSkillOffered, UserSkillWanted, Skill } from '../types';
import { Search as SearchIcon, MessageSquare, Star, ArrowLeftRight } from 'lucide-react';
import { SwapRequestModal } from '../components/SwapRequestModal';

interface UserWithSkills {
  user: User;
  offeredSkills: UserSkillOffered[];
  wantedSkills: UserSkillWanted[];
}

export const Search: React.FC = () => {
  const { user } = useAuth();
  const [allUsers, setAllUsers] = useState<UserWithSkills[]>([]);
  const [filteredUsers, setFilteredUsers] = useState<UserWithSkills[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedSkill, setSelectedSkill] = useState('');
  const [allSkills, setAllSkills] = useState<Skill[]>([]);
  const [loading, setLoading] = useState(true);
  const [matchMode, setMatchMode] = useState<'all' | 'matches'>('all');
  const [swapModalUser, setSwapModalUser] = useState<User | null>(null);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setLoading(true);
    try {
      const { data: skills } = await supabase.from('skills').select('*');
      setAllSkills(skills || []);

      const { data: users } = await supabase
        .from('users')
        .select('*')
        .neq('id', user?.id);

      if (users) {
        const usersWithSkills: UserWithSkills[] = [];

        for (const u of users) {
          const { data: offered } = await supabase
            .from('user_skills_offered')
            .select('*, skill:skills(*)')
            .eq('user_id', u.id);

          const { data: wanted } = await supabase
            .from('user_skills_wanted')
            .select('*, skill:skills(*)')
            .eq('user_id', u.id);

          usersWithSkills.push({
            user: u,
            offeredSkills: offered || [],
            wantedSkills: wanted || [],
          });
        }

        setAllUsers(usersWithSkills);
        setFilteredUsers(usersWithSkills);
      }
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    let results = allUsers;

    if (matchMode === 'matches') {
      results = results.filter((u) => calculateMatchScore(u) > 0);
    }

    if (searchQuery) {
      results = results.filter(
        (u) =>
          u.user.username.toLowerCase().includes(searchQuery.toLowerCase()) ||
          u.user.bio.toLowerCase().includes(searchQuery.toLowerCase()) ||
          u.user.city.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }

    if (selectedSkill) {
      results = results.filter((u) =>
        u.offeredSkills.some((s) => s.skill_id === selectedSkill)
      );
    }

    setFilteredUsers(results);
  }, [searchQuery, selectedSkill, matchMode, allUsers]);

  const calculateMatchScore = (userWithSkills: UserWithSkills): number => {
    if (!user?.id) return 0;

    let score = 0;

    const currentUserOffered = allUsers.find((u) => u.user.id === user.id)?.offeredSkills || [];
    const currentUserWanted = allUsers.find((u) => u.user.id === user.id)?.wantedSkills || [];

    currentUserOffered.forEach((offered) => {
      if (userWithSkills.wantedSkills.some((w) => w.skill_id === offered.skill_id)) {
        score += 2;
      }
    });

    currentUserWanted.forEach((wanted) => {
      if (userWithSkills.offeredSkills.some((o) => o.skill_id === wanted.skill_id)) {
        score += 2;
      }
    });

    return score;
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  const matchedUsers = filteredUsers.filter((u) => calculateMatchScore(u) > 0);

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-6xl mx-auto px-4">
        <h1 className="text-3xl font-bold text-gray-900 mb-8">Find Learning Partners</h1>

        {/* Filters */}
        <div className="bg-white rounded-lg shadow-md p-6 mb-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Search by Name or Bio</label>
              <div className="relative">
                <SearchIcon className="absolute left-3 top-3 text-gray-400" size={20} />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search users..."
                  className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none transition"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Filter by Skill</label>
              <select
                value={selectedSkill}
                onChange={(e) => setSelectedSkill(e.target.value)}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none transition"
              >
                <option value="">All skills</option>
                {allSkills.map((skill) => (
                  <option key={skill.id} value={skill.id}>
                    {skill.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">View Mode</label>
              <select
                value={matchMode}
                onChange={(e) => setMatchMode(e.target.value as 'all' | 'matches')}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none transition"
              >
                <option value="all">All Users ({filteredUsers.length})</option>
                <option value="matches">Perfect Matches ({matchedUsers.length})</option>
              </select>
            </div>
          </div>
        </div>

        {/* Results */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredUsers.length > 0 ? (
            filteredUsers.map((userWithSkills) => {
              const matchScore = calculateMatchScore(userWithSkills);
              const isPerfectMatch = matchScore > 0;

              return (
                <div
                  key={userWithSkills.user.id}
                  className={`bg-white rounded-lg shadow-md overflow-hidden transition hover:shadow-lg ${
                    isPerfectMatch ? 'border-2 border-green-500' : ''
                  }`}
                >
                  <div className="p-6">
                    {isPerfectMatch && (
                      <div className="inline-block bg-green-100 text-green-700 px-3 py-1 rounded-full text-xs font-semibold mb-3">
                        Perfect Match
                      </div>
                    )}

                    <div className="flex items-start gap-4 mb-4">
                      <div className="w-16 h-16 bg-gradient-to-br from-blue-400 to-blue-600 rounded-lg flex items-center justify-center flex-shrink-0">
                        {userWithSkills.user.profile_picture_url ? (
                          <img
                            src={userWithSkills.user.profile_picture_url}
                            alt={userWithSkills.user.username}
                            className="w-full h-full object-cover"
                          />
                        ) : (
                          <span className="text-white text-2xl font-bold">
                            {userWithSkills.user.username.charAt(0).toUpperCase()}
                          </span>
                        )}
                      </div>

                      <div className="flex-1">
                        <Link
                          to={`/profile/${userWithSkills.user.id}`}
                          className="text-lg font-bold text-gray-900 hover:text-blue-600 transition"
                        >
                          {userWithSkills.user.username}
                        </Link>
                        <div className="flex items-center gap-2 mt-1">
                          <Star size={16} className="fill-yellow-400 text-yellow-400" />
                          <span className="text-sm text-gray-600">
                            {userWithSkills.user.average_rating.toFixed(1)}
                          </span>
                        </div>
                        {userWithSkills.user.city && (
                          <p className="text-sm text-gray-600">{userWithSkills.user.city}</p>
                        )}
                      </div>
                    </div>

                    {userWithSkills.user.bio && (
                      <p className="text-sm text-gray-600 mb-4 line-clamp-2">{userWithSkills.user.bio}</p>
                    )}

                    {userWithSkills.offeredSkills.length > 0 && (
                      <div className="mb-4">
                        <h4 className="font-semibold text-gray-900 mb-2 text-sm">Can Teach</h4>
                        <div className="flex flex-wrap gap-2">
                          {userWithSkills.offeredSkills.slice(0, 3).map((skill) => (
                            <span
                              key={skill.id}
                              className="inline-block bg-blue-100 text-blue-700 px-3 py-1 rounded-full text-xs font-medium"
                            >
                              {skill.skill?.name}
                            </span>
                          ))}
                          {userWithSkills.offeredSkills.length > 3 && (
                            <span className="inline-block text-gray-500 text-xs px-2">
                              +{userWithSkills.offeredSkills.length - 3}
                            </span>
                          )}
                        </div>
                      </div>
                    )}

                    {userWithSkills.wantedSkills.length > 0 && (
                      <div className="mb-4">
                        <h4 className="font-semibold text-gray-900 mb-2 text-sm">Wants to Learn</h4>
                        <div className="flex flex-wrap gap-2">
                          {userWithSkills.wantedSkills.slice(0, 3).map((skill) => (
                            <span
                              key={skill.id}
                              className="inline-block bg-purple-100 text-purple-700 px-3 py-1 rounded-full text-xs font-medium"
                            >
                              {skill.skill?.name}
                            </span>
                          ))}
                          {userWithSkills.wantedSkills.length > 3 && (
                            <span className="inline-block text-gray-500 text-xs px-2">
                              +{userWithSkills.wantedSkills.length - 3}
                            </span>
                          )}
                        </div>
                      </div>
                    )}

                    <div className="flex gap-2 pt-4 border-t border-gray-200">
                      <Link
                        to={`/profile/${userWithSkills.user.id}`}
                        className="flex-1 text-center bg-gray-100 text-gray-700 py-2 rounded-lg hover:bg-gray-200 transition font-medium text-sm"
                      >
                        Profile
                      </Link>
                      <button
                        onClick={() => setSwapModalUser(userWithSkills.user)}
                        className="flex-1 text-center bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700 transition font-medium text-sm flex items-center justify-center gap-1.5"
                      >
                        <ArrowLeftRight size={15} />
                        Request Swap
                      </button>
                    </div>
                  </div>
                </div>
              );
            })
          ) : (
            <div className="col-span-full text-center py-12">
              <p className="text-gray-600 text-lg">No users found matching your criteria.</p>
            </div>
          )}
        </div>
      </div>

      {swapModalUser && (
        <SwapRequestModal
          targetUser={swapModalUser}
          onClose={() => setSwapModalUser(null)}
          onSuccess={() => setSwapModalUser(null)}
        />
      )}
    </div>
  );
};
