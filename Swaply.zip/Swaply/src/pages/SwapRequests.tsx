import React, { useEffect, useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { supabase } from '../lib/supabase';
import { SwapRequest } from '../types';
import {
  CheckCircle,
  XCircle,
  Clock,
  MessageSquare,
  ArrowLeftRight,
  ChevronRight,
  User as UserIcon,
  RefreshCw,
  CheckCheck,
  Star,
} from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { ReviewModal } from '../components/ReviewModal';

type Tab = 'incoming' | 'outgoing' | 'accepted' | 'history';

const STATUS_BADGE: Record<string, { label: string; className: string }> = {
  pending:   { label: 'Pending',   className: 'bg-yellow-100 text-yellow-800' },
  accepted:  { label: 'Accepted',  className: 'bg-green-100 text-green-800'   },
  declined:  { label: 'Declined',  className: 'bg-red-100 text-red-800'       },
  completed: { label: 'Completed', className: 'bg-blue-100 text-blue-800'     },
};

interface ReviewState {
  swap: SwapRequest;
  reviewedUserId: string;
  reviewedUsername: string;
}

export const SwapRequests: React.FC = () => {
  const { user } = useAuth();
  const navigate = useNavigate();

  const [activeTab, setActiveTab]       = useState<Tab>('incoming');
  const [incoming, setIncoming]         = useState<SwapRequest[]>([]);
  const [outgoing, setOutgoing]         = useState<SwapRequest[]>([]);
  const [accepted, setAccepted]         = useState<SwapRequest[]>([]);
  const [history, setHistory]           = useState<SwapRequest[]>([]);
  const [loading, setLoading]           = useState(true);
  const [actionLoading, setActionLoading] = useState<string | null>(null);
  const [reviewModal, setReviewModal]   = useState<ReviewState | null>(null);
  const [reviewedSwaps, setReviewedSwaps] = useState<Set<string>>(new Set());

  useEffect(() => {
    if (user) loadAll();
  }, [user]);

  const loadAll = async () => {
    if (!user) return;
    setLoading(true);
    try {
      const base = `*, requester:requester_id(id, username, profile_picture_url), recipient:recipient_id(id, username, profile_picture_url), skill_offered:skill_offered_id(*), skill_wanted:skill_wanted_id(*)`;

      const [incomingRes, outgoingRes, acceptedRes, historyRes] = await Promise.all([
        supabase
          .from('swap_requests')
          .select(base)
          .eq('recipient_id', user.id)
          .eq('status', 'pending')
          .order('created_at', { ascending: false }),

        supabase
          .from('swap_requests')
          .select(base)
          .eq('requester_id', user.id)
          .eq('status', 'pending')
          .order('created_at', { ascending: false }),

        supabase
          .from('swap_requests')
          .select(base)
          .or(`requester_id.eq.${user.id},recipient_id.eq.${user.id}`)
          .eq('status', 'accepted')
          .order('updated_at', { ascending: false }),

        supabase
          .from('swap_requests')
          .select(base)
          .or(`requester_id.eq.${user.id},recipient_id.eq.${user.id}`)
          .in('status', ['declined', 'completed'])
          .order('updated_at', { ascending: false })
          .limit(30),
      ]);

      setIncoming((incomingRes.data as any) || []);
      setOutgoing((outgoingRes.data as any) || []);
      setAccepted((acceptedRes.data as any) || []);
      setHistory((historyRes.data  as any) || []);

      const completedIds = ((historyRes.data as any) || [])
        .filter((r: any) => r.status === 'completed')
        .map((r: any) => r.id);

      if (completedIds.length > 0) {
        const { data: myReviews } = await supabase
          .from('swap_request_reviews')
          .select('swap_request_id')
          .eq('reviewer_id', user.id)
          .in('swap_request_id', completedIds);

        if (myReviews) {
          setReviewedSwaps(new Set(myReviews.map((r: any) => r.swap_request_id)));
        }
      }
    } finally {
      setLoading(false);
    }
  };

  const handleAccept = async (req: SwapRequest) => {
    setActionLoading(req.id);
    try {
      await supabase
        .from('swap_requests')
        .update({ status: 'accepted', updated_at: new Date().toISOString() })
        .eq('id', req.id);

      await supabase.from('notifications').insert([{
        user_id:         req.requester_id,
        type:            'swap_accepted',
        title:           'Swap Request Accepted!',
        message:         'Your swap request was accepted. Start chatting to schedule your session.',
        related_user_id: user!.id,
        related_swap_id: null,
      }]);

      await loadAll();
      setActiveTab('accepted');
    } finally {
      setActionLoading(null);
    }
  };

  const handleDecline = async (req: SwapRequest) => {
    setActionLoading(req.id);
    try {
      await supabase
        .from('swap_requests')
        .update({ status: 'declined', updated_at: new Date().toISOString() })
        .eq('id', req.id);

      await supabase.from('notifications').insert([{
        user_id:         req.requester_id,
        type:            'swap_declined',
        title:           'Swap Request Declined',
        message:         'Your swap request was declined. Try connecting with other users.',
        related_user_id: user!.id,
        related_swap_id: null,
      }]);

      await loadAll();
    } finally {
      setActionLoading(null);
    }
  };

  const handleCancel = async (req: SwapRequest) => {
    setActionLoading(req.id);
    try {
      await supabase
        .from('swap_requests')
        .update({ status: 'declined', updated_at: new Date().toISOString() })
        .eq('id', req.id);
      await loadAll();
    } finally {
      setActionLoading(null);
    }
  };

  const handleConfirmComplete = async (req: SwapRequest) => {
    if (!user) return;
    setActionLoading(req.id);

    const isRequester = req.requester_id === user.id;
    const updateField = isRequester
      ? { requester_confirmed_complete: true }
      : { recipient_confirmed_complete: true };

    try {
      await supabase
        .from('swap_requests')
        .update({ ...updateField, updated_at: new Date().toISOString() })
        .eq('id', req.id);

      const { data: fresh } = await supabase
        .from('swap_requests')
        .select('requester_confirmed_complete, recipient_confirmed_complete')
        .eq('id', req.id)
        .single();

      if (fresh?.requester_confirmed_complete && fresh?.recipient_confirmed_complete) {
        await supabase
          .from('swap_requests')
          .update({ status: 'completed', updated_at: new Date().toISOString() })
          .eq('id', req.id);

        const otherId = isRequester ? req.recipient_id : req.requester_id;

        await supabase.from('notifications').insert([
          {
            user_id:         otherId,
            type:            'swap_completed',
            title:           'Swap Completed!',
            message:         'Both parties confirmed the swap is done. Leave a review!',
            related_user_id: user.id,
            related_swap_id: null,
          },
          {
            user_id:         user.id,
            type:            'swap_completed',
            title:           'Swap Completed!',
            message:         'Both parties confirmed the swap is done. Leave a review!',
            related_user_id: otherId,
            related_swap_id: null,
          },
        ]);

        await loadAll();
        setActiveTab('history');
      } else {
        await loadAll();
      }
    } finally {
      setActionLoading(null);
    }
  };

  const openReview = (req: SwapRequest) => {
    if (!user) return;
    const isRequester = req.requester_id === user.id;
    const other = isRequester ? (req as any).recipient : (req as any).requester;
    setReviewModal({
      swap: req,
      reviewedUserId: other?.id ?? '',
      reviewedUsername: other?.username ?? 'Unknown',
    });
  };

  const startChat = (otherUserId: string) => navigate(`/messages?user=${otherUserId}`);

  const tabs: { key: Tab; label: string; count: number; activeClass: string; badgeClass: string }[] = [
    { key: 'incoming', label: 'Incoming',  count: incoming.length, activeClass: 'border-blue-600 text-blue-600',   badgeClass: 'bg-blue-100 text-blue-700'   },
    { key: 'outgoing', label: 'Sent',      count: outgoing.length, activeClass: 'border-orange-500 text-orange-600', badgeClass: 'bg-orange-100 text-orange-700' },
    { key: 'accepted', label: 'Accepted',  count: accepted.length, activeClass: 'border-green-600 text-green-600',  badgeClass: 'bg-green-100 text-green-700'  },
    { key: 'history',  label: 'History',   count: history.length,  activeClass: 'border-gray-500 text-gray-600',   badgeClass: 'bg-gray-100 text-gray-600'    },
  ];

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  const renderEmpty = (message: string) => (
    <div className="text-center py-16 text-gray-400">
      <ArrowLeftRight size={40} className="mx-auto mb-3 opacity-40" />
      <p className="text-base">{message}</p>
    </div>
  );

  const renderRequest = (req: SwapRequest, mode: Tab) => {
    const isIncoming  = mode === 'incoming';
    const isAccepted  = mode === 'accepted';
    const isHistory   = mode === 'history';
    const isRequester = req.requester_id === user?.id;
    const otherUser   = isIncoming ? (req as any).requester : (req as any).recipient;
    const offered     = (req as any).skill_offered;
    const wanted      = (req as any).skill_wanted;
    const isLoading   = actionLoading === req.id;
    const statusInfo  = STATUS_BADGE[req.status] ?? STATUS_BADGE.pending;

    const iHaveConfirmed = isRequester
      ? req.requester_confirmed_complete
      : req.recipient_confirmed_complete;
    const theyHaveConfirmed = isRequester
      ? req.recipient_confirmed_complete
      : req.requester_confirmed_complete;

    const hasReviewed = reviewedSwaps.has(req.id);

    return (
      <div key={req.id} className="border border-gray-200 rounded-xl p-5 hover:border-gray-300 transition bg-white shadow-sm">
        {/* Header row */}
        <div className="flex items-start justify-between gap-4 mb-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-blue-700 rounded-full flex items-center justify-center flex-shrink-0">
              <UserIcon size={18} className="text-white" />
            </div>
            <div>
              <Link
                to={`/profile/${otherUser?.id}`}
                className="font-semibold text-gray-900 hover:text-blue-600 transition"
              >
                {otherUser?.username || 'Unknown User'}
              </Link>
              <p className="text-xs text-gray-400 mt-0.5">
                {new Date(req.created_at).toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' })}
              </p>
            </div>
          </div>
          <span className={`text-xs font-semibold px-2.5 py-1 rounded-full whitespace-nowrap ${statusInfo.className}`}>
            {statusInfo.label}
          </span>
        </div>

        {/* Skills exchange */}
        <div className="bg-gray-50 rounded-lg p-4 mb-4">
          <div className="flex items-center gap-3 flex-wrap">
            <div className="flex-1 min-w-0">
              <p className="text-xs text-gray-500 mb-1">{isIncoming ? 'They offer' : 'You offer'}</p>
              <span className="inline-block bg-blue-100 text-blue-800 text-xs font-semibold px-2.5 py-1 rounded-full">
                {offered?.name || '—'}
              </span>
            </div>
            <ArrowLeftRight size={16} className="text-gray-400 flex-shrink-0" />
            <div className="flex-1 min-w-0 text-right">
              <p className="text-xs text-gray-500 mb-1">{isIncoming ? 'They want' : 'You want'}</p>
              <span className="inline-block bg-purple-100 text-purple-800 text-xs font-semibold px-2.5 py-1 rounded-full">
                {wanted?.name || '—'}
              </span>
            </div>
          </div>
          <div className="mt-2 flex items-center gap-1.5">
            <span className="text-xs text-gray-400">Session:</span>
            <span className="text-xs text-gray-600 capitalize">{req.session_type}</span>
          </div>
        </div>

        {req.message && (
          <div className="bg-blue-50 border border-blue-100 rounded-lg px-4 py-3 mb-4">
            <p className="text-xs text-blue-600 font-semibold mb-1">Message</p>
            <p className="text-sm text-gray-700 italic">"{req.message}"</p>
          </div>
        )}

        {/* Completion confirmation status (accepted tab only) */}
        {isAccepted && (
          <div className="mb-4 rounded-lg border border-gray-100 bg-gray-50 px-4 py-3">
            <p className="text-xs font-semibold text-gray-600 mb-2">Completion Status</p>
            <div className="flex flex-col gap-1.5">
              <div className="flex items-center gap-2">
                {iHaveConfirmed
                  ? <CheckCircle size={14} className="text-green-500 flex-shrink-0" />
                  : <Clock size={14} className="text-gray-300 flex-shrink-0" />
                }
                <span className={`text-xs ${iHaveConfirmed ? 'text-green-700 font-medium' : 'text-gray-400'}`}>
                  You {iHaveConfirmed ? 'confirmed completion' : 'have not confirmed yet'}
                </span>
              </div>
              <div className="flex items-center gap-2">
                {theyHaveConfirmed
                  ? <CheckCircle size={14} className="text-green-500 flex-shrink-0" />
                  : <Clock size={14} className="text-gray-300 flex-shrink-0" />
                }
                <span className={`text-xs ${theyHaveConfirmed ? 'text-green-700 font-medium' : 'text-gray-400'}`}>
                  {otherUser?.username ?? 'Other user'} {theyHaveConfirmed ? 'confirmed completion' : 'has not confirmed yet'}
                </span>
              </div>
            </div>
            {iHaveConfirmed && !theyHaveConfirmed && (
              <p className="text-xs text-amber-600 mt-2 font-medium">
                Waiting for {otherUser?.username} to confirm…
              </p>
            )}
          </div>
        )}

        {/* Action buttons */}
        <div className="flex gap-2 flex-wrap">
          {mode === 'incoming' && (
            <>
              <button
                onClick={() => handleAccept(req)}
                disabled={isLoading}
                className="flex items-center gap-1.5 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition text-sm font-semibold disabled:opacity-50"
              >
                {isLoading
                  ? <div className="animate-spin rounded-full h-3.5 w-3.5 border-b-2 border-white" />
                  : <CheckCircle size={15} />
                }
                Accept
              </button>
              <button
                onClick={() => handleDecline(req)}
                disabled={isLoading}
                className="flex items-center gap-1.5 px-4 py-2 bg-red-50 text-red-600 border border-red-200 rounded-lg hover:bg-red-100 transition text-sm font-semibold disabled:opacity-50"
              >
                {isLoading
                  ? <div className="animate-spin rounded-full h-3.5 w-3.5 border-b-2 border-red-400" />
                  : <XCircle size={15} />
                }
                Decline
              </button>
              <button
                onClick={() => startChat(otherUser?.id)}
                className="flex items-center gap-1.5 px-4 py-2 border border-gray-200 text-gray-600 rounded-lg hover:bg-gray-50 transition text-sm font-semibold"
              >
                <MessageSquare size={15} />
                Message
              </button>
            </>
          )}

          {mode === 'outgoing' && (
            <>
              <button
                onClick={() => handleCancel(req)}
                disabled={isLoading}
                className="flex items-center gap-1.5 px-4 py-2 bg-gray-100 text-gray-600 rounded-lg hover:bg-gray-200 transition text-sm font-semibold disabled:opacity-50"
              >
                {isLoading
                  ? <div className="animate-spin rounded-full h-3.5 w-3.5 border-b-2 border-gray-400" />
                  : <XCircle size={15} />
                }
                Cancel Request
              </button>
              <button
                onClick={() => startChat(otherUser?.id)}
                className="flex items-center gap-1.5 px-4 py-2 border border-gray-200 text-gray-600 rounded-lg hover:bg-gray-50 transition text-sm font-semibold"
              >
                <MessageSquare size={15} />
                Message
              </button>
            </>
          )}

          {mode === 'accepted' && (
            <>
              {!iHaveConfirmed && (
                <button
                  onClick={() => handleConfirmComplete(req)}
                  disabled={isLoading}
                  className="flex items-center gap-1.5 px-4 py-2 bg-emerald-600 text-white rounded-lg hover:bg-emerald-700 transition text-sm font-semibold disabled:opacity-50"
                >
                  {isLoading
                    ? <div className="animate-spin rounded-full h-3.5 w-3.5 border-b-2 border-white" />
                    : <CheckCheck size={15} />
                  }
                  Mark as Complete
                </button>
              )}
              <button
                onClick={() => startChat(otherUser?.id)}
                className="flex items-center gap-1.5 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition text-sm font-semibold"
              >
                <MessageSquare size={15} />
                Open Chat
              </button>
              <Link
                to={`/profile/${otherUser?.id}`}
                className="flex items-center gap-1.5 px-4 py-2 border border-gray-200 text-gray-600 rounded-lg hover:bg-gray-50 transition text-sm font-semibold"
              >
                <UserIcon size={15} />
                View Profile
              </Link>
            </>
          )}

          {mode === 'history' && (
            <>
              {req.status === 'completed' && !hasReviewed && (
                <button
                  onClick={() => openReview(req)}
                  className="flex items-center gap-1.5 px-4 py-2 bg-amber-500 text-white rounded-lg hover:bg-amber-600 transition text-sm font-semibold"
                >
                  <Star size={15} />
                  Leave a Review
                </button>
              )}
              {req.status === 'completed' && hasReviewed && (
                <span className="flex items-center gap-1.5 px-4 py-2 bg-green-50 text-green-700 border border-green-200 rounded-lg text-sm font-semibold">
                  <CheckCircle size={15} />
                  Reviewed
                </span>
              )}
              <button
                onClick={() => startChat(otherUser?.id)}
                className="flex items-center gap-1.5 px-4 py-2 border border-gray-200 text-gray-600 rounded-lg hover:bg-gray-50 transition text-sm font-semibold"
              >
                <MessageSquare size={15} />
                Message
              </button>
            </>
          )}
        </div>
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-3xl mx-auto px-4">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Swap Requests</h1>
            <p className="text-gray-500 mt-1">Manage your skill exchange requests</p>
          </div>
          <button
            onClick={loadAll}
            className="flex items-center gap-2 px-4 py-2 border border-gray-200 bg-white text-gray-600 rounded-lg hover:bg-gray-50 transition text-sm shadow-sm"
          >
            <RefreshCw size={15} />
            Refresh
          </button>
        </div>

        <div className="flex border-b border-gray-200 mb-6 bg-white rounded-t-xl overflow-hidden shadow-sm">
          {tabs.map((tab) => (
            <button
              key={tab.key}
              onClick={() => setActiveTab(tab.key)}
              className={`flex-1 py-4 text-sm font-semibold transition border-b-2 ${
                activeTab === tab.key
                  ? tab.activeClass
                  : 'border-transparent text-gray-500 hover:text-gray-700'
              }`}
            >
              {tab.label}
              {tab.count > 0 && (
                <span className={`ml-1.5 text-xs font-bold px-2 py-0.5 rounded-full ${
                  activeTab === tab.key ? tab.badgeClass : 'bg-gray-100 text-gray-500'
                }`}>
                  {tab.count}
                </span>
              )}
            </button>
          ))}
        </div>

        <div className="space-y-4">
          {activeTab === 'incoming' && (
            incoming.length === 0
              ? renderEmpty('No incoming swap requests right now.')
              : incoming.map((r) => renderRequest(r, 'incoming'))
          )}
          {activeTab === 'outgoing' && (
            outgoing.length === 0
              ? renderEmpty("You haven't sent any pending requests.")
              : outgoing.map((r) => renderRequest(r, 'outgoing'))
          )}
          {activeTab === 'accepted' && (
            accepted.length === 0
              ? renderEmpty('No accepted swaps yet. Accept an incoming request to get started.')
              : accepted.map((r) => renderRequest(r, 'accepted'))
          )}
          {activeTab === 'history' && (
            history.length === 0
              ? renderEmpty('No swap history yet.')
              : history.map((r) => renderRequest(r, 'history'))
          )}
        </div>

        {incoming.length === 0 && outgoing.length === 0 && accepted.length === 0 && history.length === 0 && (
          <div className="mt-10 text-center">
            <p className="text-gray-500 mb-4">Find learning partners and send your first swap request!</p>
            <Link
              to="/search"
              className="inline-flex items-center gap-2 px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition font-semibold"
            >
              Find Learning Partners
              <ChevronRight size={16} />
            </Link>
          </div>
        )}
      </div>

      {reviewModal && (
        <ReviewModal
          swap={reviewModal.swap}
          reviewedUserId={reviewModal.reviewedUserId}
          reviewedUsername={reviewModal.reviewedUsername}
          onClose={() => setReviewModal(null)}
          onSubmitted={async () => {
            setReviewModal(null);
            setReviewedSwaps((prev) => new Set([...prev, reviewModal.swap.id]));
            await loadAll();
          }}
        />
      )}
    </div>
  );
};
