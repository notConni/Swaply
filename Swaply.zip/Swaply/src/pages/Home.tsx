import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Users, Zap, Heart, Sparkles } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

export const Home: React.FC = () => {
  const { user } = useAuth();

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-white">
      {/* Hero Section */}
      <section className="max-w-7xl mx-auto px-4 py-20 text-center">
        <h1 className="text-5xl md:text-6xl font-bold text-gray-900 mb-6 leading-tight">
          Learn. Teach. <span className="text-blue-600">Grow Together</span>
        </h1>
        <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto leading-relaxed">
          Skill Swap connects people who want to learn with people who can teach. Exchange knowledge with others in your community and build valuable skills through mutual learning.
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
          {user ? (
            <>
              <Link
                to="/search"
                className="bg-blue-600 text-white px-8 py-4 rounded-lg hover:bg-blue-700 transition font-semibold flex items-center justify-center gap-2"
              >
                Find Skills to Learn <ArrowRight size={20} />
              </Link>
              <Link
                to="/dashboard"
                className="bg-white text-blue-600 px-8 py-4 rounded-lg border-2 border-blue-600 hover:bg-blue-50 transition font-semibold"
              >
                Go to Dashboard
              </Link>
            </>
          ) : (
            <>
              <Link
                to="/register"
                className="bg-blue-600 text-white px-8 py-4 rounded-lg hover:bg-blue-700 transition font-semibold flex items-center justify-center gap-2"
              >
                Get Started <ArrowRight size={20} />
              </Link>
              <Link
                to="/login"
                className="bg-white text-blue-600 px-8 py-4 rounded-lg border-2 border-blue-600 hover:bg-blue-50 transition font-semibold"
              >
                Sign In
              </Link>
            </>
          )}
        </div>
      </section>

      {/* How It Works */}
      <section className="max-w-7xl mx-auto px-4 py-20">
        <h2 className="text-4xl font-bold text-gray-900 mb-16 text-center">How Skill Swap Works</h2>
        <div className="grid md:grid-cols-4 gap-8">
          <div className="text-center">
            <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6">
              <Users className="text-blue-600" size={32} />
            </div>
            <h3 className="text-xl font-semibold text-gray-900 mb-3">1. Create Profile</h3>
            <p className="text-gray-600">Sign up and tell us about yourself. Add your location and interests.</p>
          </div>

          <div className="text-center">
            <div className="bg-green-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6">
              <Sparkles className="text-green-600" size={32} />
            </div>
            <h3 className="text-xl font-semibold text-gray-900 mb-3">2. List Your Skills</h3>
            <p className="text-gray-600">Add skills you can teach and skills you want to learn. Set your proficiency level.</p>
          </div>

          <div className="text-center">
            <div className="bg-purple-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6">
              <Zap className="text-purple-600" size={32} />
            </div>
            <h3 className="text-xl font-semibold text-gray-900 mb-3">3. Find Matches</h3>
            <p className="text-gray-600">Discover people with complementary skills. Browse and connect with potential swap partners.</p>
          </div>

          <div className="text-center">
            <div className="bg-red-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6">
              <Heart className="text-red-600" size={32} />
            </div>
            <h3 className="text-xl font-semibold text-gray-900 mb-3">4. Exchange & Review</h3>
            <p className="text-gray-600">Arrange sessions, learn together, and leave reviews to build your reputation.</p>
          </div>
        </div>
      </section>

      {/* Benefits */}
      <section className="bg-blue-50 py-20">
        <div className="max-w-7xl mx-auto px-4">
          <h2 className="text-4xl font-bold text-gray-900 mb-16 text-center">Why Join Skill Swap?</h2>
          <div className="grid md:grid-cols-2 gap-12">
            <div className="flex gap-6">
              <div className="flex-shrink-0">
                <div className="flex items-center justify-center h-12 w-12 rounded-md bg-blue-600 text-white">
                  <Users size={24} />
                </div>
              </div>
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">Community Learning</h3>
                <p className="text-gray-600">Learn from passionate individuals in your community who genuinely want to share their expertise.</p>
              </div>
            </div>

            <div className="flex gap-6">
              <div className="flex-shrink-0">
                <div className="flex items-center justify-center h-12 w-12 rounded-md bg-blue-600 text-white">
                  <Zap size={24} />
                </div>
              </div>
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">Cost-Free Learning</h3>
                <p className="text-gray-600">Swap skills instead of paying expensive tutors or courses. Everyone benefits equally.</p>
              </div>
            </div>

            <div className="flex gap-6">
              <div className="flex-shrink-0">
                <div className="flex items-center justify-center h-12 w-12 rounded-md bg-blue-600 text-white">
                  <Sparkles size={24} />
                </div>
              </div>
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">Personal Growth</h3>
                <p className="text-gray-600">Develop new skills while teaching others, building your portfolio and experience.</p>
              </div>
            </div>

            <div className="flex gap-6">
              <div className="flex-shrink-0">
                <div className="flex items-center justify-center h-12 w-12 rounded-md bg-blue-600 text-white">
                  <Heart size={24} />
                </div>
              </div>
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">Build Connections</h3>
                <p className="text-gray-600">Network with like-minded individuals and expand your social and professional circles.</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="max-w-7xl mx-auto px-4 py-20 text-center">
        <h2 className="text-4xl font-bold text-gray-900 mb-6">Ready to Start Learning?</h2>
        <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
          Join thousands of people exchanging valuable skills and knowledge. Your next learning adventure starts here.
        </p>
        {!user && (
          <Link
            to="/register"
            className="inline-block bg-blue-600 text-white px-8 py-4 rounded-lg hover:bg-blue-700 transition font-semibold"
          >
            Create Your Free Account Today
          </Link>
        )}
      </section>
    </div>
  );
};
