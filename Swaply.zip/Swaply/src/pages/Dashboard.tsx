import React, { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { supabase } from '../lib/supabase';
import { SwapRequest, Notification, Message } from '../types';
import {
  Bell,
  MessageSquare,
  CheckCircle,
  ArrowLeftRight,
  XCircle,
  ChevronRight,
  User as UserIcon,
  CheckCheck,
} from 'lucide-react';

export const Dashboard: React.FC = () => {
  const { user, profile } = useAuth();
  const navigate = useNavigate();
  const [incomingRequests, setIncomingRequests] = useState<SwapRequest[]>([]);
  const [acceptedSwaps, setAcceptedSwaps] = useState<SwapRequest[]>([]);
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [unreadMessages, setUnreadMessages] = useState<Message[]>([]);
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState<string | null>(null);

  useEffect(() => {
    if (user) {
      loadDashboardData();
      const interval = setInterval(loadDashboardData, 10000);
      return () => clearInterval(interval);
    }
  }, [user]);

  const loadDashboardData = async () => {
    if (!user) return;

    try {
      const base = `*, requester:requester_id(id, username, profile_picture_url), recipient:recipient_id(id, username, profile_picture_url), skill_offered:skill_offered_id(*), skill_wanted:skill_wanted_id(*)`;

      const [incomingRes, acceptedRes, notifsRes, msgsRes] = await Promise.all([
        supabase
          .from('swap_requests')
          .select(base)
          .eq('recipient_id', user.id)
          .eq('status', 'pending')
          .order('created_at', { ascending: false })
          .limit(5),

        supabase
          .from('swap_requests')
          .select(base)
          .or(`requester_id.eq.${user.id},recipient_id.eq.${user.id}`)
          .eq('status', 'accepted')
          .order('updated_at', { ascending: false })
          .limit(5),

        supabase
          .from('notifications')
          .select('*')
          .eq('user_id', user.id)
          .order('created_at', { ascending: false })
          .limit(10),

        supabase
          .from('messages')
          .select('*')
          .eq('recipient_id', user.id)
          .eq('is_read', false)
          .order('created_at', { ascending: false })
          .limit(5),
      ]);

      setIncomingRequests((incomingRes.data as any) || []);
      setAcceptedSwaps((acceptedRes.data as any) || []);
      setNotifications(notifsRes.data || []);
      setUnreadMessages(msgsRes.data || []);
    } finally {
      setLoading(false);
    }
  };

  const handleAccept = async (req: SwapRequest) => {
    setActionLoading(req.id);
    try {
      await supabase
        .from('swap_requests')
        .update({ status: 'accepted', updated_at: new Date().toISOString() })
        .eq('id', req.id);

      await supabase.from('notifications').insert([{
        user_id:         req.requester_id,
        type:            'swap_accepted',
        title:           'Swap Request Accepted!',
        message:         'Your swap request was accepted. Start chatting to schedule your session.',
        related_user_id: user!.id,
        related_swap_id: null,
      }]);

      await loadDashboardData();
    } finally {
      setActionLoading(null);
    }
  };

  const handleDecline = async (req: SwapRequest) => {
    setActionLoading(req.id);
    try {
      await supabase
        .from('swap_requests')
        .update({ status: 'declined', updated_at: new Date().toISOString() })
        .eq('id', req.id);

      await supabase.from('notifications').insert([{
        user_id:         req.requester_id,
        type:            'swap_declined',
        title:           'Swap Request Declined',
        message:         'Your swap request was declined. Try connecting with other users.',
        related_user_id: user!.id,
        related_swap_id: null,
      }]);

      await loadDashboardData();
    } finally {
      setActionLoading(null);
    }
  };

  const handleConfirmComplete = async (req: SwapRequest) => {
    if (!user) return;
    setActionLoading(req.id);

    const isRequester = req.requester_id === user.id;
    const otherId     = isRequester ? req.recipient_id : req.requester_id;
    const marker      = `__SWAP_COMPLETE__:${req.id}`;

    try {
      // Avoid duplicate confirmations
      const { data: already } = await supabase
        .from('messages')
        .select('id')
        .eq('sender_id', user.id)
        .eq('content', marker)
        .limit(1);

      if (already && already.length > 0) return;

      const { error: insertErr } = await supabase
        .from('messages')
        .insert([{ sender_id: user.id, recipient_id: otherId, content: marker, is_read: true }]);

      if (insertErr) { console.error('Complete confirm error:', insertErr); return; }

      // Check if the other user has also confirmed
      const { data: theirConfirm } = await supabase
        .from('messages')
        .select('id')
        .eq('sender_id', otherId)
        .eq('recipient_id', user.id)
        .eq('content', marker)
        .limit(1);

      if (theirConfirm && theirConfirm.length > 0) {
        await supabase
          .from('swap_requests')
          .update({ status: 'completed', updated_at: new Date().toISOString() })
          .eq('id', req.id);

        await supabase.from('notifications').insert([
          { user_id: otherId, type: 'swap_completed', title: 'Swap Completed!', message: 'Both confirmed. Leave a review in Swap Requests!', related_user_id: user.id,   related_swap_id: null },
          { user_id: user.id, type: 'swap_completed', title: 'Swap Completed!', message: 'Both confirmed. Leave a review in Swap Requests!', related_user_id: otherId, related_swap_id: null },
        ]);
      }

      await loadDashboardData();
    } finally {
      setActionLoading(null);
    }
  };

  const markNotificationRead = async (notifId: string) => {
    await supabase.from('notifications').update({ is_read: true }).eq('id', notifId);
    setNotifications((prev) =>
      prev.map((n) => (n.id === notifId ? { ...n, is_read: true } : n))
    );
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  const unreadNotifs = notifications.filter((n) => !n.is_read).length;

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">
            Welcome back, {profile?.username}!
          </h1>
          <p className="text-gray-600 mt-2">Manage your skill swaps and connect with learning partners</p>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          <div className="bg-white rounded-xl shadow-sm p-5 border border-gray-100">
            <div className="flex items-center gap-3">
              <div className="bg-blue-100 p-2.5 rounded-lg">
                <ArrowLeftRight className="text-blue-600" size={20} />
              </div>
              <div>
                <p className="text-gray-500 text-xs">Incoming Requests</p>
                <p className="text-2xl font-bold text-gray-900">{incomingRequests.length}</p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-sm p-5 border border-gray-100">
            <div className="flex items-center gap-3">
              <div className="bg-green-100 p-2.5 rounded-lg">
                <CheckCircle className="text-green-600" size={20} />
              </div>
              <div>
                <p className="text-gray-500 text-xs">Active Swaps</p>
                <p className="text-2xl font-bold text-gray-900">{acceptedSwaps.length}</p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-sm p-5 border border-gray-100">
            <div className="flex items-center gap-3">
              <div className="bg-orange-100 p-2.5 rounded-lg">
                <MessageSquare className="text-orange-600" size={20} />
              </div>
              <div>
                <p className="text-gray-500 text-xs">Unread Messages</p>
                <p className="text-2xl font-bold text-gray-900">{unreadMessages.length}</p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-sm p-5 border border-gray-100">
            <div className="flex items-center gap-3">
              <div className="bg-purple-100 p-2.5 rounded-lg">
                <Bell className="text-purple-600" size={20} />
              </div>
              <div>
                <p className="text-gray-500 text-xs">Notifications</p>
                <p className="text-2xl font-bold text-gray-900">{unreadNotifs}</p>
              </div>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Left: Swap Requests */}
          <div className="lg:col-span-2 space-y-6">

            {/* Incoming Swap Requests */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
              <div className="flex items-center justify-between mb-5">
                <div className="flex items-center gap-2">
                  <ArrowLeftRight className="text-blue-600" size={20} />
                  <h2 className="text-lg font-bold text-gray-900">Incoming Swap Requests</h2>
                  {incomingRequests.length > 0 && (
                    <span className="bg-blue-100 text-blue-700 px-2.5 py-0.5 rounded-full text-xs font-bold">
                      {incomingRequests.length}
                    </span>
                  )}
                </div>
                <Link
                  to="/swap-requests"
                  className="text-blue-600 hover:text-blue-700 text-sm font-semibold flex items-center gap-1"
                >
                  View all <ChevronRight size={14} />
                </Link>
              </div>

              {incomingRequests.length > 0 ? (
                <div className="space-y-4">
                  {incomingRequests.map((req) => {
                    const requester = (req as any).requester;
                    const offered   = (req as any).skill_offered;
                    const wanted    = (req as any).skill_wanted;
                    const isLoading = actionLoading === req.id;

                    return (
                      <div key={req.id} className="border border-gray-200 rounded-xl p-4">
                        <div className="flex items-center gap-3 mb-3">
                          <div className="w-9 h-9 bg-gradient-to-br from-blue-500 to-blue-700 rounded-full flex items-center justify-center flex-shrink-0">
                            <UserIcon size={16} className="text-white" />
                          </div>
                          <div className="flex-1 min-w-0">
                            <Link
                              to={`/profile/${requester?.id}`}
                              className="font-semibold text-gray-900 hover:text-blue-600 transition text-sm"
                            >
                              {requester?.username}
                            </Link>
                            <p className="text-xs text-gray-400">
                              {new Date(req.created_at).toLocaleDateString(undefined, { month: 'short', day: 'numeric' })}
                            </p>
                          </div>
                        </div>

                        <div className="flex items-center gap-2 mb-3 bg-gray-50 rounded-lg px-3 py-2 flex-wrap">
                          <span className="text-xs bg-blue-100 text-blue-800 font-semibold px-2 py-0.5 rounded-full">
                            {offered?.name || '—'}
                          </span>
                          <ArrowLeftRight size={12} className="text-gray-400 flex-shrink-0" />
                          <span className="text-xs bg-purple-100 text-purple-800 font-semibold px-2 py-0.5 rounded-full">
                            {wanted?.name || '—'}
                          </span>
                        </div>

                        {req.message && (
                          <p className="text-xs text-gray-500 italic mb-3 line-clamp-1">"{req.message}"</p>
                        )}

                        <div className="flex gap-2">
                          <button
                            onClick={() => handleAccept(req)}
                            disabled={isLoading}
                            className="flex items-center gap-1.5 px-3 py-1.5 bg-green-600 text-white rounded-lg hover:bg-green-700 transition text-xs font-semibold disabled:opacity-50"
                          >
                            {isLoading
                              ? <div className="animate-spin rounded-full h-3 w-3 border-b-2 border-white" />
                              : <CheckCircle size={13} />
                            }
                            Accept
                          </button>
                          <button
                            onClick={() => handleDecline(req)}
                            disabled={isLoading}
                            className="flex items-center gap-1.5 px-3 py-1.5 bg-red-50 text-red-600 border border-red-200 rounded-lg hover:bg-red-100 transition text-xs font-semibold disabled:opacity-50"
                          >
                            {isLoading
                              ? <div className="animate-spin rounded-full h-3 w-3 border-b-2 border-red-400" />
                              : <XCircle size={13} />
                            }
                            Decline
                          </button>
                          <button
                            onClick={() => navigate(`/messages?user=${requester?.id}`)}
                            className="flex items-center gap-1.5 px-3 py-1.5 border border-gray-200 text-gray-600 rounded-lg hover:bg-gray-50 transition text-xs font-semibold"
                          >
                            <MessageSquare size={13} />
                            Message
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              ) : (
                <div className="text-center py-10 text-gray-400">
                  <ArrowLeftRight size={32} className="mx-auto mb-2 opacity-40" />
                  <p className="text-sm">No pending swap requests</p>
                  <Link
                    to="/search"
                    className="mt-3 inline-flex items-center gap-1 text-blue-600 hover:text-blue-700 text-sm font-semibold"
                  >
                    Find learning partners <ChevronRight size={14} />
                  </Link>
                </div>
              )}
            </div>

            {/* Active / Accepted Swaps */}
            {acceptedSwaps.length > 0 && (
              <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
                <div className="flex items-center justify-between mb-5">
                  <div className="flex items-center gap-2">
                    <CheckCircle className="text-green-600" size={20} />
                    <h2 className="text-lg font-bold text-gray-900">Active Swaps</h2>
                    <span className="bg-green-100 text-green-700 px-2.5 py-0.5 rounded-full text-xs font-bold">
                      {acceptedSwaps.length}
                    </span>
                  </div>
                  <Link
                    to="/swap-requests"
                    className="text-blue-600 hover:text-blue-700 text-sm font-semibold flex items-center gap-1"
                  >
                    View all <ChevronRight size={14} />
                  </Link>
                </div>

                <div className="space-y-3">
                  {acceptedSwaps.map((req) => {
                    const isRequester     = req.requester_id === user?.id;
                    const otherUser       = isRequester ? (req as any).recipient : (req as any).requester;
                    const offered         = (req as any).skill_offered;
                    const wanted          = (req as any).skill_wanted;
                    const isLoading       = actionLoading === req.id;
                    const iHaveConfirmed  = isRequester
                      ? req.requester_confirmed_complete
                      : req.recipient_confirmed_complete;

                    return (
                      <div key={req.id} className="p-4 bg-green-50 border border-green-200 rounded-xl">
                        <div className="flex items-center gap-3 mb-3">
                          <div className="w-8 h-8 bg-gradient-to-br from-green-500 to-green-700 rounded-full flex items-center justify-center flex-shrink-0">
                            <UserIcon size={14} className="text-white" />
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="font-semibold text-gray-900 text-sm">{otherUser?.username}</p>
                            <p className="text-xs text-gray-500 truncate">
                              {offered?.name} ↔ {wanted?.name}
                            </p>
                          </div>
                        </div>
                        <div className="flex gap-2 flex-wrap">
                          <button
                            onClick={() => navigate(`/messages?user=${otherUser?.id}`)}
                            className="flex items-center gap-1.5 px-3 py-1.5 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition text-xs font-semibold"
                          >
                            <MessageSquare size={13} />
                            Chat
                          </button>
                          {!iHaveConfirmed && (
                            <button
                              onClick={() => handleConfirmComplete(req)}
                              disabled={isLoading}
                              className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-600 text-white rounded-lg hover:bg-emerald-700 transition text-xs font-semibold disabled:opacity-50"
                            >
                              {isLoading
                                ? <div className="animate-spin rounded-full h-3 w-3 border-b-2 border-white" />
                                : <CheckCheck size={13} />
                              }
                              Mark Complete
                            </button>
                          )}
                          {iHaveConfirmed && (
                            <span className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-100 text-emerald-700 rounded-lg text-xs font-semibold">
                              <CheckCircle size={13} />
                              You confirmed
                            </span>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Quick Actions */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
              <h2 className="text-lg font-bold text-gray-900 mb-4">Quick Actions</h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <Link
                  to="/search"
                  className="block p-4 bg-gradient-to-br from-blue-50 to-blue-100 rounded-xl border border-blue-200 hover:border-blue-400 transition"
                >
                  <div className="font-semibold text-gray-900 text-sm">Find Learning Partners</div>
                  <p className="text-xs text-gray-600 mt-1">Search users with complementary skills</p>
                </Link>

                <Link
                  to="/swap-requests"
                  className="block p-4 bg-gradient-to-br from-purple-50 to-purple-100 rounded-xl border border-purple-200 hover:border-purple-400 transition"
                >
                  <div className="font-semibold text-gray-900 text-sm">Swap Requests</div>
                  <p className="text-xs text-gray-600 mt-1">Manage all your incoming and sent requests</p>
                </Link>

                <Link
                  to="/skills"
                  className="block p-4 bg-gradient-to-br from-green-50 to-green-100 rounded-xl border border-green-200 hover:border-green-400 transition"
                >
                  <div className="font-semibold text-gray-900 text-sm">Manage Skills</div>
                  <p className="text-xs text-gray-600 mt-1">Update what you can teach and learn</p>
                </Link>

                <Link
                  to="/messages"
                  className="block p-4 bg-gradient-to-br from-orange-50 to-orange-100 rounded-xl border border-orange-200 hover:border-orange-400 transition"
                >
                  <div className="font-semibold text-gray-900 text-sm">Messages</div>
                  <p className="text-xs text-gray-600 mt-1">
                    {unreadMessages.length > 0
                      ? `${unreadMessages.length} unread message${unreadMessages.length > 1 ? 's' : ''}`
                      : 'Check your conversations'}
                  </p>
                </Link>
              </div>
            </div>
          </div>

          {/* Right Column */}
          <div className="space-y-6">
            {/* Notifications */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
              <div className="flex items-center gap-2 mb-5">
                <Bell size={20} className="text-blue-600" />
                <h2 className="text-lg font-bold text-gray-900">Notifications</h2>
                {unreadNotifs > 0 && (
                  <span className="bg-red-100 text-red-600 px-2 py-0.5 rounded-full text-xs font-bold">
                    {unreadNotifs}
                  </span>
                )}
              </div>

              {notifications.length > 0 ? (
                <div className="space-y-3 max-h-80 overflow-y-auto">
                  {notifications.map((notif) => (
                    <button
                      key={notif.id}
                      onClick={() => markNotificationRead(notif.id)}
                      className={`w-full text-left p-3 rounded-xl border transition ${
                        notif.is_read
                          ? 'bg-gray-50 border-gray-200'
                          : 'bg-blue-50 border-blue-200 hover:bg-blue-100'
                      }`}
                    >
                      <div className="flex items-start gap-2">
                        {!notif.is_read && (
                          <div className="w-1.5 h-1.5 bg-blue-500 rounded-full mt-1.5 flex-shrink-0"></div>
                        )}
                        <div className="flex-1 min-w-0">
                          <p className="font-semibold text-gray-900 text-xs">{notif.title}</p>
                          <p className="text-xs text-gray-600 mt-0.5">{notif.message}</p>
                          <p className="text-xs text-gray-400 mt-1">
                            {new Date(notif.created_at).toLocaleDateString(undefined, { month: 'short', day: 'numeric' })}
                          </p>
                        </div>
                      </div>
                    </button>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8 text-gray-400">
                  <Bell size={28} className="mx-auto mb-2 opacity-40" />
                  <p className="text-sm">No notifications yet</p>
                </div>
              )}
            </div>

            {/* Profile Summary */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
              <h2 className="text-lg font-bold text-gray-900 mb-4">Profile Summary</h2>
              <div className="space-y-3">
                <div>
                  <p className="text-xs text-gray-500">Username</p>
                  <p className="font-semibold text-gray-900">{profile?.username}</p>
                </div>
                <div>
                  <p className="text-xs text-gray-500">Location</p>
                  <p className="font-semibold text-gray-900">{profile?.city || 'Not specified'}</p>
                </div>
                <div>
                  <p className="text-xs text-gray-500">Member Since</p>
                  <p className="font-semibold text-gray-900">
                    {profile?.created_at
                      ? new Date(profile.created_at).toLocaleDateString()
                      : 'N/A'}
                  </p>
                </div>
                <Link
                  to={`/profile/${user?.id}`}
                  className="inline-flex items-center gap-1 mt-2 text-blue-600 hover:text-blue-700 text-sm font-semibold"
                >
                  View & Edit Profile <ChevronRight size={14} />
                </Link>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
