/*
  # Skill Swap Platform - Initial Schema

  1. Overview
    Creates the complete database schema for the Skill Swap platform, including tables for:
    - Users with profile information
    - Skills database
    - User skill associations (offered and wanted)
    - Skill swap transactions/history
    - Messaging system for user communication
    - Review and rating system
    - Notifications

  2. New Tables
    - `users` - User profiles and authentication data
    - `skills` - Available skills in the system
    - `user_skills_offered` - Skills users can teach
    - `user_skills_wanted` - Skills users want to learn
    - `skill_swaps` - History of skill exchanges
    - `messages` - Private messages between users
    - `reviews` - Reviews and ratings for completed swaps
    - `notifications` - User notifications

  3. Security
    - Row Level Security enabled on all tables
    - Policies ensure users can only access their own data
    - Public skill browsing with authenticated access requirements
*/

-- Users table
CREATE TABLE IF NOT EXISTS users (
  id uuid PRIMARY KEY DEFAULT auth.uid(),
  username text UNIQUE NOT NULL,
  email text UNIQUE NOT NULL,
  bio text DEFAULT '',
  profile_picture_url text,
  city text DEFAULT '',
  country text DEFAULT '',
  average_rating decimal(3, 2) DEFAULT 0,
  total_reviews int DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Skills table
CREATE TABLE IF NOT EXISTS skills (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text UNIQUE NOT NULL,
  description text DEFAULT '',
  category text NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- User skills offered (skills they can teach)
CREATE TABLE IF NOT EXISTS user_skills_offered (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  skill_id uuid NOT NULL REFERENCES skills(id) ON DELETE CASCADE,
  proficiency_level text CHECK (proficiency_level IN ('beginner', 'intermediate', 'advanced', 'expert')) DEFAULT 'beginner',
  years_of_experience int DEFAULT 0,
  description text DEFAULT '',
  created_at timestamptz DEFAULT now(),
  UNIQUE(user_id, skill_id)
);

-- User skills wanted (skills they want to learn)
CREATE TABLE IF NOT EXISTS user_skills_wanted (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  skill_id uuid NOT NULL REFERENCES skills(id) ON DELETE CASCADE,
  priority int DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  UNIQUE(user_id, skill_id)
);

-- Skill swaps (transactions/history)
CREATE TABLE IF NOT EXISTS skill_swaps (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  initiator_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  recipient_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  skill_offered_id uuid NOT NULL REFERENCES skills(id) ON DELETE SET NULL,
  skill_wanted_id uuid NOT NULL REFERENCES skills(id) ON DELETE SET NULL,
  status text CHECK (status IN ('pending', 'accepted', 'completed', 'cancelled')) DEFAULT 'pending',
  proposed_date timestamp,
  notes text DEFAULT '',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Messages (private messaging)
CREATE TABLE IF NOT EXISTS messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  sender_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  recipient_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  swap_id uuid REFERENCES skill_swaps(id) ON DELETE SET NULL,
  content text NOT NULL,
  is_read boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

-- Reviews and ratings
CREATE TABLE IF NOT EXISTS reviews (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  reviewer_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  reviewed_user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  swap_id uuid NOT NULL REFERENCES skill_swaps(id) ON DELETE CASCADE,
  rating int CHECK (rating >= 1 AND rating <= 5),
  comment text DEFAULT '',
  created_at timestamptz DEFAULT now()
);

-- Notifications
CREATE TABLE IF NOT EXISTS notifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  type text NOT NULL,
  title text NOT NULL,
  message text NOT NULL,
  related_user_id uuid REFERENCES users(id) ON DELETE SET NULL,
  related_swap_id uuid REFERENCES skill_swaps(id) ON DELETE SET NULL,
  is_read boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE skills ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_skills_offered ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_skills_wanted ENABLE ROW LEVEL SECURITY;
ALTER TABLE skill_swaps ENABLE ROW LEVEL SECURITY;
ALTER TABLE messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE reviews ENABLE ROW LEVEL SECURITY;
ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;

-- Users table policies
CREATE POLICY "Users can view all profiles" ON users FOR SELECT USING (true);
CREATE POLICY "Users can update own profile" ON users FOR UPDATE TO authenticated USING (auth.uid() = id) WITH CHECK (auth.uid() = id);
CREATE POLICY "Users can insert own profile" ON users FOR INSERT TO authenticated WITH CHECK (auth.uid() = id);

-- Skills table policies
CREATE POLICY "Anyone can view skills" ON skills FOR SELECT USING (true);
CREATE POLICY "Admins can manage skills" ON skills FOR INSERT TO authenticated WITH CHECK (false);

-- User skills offered policies
CREATE POLICY "Users can view all offered skills" ON user_skills_offered FOR SELECT USING (true);
CREATE POLICY "Users can add their own skills" ON user_skills_offered FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update their own skills" ON user_skills_offered FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can delete their own skills" ON user_skills_offered FOR DELETE TO authenticated USING (auth.uid() = user_id);

-- User skills wanted policies
CREATE POLICY "Users can view all wanted skills" ON user_skills_wanted FOR SELECT USING (true);
CREATE POLICY "Users can add their own wanted skills" ON user_skills_wanted FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update their own wanted skills" ON user_skills_wanted FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can delete their own wanted skills" ON user_skills_wanted FOR DELETE TO authenticated USING (auth.uid() = user_id);

-- Skill swaps policies
CREATE POLICY "Users can view swaps involving them" ON skill_swaps FOR SELECT TO authenticated USING (auth.uid() = initiator_id OR auth.uid() = recipient_id);
CREATE POLICY "Users can create swap requests" ON skill_swaps FOR INSERT TO authenticated WITH CHECK (auth.uid() = initiator_id);
CREATE POLICY "Users can update swaps involving them" ON skill_swaps FOR UPDATE TO authenticated USING (auth.uid() = initiator_id OR auth.uid() = recipient_id) WITH CHECK (auth.uid() = initiator_id OR auth.uid() = recipient_id);

-- Messages policies
CREATE POLICY "Users can view their messages" ON messages FOR SELECT TO authenticated USING (auth.uid() = sender_id OR auth.uid() = recipient_id);
CREATE POLICY "Users can send messages" ON messages FOR INSERT TO authenticated WITH CHECK (auth.uid() = sender_id);
CREATE POLICY "Users can update their messages" ON messages FOR UPDATE TO authenticated USING (auth.uid() = sender_id OR auth.uid() = recipient_id) WITH CHECK (auth.uid() = sender_id OR auth.uid() = recipient_id);

-- Reviews policies
CREATE POLICY "Users can view all reviews" ON reviews FOR SELECT USING (true);
CREATE POLICY "Users can create reviews" ON reviews FOR INSERT TO authenticated WITH CHECK (auth.uid() = reviewer_id);
CREATE POLICY "Users can update their reviews" ON reviews FOR UPDATE TO authenticated USING (auth.uid() = reviewer_id) WITH CHECK (auth.uid() = reviewer_id);

-- Notifications policies
CREATE POLICY "Users can view their notifications" ON notifications FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "Users can update their notifications" ON notifications FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

-- Create indexes for performance
CREATE INDEX idx_user_skills_offered_user_id ON user_skills_offered(user_id);
CREATE INDEX idx_user_skills_offered_skill_id ON user_skills_offered(skill_id);
CREATE INDEX idx_user_skills_wanted_user_id ON user_skills_wanted(user_id);
CREATE INDEX idx_user_skills_wanted_skill_id ON user_skills_wanted(skill_id);
CREATE INDEX idx_skill_swaps_initiator ON skill_swaps(initiator_id);
CREATE INDEX idx_skill_swaps_recipient ON skill_swaps(recipient_id);
CREATE INDEX idx_skill_swaps_status ON skill_swaps(status);
CREATE INDEX idx_messages_sender ON messages(sender_id);
CREATE INDEX idx_messages_recipient ON messages(recipient_id);
CREATE INDEX idx_messages_created ON messages(created_at);
CREATE INDEX idx_reviews_reviewed_user ON reviews(reviewed_user_id);
CREATE INDEX idx_notifications_user ON notifications(user_id);
CREATE INDEX idx_notifications_created ON notifications(created_at);

-- Insert common skills
INSERT INTO skills (name, description, category) VALUES
  ('Spanish', 'Spanish language learning and conversation', 'Languages'),
  ('French', 'French language learning and conversation', 'Languages'),
  ('German', 'German language learning and conversation', 'Languages'),
  ('Python', 'Python programming language', 'Programming'),
  ('JavaScript', 'JavaScript programming language', 'Programming'),
  ('React', 'React JavaScript library', 'Programming'),
  ('Guitar', 'Guitar playing and music theory', 'Music'),
  ('Piano', 'Piano playing and music theory', 'Music'),
  ('Drawing', 'Drawing and sketch art', 'Art'),
  ('Photography', 'Photography and photo editing', 'Art'),
  ('Yoga', 'Yoga practice and instruction', 'Fitness'),
  ('Fitness Training', 'Personal fitness and workout coaching', 'Fitness'),
  ('Cooking', 'Cooking and culinary skills', 'Cooking'),
  ('Baking', 'Baking and pastry skills', 'Cooking'),
  ('Marketing', 'Digital and traditional marketing', 'Business'),
  ('SEO', 'Search engine optimization', 'Business'),
  ('Data Science', 'Data science and analytics', 'Data'),
  ('Machine Learning', 'Machine learning concepts and implementation', 'Data'),
  ('Public Speaking', 'Public speaking and presentation skills', 'Communication'),
  ('Writing', 'Writing and creative writing', 'Communication')
ON CONFLICT DO NOTHING;