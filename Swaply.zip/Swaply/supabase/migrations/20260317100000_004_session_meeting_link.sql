/*
  # Add meeting_link to sessions table

  Allows online sessions to include a link (Google Meet, Zoom, etc.)
  Only visible to the session creator and joined participants.
*/

ALTER TABLE sessions
  ADD COLUMN IF NOT EXISTS meeting_link text DEFAULT '';
