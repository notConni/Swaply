/*
  # Add Social and Engagement Features

  1. Overview
    Adds comprehensive social engagement features including:
    - Follow/follower system for social networking
    - Connection requests for stronger relationships
    - Skill swap requests with proposal details
    - Session scheduling with calendar support
    - Group swaps for collaborative learning
    - Badges and achievements system
    - Reputation points system
    - Location data for city-based discovery
    - Progress tracking for learning history

  2. New Tables
    - `followers` - Follow relationships between users
    - `connections` - Accepted connection relationships
    - `connection_requests` - Pending connection requests
    - `swap_requests` - Proposed skill exchanges with details
    - `sessions` - Scheduled learning sessions
    - `session_participants` - Participants in sessions
    - `group_swaps` - Group learning exchange setup
    - `group_swap_members` - Members of group swaps
    - `group_swap_chat` - Chat messages for group swaps
    - `badges` - Achievement badge definitions
    - `user_badges` - User-earned badges
    - `reputation_history` - Reputation point transaction history
    - `learning_progress` - User's learning achievements and progress
    - `activity_feed` - User activity for timeline display

  3. Modifications to Existing Tables
    - Add reputation_points to users table
    - Add location data (latitude/longitude) to users table
    - Add session_preference (online/in-person) to users table
    - Add visibility_preference to users table

  4. Security
    - All tables have RLS enabled
    - Users can only see/manage their own data
    - Public visibility settings respected
*/

-- Add columns to users table
ALTER TABLE users ADD COLUMN IF NOT EXISTS reputation_points int DEFAULT 0;
ALTER TABLE users ADD COLUMN IF NOT EXISTS latitude decimal(10, 8);
ALTER TABLE users ADD COLUMN IF NOT EXISTS longitude decimal(11, 8);
ALTER TABLE users ADD COLUMN IF NOT EXISTS session_preference text DEFAULT 'both' CHECK (session_preference IN ('online', 'in-person', 'both'));
ALTER TABLE users ADD COLUMN IF NOT EXISTS is_public boolean DEFAULT true;

-- Followers table
CREATE TABLE IF NOT EXISTS followers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  follower_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  following_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at timestamptz DEFAULT now(),
  UNIQUE(follower_id, following_id),
  CHECK (follower_id != following_id)
);

-- Connections table (accepted friendships)
CREATE TABLE IF NOT EXISTS connections (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id_1 uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  user_id_2 uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at timestamptz DEFAULT now(),
  UNIQUE(user_id_1, user_id_2),
  CHECK (user_id_1 < user_id_2)
);

-- Connection requests
CREATE TABLE IF NOT EXISTS connection_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  requester_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  recipient_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  message text DEFAULT '',
  status text CHECK (status IN ('pending', 'accepted', 'declined')) DEFAULT 'pending',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(requester_id, recipient_id)
);

-- Swap requests with proposal details
CREATE TABLE IF NOT EXISTS swap_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  requester_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  recipient_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  skill_offered_id uuid NOT NULL REFERENCES skills(id) ON DELETE SET NULL,
  skill_wanted_id uuid NOT NULL REFERENCES skills(id) ON DELETE SET NULL,
  message text DEFAULT '',
  session_type text CHECK (session_type IN ('online', 'in-person')) DEFAULT 'online',
  proposed_date date,
  proposed_time time,
  status text CHECK (status IN ('pending', 'accepted', 'declined', 'completed')) DEFAULT 'pending',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Sessions for scheduled learning
CREATE TABLE IF NOT EXISTS sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  description text DEFAULT '',
  skill_id uuid NOT NULL REFERENCES skills(id) ON DELETE CASCADE,
  creator_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  session_type text CHECK (session_type IN ('online', 'in-person')) DEFAULT 'online',
  scheduled_date date NOT NULL,
  scheduled_time time NOT NULL,
  duration_minutes int DEFAULT 60,
  location text,
  max_participants int DEFAULT 2,
  status text CHECK (status IN ('scheduled', 'in-progress', 'completed', 'cancelled')) DEFAULT 'scheduled',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Session participants
CREATE TABLE IF NOT EXISTS session_participants (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id uuid NOT NULL REFERENCES sessions(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  role text CHECK (role IN ('teacher', 'learner')) DEFAULT 'learner',
  joined_at timestamptz DEFAULT now(),
  UNIQUE(session_id, user_id)
);

-- Group swaps
CREATE TABLE IF NOT EXISTS group_swaps (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  description text DEFAULT '',
  creator_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  skill_focus_id uuid REFERENCES skills(id) ON DELETE SET NULL,
  session_type text CHECK (session_type IN ('online', 'in-person')) DEFAULT 'online',
  max_members int DEFAULT 5,
  location text,
  scheduled_date date,
  scheduled_time time,
  status text CHECK (status IN ('open', 'in-progress', 'completed', 'cancelled')) DEFAULT 'open',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Group swap members
CREATE TABLE IF NOT EXISTS group_swap_members (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  group_swap_id uuid NOT NULL REFERENCES group_swaps(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  joined_at timestamptz DEFAULT now(),
  UNIQUE(group_swap_id, user_id)
);

-- Group swap chat
CREATE TABLE IF NOT EXISTS group_swap_chat (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  group_swap_id uuid NOT NULL REFERENCES group_swaps(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  message text NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Badges/Achievements
CREATE TABLE IF NOT EXISTS badges (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text UNIQUE NOT NULL,
  description text NOT NULL,
  icon_name text NOT NULL,
  requirement text NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- User badges (earned achievements)
CREATE TABLE IF NOT EXISTS user_badges (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  badge_id uuid NOT NULL REFERENCES badges(id) ON DELETE CASCADE,
  earned_at timestamptz DEFAULT now(),
  UNIQUE(user_id, badge_id)
);

-- Reputation history
CREATE TABLE IF NOT EXISTS reputation_history (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  points int NOT NULL,
  reason text NOT NULL,
  related_swap_id uuid REFERENCES skill_swaps(id) ON DELETE SET NULL,
  created_at timestamptz DEFAULT now()
);

-- Learning progress
CREATE TABLE IF NOT EXISTS learning_progress (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  skill_id uuid NOT NULL REFERENCES skills(id) ON DELETE CASCADE,
  proficiency_level text CHECK (proficiency_level IN ('beginner', 'intermediate', 'advanced', 'expert')) DEFAULT 'beginner',
  swaps_completed int DEFAULT 0,
  total_hours_learned decimal(6, 1) DEFAULT 0,
  last_practiced_at timestamptz,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(user_id, skill_id)
);

-- Activity feed
CREATE TABLE IF NOT EXISTS activity_feed (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  activity_type text NOT NULL,
  actor_id uuid REFERENCES users(id) ON DELETE SET NULL,
  content text NOT NULL,
  related_skill_id uuid REFERENCES skills(id) ON DELETE SET NULL,
  related_swap_id uuid REFERENCES skill_swaps(id) ON DELETE SET NULL,
  is_public boolean DEFAULT true,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS on all new tables
ALTER TABLE followers ENABLE ROW LEVEL SECURITY;
ALTER TABLE connections ENABLE ROW LEVEL SECURITY;
ALTER TABLE connection_requests ENABLE ROW LEVEL SECURITY;
ALTER TABLE swap_requests ENABLE ROW LEVEL SECURITY;
ALTER TABLE sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE session_participants ENABLE ROW LEVEL SECURITY;
ALTER TABLE group_swaps ENABLE ROW LEVEL SECURITY;
ALTER TABLE group_swap_members ENABLE ROW LEVEL SECURITY;
ALTER TABLE group_swap_chat ENABLE ROW LEVEL SECURITY;
ALTER TABLE badges ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_badges ENABLE ROW LEVEL SECURITY;
ALTER TABLE reputation_history ENABLE ROW LEVEL SECURITY;
ALTER TABLE learning_progress ENABLE ROW LEVEL SECURITY;
ALTER TABLE activity_feed ENABLE ROW LEVEL SECURITY;

-- Followers policies
CREATE POLICY "Anyone can view followers" ON followers FOR SELECT USING (true);
CREATE POLICY "Users can follow others" ON followers FOR INSERT TO authenticated WITH CHECK (auth.uid() = follower_id);
CREATE POLICY "Users can unfollow" ON followers FOR DELETE TO authenticated USING (auth.uid() = follower_id);

-- Connections policies
CREATE POLICY "Users can view connections" ON connections FOR SELECT TO authenticated USING (auth.uid() = user_id_1 OR auth.uid() = user_id_2);
CREATE POLICY "Connections created from request" ON connections FOR INSERT TO authenticated WITH CHECK (false);
CREATE POLICY "Users can remove connections" ON connections FOR DELETE TO authenticated USING (auth.uid() = user_id_1 OR auth.uid() = user_id_2);

-- Connection requests policies
CREATE POLICY "Users can view their requests" ON connection_requests FOR SELECT TO authenticated USING (auth.uid() = requester_id OR auth.uid() = recipient_id);
CREATE POLICY "Users can send connection requests" ON connection_requests FOR INSERT TO authenticated WITH CHECK (auth.uid() = requester_id);
CREATE POLICY "Users can accept/decline requests" ON connection_requests FOR UPDATE TO authenticated USING (auth.uid() = recipient_id) WITH CHECK (auth.uid() = recipient_id);

-- Swap requests policies
CREATE POLICY "Users can view relevant swap requests" ON swap_requests FOR SELECT TO authenticated USING (auth.uid() = requester_id OR auth.uid() = recipient_id);
CREATE POLICY "Users can create swap requests" ON swap_requests FOR INSERT TO authenticated WITH CHECK (auth.uid() = requester_id);
CREATE POLICY "Users can update relevant requests" ON swap_requests FOR UPDATE TO authenticated USING (auth.uid() = requester_id OR auth.uid() = recipient_id) WITH CHECK (auth.uid() = requester_id OR auth.uid() = recipient_id);

-- Sessions policies
CREATE POLICY "Users can view all sessions" ON sessions FOR SELECT USING (true);
CREATE POLICY "Users can create sessions" ON sessions FOR INSERT TO authenticated WITH CHECK (auth.uid() = creator_id);
CREATE POLICY "Creators can update sessions" ON sessions FOR UPDATE TO authenticated USING (auth.uid() = creator_id) WITH CHECK (auth.uid() = creator_id);

-- Session participants policies
CREATE POLICY "Users can view session participants" ON session_participants FOR SELECT USING (true);
CREATE POLICY "Users can join sessions" ON session_participants FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can leave sessions" ON session_participants FOR DELETE TO authenticated USING (auth.uid() = user_id);

-- Group swaps policies
CREATE POLICY "Users can view all group swaps" ON group_swaps FOR SELECT USING (true);
CREATE POLICY "Users can create group swaps" ON group_swaps FOR INSERT TO authenticated WITH CHECK (auth.uid() = creator_id);
CREATE POLICY "Creators can update group swaps" ON group_swaps FOR UPDATE TO authenticated USING (auth.uid() = creator_id) WITH CHECK (auth.uid() = creator_id);

-- Group swap members policies
CREATE POLICY "Users can view members" ON group_swap_members FOR SELECT USING (true);
CREATE POLICY "Users can join groups" ON group_swap_members FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can leave groups" ON group_swap_members FOR DELETE TO authenticated USING (auth.uid() = user_id);

-- Group swap chat policies
CREATE POLICY "Users can view group chat" ON group_swap_chat FOR SELECT USING (true);
CREATE POLICY "Members can post to group chat" ON group_swap_chat FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);

-- Badges policies
CREATE POLICY "Anyone can view badges" ON badges FOR SELECT USING (true);

-- User badges policies
CREATE POLICY "Users can view all earned badges" ON user_badges FOR SELECT USING (true);
CREATE POLICY "System can award badges" ON user_badges FOR INSERT TO authenticated WITH CHECK (false);

-- Reputation history policies
CREATE POLICY "Users can view their reputation history" ON reputation_history FOR SELECT TO authenticated USING (auth.uid() = user_id);

-- Learning progress policies
CREATE POLICY "Users can view all progress" ON learning_progress FOR SELECT USING (true);
CREATE POLICY "Users can update own progress" ON learning_progress FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update their progress" ON learning_progress FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

-- Activity feed policies
CREATE POLICY "Users can view public activity" ON activity_feed FOR SELECT USING (is_public = true);
CREATE POLICY "Users can view their followers activity" ON activity_feed FOR SELECT TO authenticated USING (
  is_public = true OR auth.uid() = user_id OR
  EXISTS (SELECT 1 FROM followers WHERE follower_id = auth.uid() AND following_id = user_id)
);
CREATE POLICY "Users can create their activity" ON activity_feed FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);

-- Create indexes for performance
CREATE INDEX idx_followers_follower ON followers(follower_id);
CREATE INDEX idx_followers_following ON followers(following_id);
CREATE INDEX idx_connections_users ON connections(user_id_1, user_id_2);
CREATE INDEX idx_connection_requests_recipient ON connection_requests(recipient_id);
CREATE INDEX idx_swap_requests_recipient ON swap_requests(recipient_id);
CREATE INDEX idx_swap_requests_status ON swap_requests(status);
CREATE INDEX idx_sessions_creator ON sessions(creator_id);
CREATE INDEX idx_sessions_date ON sessions(scheduled_date);
CREATE INDEX idx_session_participants_user ON session_participants(user_id);
CREATE INDEX idx_group_swap_members_user ON group_swap_members(user_id);
CREATE INDEX idx_user_badges_user ON user_badges(user_id);
CREATE INDEX idx_reputation_history_user ON reputation_history(user_id);
CREATE INDEX idx_learning_progress_user ON learning_progress(user_id);
CREATE INDEX idx_activity_feed_user ON activity_feed(user_id);
CREATE INDEX idx_activity_feed_created ON activity_feed(created_at);

-- Insert badge definitions
INSERT INTO badges (name, description, icon_name, requirement) VALUES
  ('First Swap', 'Complete your first skill swap', 'star', 'complete_first_swap'),
  ('5 Swaps Champion', 'Complete 5 successful skill swaps', 'award', 'complete_5_swaps'),
  ('10 Swaps Master', 'Complete 10 successful skill swaps', 'trophy', 'complete_10_swaps'),
  ('Highly Rated', 'Receive an average rating of 4.5 or higher', 'heart', 'rating_4_5'),
  ('Community Helper', 'Help 5 different users learn', 'users', 'help_5_users'),
  ('Reputation Builder', 'Earn 500 reputation points', 'trending-up', 'reputation_500'),
  ('Session Host', 'Schedule and complete 3 learning sessions', 'calendar', 'host_3_sessions'),
  ('Group Leader', 'Create and lead a group swap', 'users-plus', 'lead_group_swap'),
  ('Early Adopter', 'Join Skill Swap in the first month', 'zap', 'early_adopter'),
  ('Connected', 'Have 10 active connections', 'link', 'connections_10')
ON CONFLICT DO NOTHING;
