-- ============================================================
-- RUN THIS IN YOUR SUPABASE DASHBOARD → SQL EDITOR
-- Applies migrations 003 + 004 in one shot
-- ============================================================

-- ── MIGRATION 003: Swap Completion + Reviews ────────────────

-- Dual-confirmation columns on swap_requests
ALTER TABLE swap_requests
  ADD COLUMN IF NOT EXISTS requester_confirmed_complete boolean DEFAULT false,
  ADD COLUMN IF NOT EXISTS recipient_confirmed_complete boolean DEFAULT false;

-- Reviews table for swap_requests (separate from legacy reviews)
CREATE TABLE IF NOT EXISTS swap_request_reviews (
  id                uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  swap_request_id   uuid NOT NULL REFERENCES swap_requests(id) ON DELETE CASCADE,
  reviewer_id       uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  reviewed_user_id  uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  rating            int  NOT NULL CHECK (rating >= 1 AND rating <= 5),
  comment           text DEFAULT '',
  created_at        timestamptz DEFAULT now(),
  UNIQUE(swap_request_id, reviewer_id)
);

ALTER TABLE swap_request_reviews ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view swap reviews"
  ON swap_request_reviews FOR SELECT USING (true);

CREATE POLICY "Authenticated users can create swap reviews"
  ON swap_request_reviews FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = reviewer_id);

CREATE INDEX IF NOT EXISTS idx_swap_request_reviews_swap     ON swap_request_reviews(swap_request_id);
CREATE INDEX IF NOT EXISTS idx_swap_request_reviews_reviewed ON swap_request_reviews(reviewed_user_id);

-- Allow inserting notifications (was missing, silently blocked all notification inserts)
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies
    WHERE tablename = 'notifications' AND policyname = 'Users can create notifications'
  ) THEN
    EXECUTE 'CREATE POLICY "Users can create notifications" ON notifications FOR INSERT TO authenticated WITH CHECK (true)';
  END IF;
END $$;

-- Allow inserting reputation history entries
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies
    WHERE tablename = 'reputation_history' AND policyname = 'Users can insert reputation history'
  ) THEN
    EXECUTE 'CREATE POLICY "Users can insert reputation history" ON reputation_history FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id)';
  END IF;
END $$;


-- ── MIGRATION 004: Session Meeting Link ─────────────────────

ALTER TABLE sessions
  ADD COLUMN IF NOT EXISTS meeting_link text DEFAULT '';

-- ============================================================
-- Done! All features should now work correctly.
-- ============================================================
