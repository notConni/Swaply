import "jsr:@supabase/functions-js/edge-runtime.d.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

interface SuggestionRequest {
  userId: string;
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const { userId }: SuggestionRequest = await req.json();

    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");

    if (!supabaseUrl || !supabaseKey) {
      throw new Error("Missing Supabase configuration");
    }

    const headers = {
      "Content-Type": "application/json",
      Authorization: `Bearer ${supabaseKey}`,
      apikey: supabaseKey,
    };

    const userWantedResponse = await fetch(
      `${supabaseUrl}/rest/v1/user_skills_wanted?user_id=eq.${userId}`,
      { headers }
    );
    const userWanted = await userWantedResponse.json();

    const userProgressResponse = await fetch(
      `${supabaseUrl}/rest/v1/learning_progress?user_id=eq.${userId}`,
      { headers }
    );
    const userProgress = await userProgressResponse.json();

    const userComplexityResponse = await fetch(
      `${supabaseUrl}/rest/v1/skill_swaps?or=(initiator_id.eq.${userId},recipient_id.eq.${userId})&status=eq.completed`,
      { headers }
    );
    const completedSwaps = await userComplexityResponse.json();

    const suggestions = [];

    const skillIdToProgress = new Map();
    userProgress.forEach((p: { skill_id: string; proficiency_level: string }) => {
      skillIdToProgress.set(p.skill_id, p.proficiency_level);
    });

    const nextLevelMap: Record<string, string> = {
      beginner: "intermediate",
      intermediate: "advanced",
      advanced: "expert",
    };

    userProgress.forEach((prog: { skill_id: string; proficiency_level: string; skill?: { name: string } }) => {
      const nextLevel = nextLevelMap[prog.proficiency_level];
      if (nextLevel) {
        suggestions.push({
          type: "level_up",
          skill: prog.skill?.name || "Unknown Skill",
          currentLevel: prog.proficiency_level,
          nextLevel,
          message: `You're ready to advance your ${prog.skill?.name} skills to ${nextLevel} level!`,
          priority: 2,
        });
      }
    });

    const categoryFrequency = new Map<string, number>();
    userWanted.forEach((w: { skill_id: string }) => {
      categoryFrequency.set(w.skill_id, (categoryFrequency.get(w.skill_id) || 0) + 1);
    });

    if (completedSwaps.length >= 5) {
      suggestions.push({
        type: "achievement",
        message: "You've completed 5+ swaps! Consider mentoring new members.",
        priority: 1,
      });
    }

    if (completedSwaps.length >= 10) {
      suggestions.push({
        type: "achievement",
        message: "You're a Skill Swap Master with 10+ completed exchanges!",
        priority: 1,
      });
    }

    const skillDistribution = new Map<string, number>();
    userWanted.forEach((w: { skill_id: string }) => {
      skillDistribution.set(w.skill_id, (skillDistribution.get(w.skill_id) || 0) + 1);
    });

    if (skillDistribution.size > 0) {
      const skillIds = Array.from(skillDistribution.keys());
      if (skillIds.length >= 3) {
        suggestions.push({
          type: "diversity",
          message: `You're learning diverse skills! Consider specializing in one to become an expert.`,
          priority: 2,
        });
      }
    }

    suggestions.sort((a, b) => b.priority - a.priority);

    return new Response(JSON.stringify({ suggestions: suggestions.slice(0, 5) }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (error) {
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : "Unknown error" }),
      {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  }
});
