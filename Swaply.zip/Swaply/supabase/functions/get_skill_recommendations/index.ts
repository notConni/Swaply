import "jsr:@supabase/functions-js/edge-runtime.d.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

interface RecommendationRequest {
  userId: string;
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const { userId }: RecommendationRequest = await req.json();

    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");

    if (!supabaseUrl || !supabaseKey) {
      throw new Error("Missing Supabase configuration");
    }

    const headers = {
      "Content-Type": "application/json",
      Authorization: `Bearer ${supabaseKey}`,
      apikey: supabaseKey,
    };

    const userWantedResponse = await fetch(
      `${supabaseUrl}/rest/v1/user_skills_wanted?user_id=eq.${userId}`,
      { headers }
    );
    const userWanted = await userWantedResponse.json();

    const userOfferedResponse = await fetch(
      `${supabaseUrl}/rest/v1/user_skills_offered?user_id=eq.${userId}`,
      { headers }
    );
    const userOffered = await userOfferedResponse.json();

    if (!userWanted || !userOffered) {
      return new Response(JSON.stringify({ recommendations: [] }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const wantedSkillIds = userWanted.map((w: { skill_id: string }) => `"${w.skill_id}"`).join(",");
    const offeredSkillIds = userOffered.map((o: { skill_id: string }) => `"${o.skill_id}"`).join(",");

    const recommendedUsersResponse = await fetch(
      `${supabaseUrl}/rest/v1/user_skills_offered?skill_id=in.(${wantedSkillIds})&user_id=neq.${userId}`,
      { headers }
    );
    const recommendedUsers = await recommendedUsersResponse.json();

    const complementaryUsersResponse = await fetch(
      `${supabaseUrl}/rest/v1/user_skills_wanted?skill_id=in.(${offeredSkillIds})&user_id=neq.${userId}`,
      { headers }
    );
    const complementaryUsers = await complementaryUsersResponse.json();

    const recommendations = {
      usersWhoTeachWhatYouWant: recommendedUsers,
      usersWhoWantWhatYouTeach: complementaryUsers,
    };

    return new Response(JSON.stringify(recommendations), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (error) {
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : "Unknown error" }),
      {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  }
});
